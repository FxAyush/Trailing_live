"""
pipeline_mc.py
--------------
Master pipeline using Monte Carlo scenarios instead of diffusion model.

Run modes:
  python pipeline_mc.py --mode demo      Instant demo, no training needed
  python pipeline_mc.py --mode train     Train RL agent only (no diffusion)
  python pipeline_mc.py --mode infer     Get today's recommendation
  python pipeline_mc.py --mode backtest  Walk-forward backtest
"""

import os, sys, argparse
import numpy as np
import pandas as pd
import torch
import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from data_loader      import load_all_signals
from signal_processor import run_full_pipeline, get_current_snapshot
from monte_carlo      import MonteCarloEngine, mc_portfolio_returns, N_ASSETS
from cvar_engine      import CVaREngine, ASSET_CLASSES
from safe_rl_agent    import SafeRLAgent

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ---------------------------------------------------------------------------
# Patched CVaR compute that uses MC returns directly
# ---------------------------------------------------------------------------
def mc_cvar_compute(engine: CVaREngine,
                    weights: np.ndarray,
                    mc_scenarios: np.ndarray) -> dict:
    """
    CVaR computation using Monte Carlo asset returns directly.
    Bypasses the signals_to_returns() mapping entirely.
    """
    weights = np.clip(weights, 0, 1)
    weights = weights / (weights.sum() + 1e-8)

    port_rets   = mc_portfolio_returns(weights, mc_scenarios)
    sorted_rets = np.sort(port_rets)
    n           = len(sorted_rets)
    tail_idx    = max(1, int(np.ceil(engine.alpha * n)))
    tail_rets   = sorted_rets[:tail_idx]

    cvar     = float(tail_rets.mean())
    var      = float(sorted_rets[tail_idx])
    expected = float(port_rets.mean())
    vol      = float(port_rets.std())
    sharpe   = expected / vol * np.sqrt(12) if vol > 0 else 0.0  # monthly Sharpe

    pct = {k: float(np.percentile(port_rets, v))
           for k, v in [("p1",1),("p5",5),("p10",10),
                        ("p25",25),("p50",50),("p75",75),("p90",90)]}

    return {
        "cvar":         cvar,
        "var":          var,
        "expected_ret": expected,
        "volatility":   vol,
        "sharpe":       sharpe,
        "percentiles":  pct,
        "all_returns":  port_rets,
        "worst_returns":tail_rets,
        "n_scenarios":  n,
        "tail_size":    tail_idx,
        "alpha":        engine.alpha,
    }


# ---------------------------------------------------------------------------
# Recommendation
# ---------------------------------------------------------------------------
def get_recommendation(signals, mc_engine, agent,
                       n_scenarios=500, max_cvar=-0.15):
    signal_dim      = signals.shape[1]
    current_state   = signals.iloc[-1].values.astype(np.float32)
    current_weights = np.ones(N_ASSETS) / N_ASSETS
    state = np.concatenate([current_state, current_weights]).astype(np.float32)

    print(f"  Generating {n_scenarios} Monte Carlo scenarios...")
    scenarios = mc_engine.generate_scenarios(current_state, n_scenarios)

    print("  Running safe RL agent + action repair...")

    # Inject MC scenarios into agent via closure
    cvar_engine = CVaREngine(alpha=0.05)

    # Patch action repair to use MC scenarios
    from safe_rl_agent import ActionRepair
    repair = ActionRepair(cvar_engine, max_cvar)

    # Get raw action from actor
    s_t = torch.FloatTensor(state).unsqueeze(0).to(DEVICE)
    with torch.no_grad():
        mean, _ = agent.actor(s_t)
        raw_action = mean.squeeze(0).cpu().numpy()
    raw_action = np.clip(raw_action, 0, 1)
    raw_action /= raw_action.sum() + 1e-8

    # Check safety with MC
    metrics = mc_cvar_compute(cvar_engine, raw_action, scenarios)
    is_safe = metrics["cvar"] >= max_cvar

    if not is_safe:
        # Repair using MC scenarios
        safe_action, repaired, n_steps = repair.repair(raw_action, scenarios)
        metrics = mc_cvar_compute(cvar_engine, safe_action, scenarios)
    else:
        safe_action = raw_action
        repaired    = False
        n_steps     = 0

    info = {
        "raw_weights":   raw_action,
        "safe_weights":  safe_action,
        "repaired":      repaired,
        "repair_steps":  n_steps,
        "cvar":          metrics["cvar"],
        "expected_ret":  metrics["expected_ret"],
        "sharpe":        metrics["sharpe"],
        "is_safe":       metrics["cvar"] >= max_cvar,
        "weights_named": dict(zip(ASSET_CLASSES, safe_action)),
    }

    return safe_action, info, metrics, scenarios


def print_recommendation(info, metrics):
    w = info["weights_named"]
    top3 = sorted(w.items(), key=lambda x: -x[1])[:3]
    pct  = metrics["percentiles"]

    print("\nPORTFOLIO RECOMMENDATION")
    print("=" * 45)
    print("\nTop allocations:")
    for asset, weight in top3:
        print(f"  {asset:20s}: {weight*100:.1f}%")

    print(f"\nFull allocation:")
    for asset, weight in sorted(w.items(), key=lambda x: -x[1]):
        bar = "█" * int(weight * 30)
        print(f"  {asset:20s} {weight*100:5.1f}%  {bar}")

    print(f"\nRisk metrics (30-day outlook, {metrics['n_scenarios']} scenarios):")
    print(f"  Expected return:          {metrics['expected_ret']*100:+.1f}%")
    print(f"  Median return:            {pct['p50']*100:+.1f}%")
    print(f"  CVaR (worst 5% avg loss): {metrics['cvar']*100:.1f}%")
    print(f"  Sharpe ratio:             {metrics['sharpe']:.2f}")

    print(f"\nScenario distribution:")
    print(f"  Best case  (top 10%):   {pct['p90']*100:+.1f}%")
    print(f"  Good case  (top 25%):   {pct['p75']*100:+.1f}%")
    print(f"  Base case  (median):    {pct['p50']*100:+.1f}%")
    print(f"  Bad case   (bot 10%):   {pct['p10']*100:+.1f}%")
    print(f"  Worst case (bot 5%):    {pct['p5']*100:+.1f}%")

    status = "✓ SAFE" if info["is_safe"] else "✗ UNSAFE"
    print(f"\nSafety: {status} — CVaR {metrics['cvar']*100:.1f}% "
          f"(limit: -15.0%)")
    if info["repaired"]:
        print(f"  ⚡ Action repair applied ({info['repair_steps']} steps)")


# ---------------------------------------------------------------------------
# Training with Monte Carlo
# ---------------------------------------------------------------------------
def train_rl_with_mc(signals, mc_engine, n_episodes=200,
                     max_cvar=-0.15, n_scenarios=200,
                     save_path="safe_rl_agent_mc.pt"):
    from safe_rl_agent import PortfolioEnv, SafeRLAgent

    signal_dim = signals.shape[1]
    state_dim  = signal_dim + N_ASSETS

    def scenarios_fn(state, n):
        return mc_engine.generate_scenarios(state, n)

    env   = PortfolioEnv(signals, scenarios_fn,
                         max_cvar=max_cvar, n_scenarios=n_scenarios)
    agent = SafeRLAgent(state_dim=state_dim, max_cvar=max_cvar)

    print(f"\nTraining Safe RL Agent (Monte Carlo) on {DEVICE}")
    print(f"  Episodes:       {n_episodes}")
    print(f"  CVaR limit:     {max_cvar*100:.0f}%")
    print(f"  Scenarios/step: {n_scenarios}")

    ep_rewards = []

    for ep in range(1, n_episodes + 1):
        state, _ = env.reset()
        ep_reward = 0

        for step in range(env.horizon):
            current_state = signals.iloc[env._signal_idx].values
            scenarios = mc_engine.generate_scenarios(current_state, n_scenarios)

            # Use MC CVaR for action repair during training
            cvar_eng = CVaREngine(alpha=0.05)
            s_t = torch.FloatTensor(state).unsqueeze(0).to(DEVICE)
            with torch.no_grad():
                raw_a, _ = agent.actor.sample(s_t)
                raw_a = raw_a.squeeze(0).cpu().numpy()
            raw_a = np.clip(raw_a, 0, 1) / (raw_a.sum() + 1e-8)

            metrics  = mc_cvar_compute(cvar_eng, raw_a, scenarios)
            is_safe  = metrics["cvar"] >= max_cvar
            if not is_safe:
                from safe_rl_agent import ActionRepair
                repair = ActionRepair(cvar_eng, max_cvar)
                action, _, _ = repair.repair(raw_a, scenarios)
            else:
                action = raw_a

            next_state, reward, done, _, step_info = env.step(action)
            safety_cost = max(0, max_cvar - metrics["cvar"])

            agent.store_transition(state, action, reward,
                                   next_state, done, safety_cost)
            if len(agent.buffer) >= 128:
                agent.update(64)

            state = next_state
            ep_reward += reward
            if done:
                break

        ep_rewards.append(ep_reward)
        if ep % 20 == 0:
            print(f"  Episode {ep:3d}/{n_episodes} | "
                  f"avg reward (last 20): {np.mean(ep_rewards[-20:]):.3f}")

    agent.save(save_path)
    return agent


# ---------------------------------------------------------------------------
# Backtest
# ---------------------------------------------------------------------------
def backtest(signals, mc_engine, agent, n_scenarios=200, step=21):
    signal_dim = signals.shape[1]
    cvar_eng   = CVaREngine(alpha=0.05)
    records    = []
    indices    = range(60, len(signals) - 30, step)
    print(f"\nWalk-forward backtest ({len(indices)} rebalance points)...")

    # Benchmark: 60/30/10
    bench_w = np.zeros(N_ASSETS)
    bench_w[0] = 0.60   # indian_equity
    bench_w[4] = 0.30   # bonds_india
    bench_w[3] = 0.10   # gold

    for i, idx in enumerate(indices):
        current_state = signals.iloc[idx].values.astype(np.float32)
        scenarios = mc_engine.generate_scenarios(current_state, n_scenarios)

        # Strategy weights
        current_weights = np.ones(N_ASSETS) / N_ASSETS
        state = np.concatenate([current_state, current_weights]).astype(np.float32)
        s_t = torch.FloatTensor(state).unsqueeze(0).to(DEVICE)
        with torch.no_grad():
            mean, _ = agent.actor(s_t)
            action = mean.squeeze(0).cpu().numpy()
        action = np.clip(action, 0, 1) / (action.sum() + 1e-8)

        # 21-day forward return
        fwd = scenarios[:, :step, :]
        strat_ret = float(mc_portfolio_returns(action, fwd).mean())
        bench_ret = float(mc_portfolio_returns(bench_w, fwd).mean())

        cvar = mc_cvar_compute(cvar_eng, action, scenarios)["cvar"]
        stress = float(
            run_full_pipeline(
                signals.iloc[max(0, idx-60):idx+1]
            )["score"].iloc[-1]
        )

        records.append({
            "date":          str(signals.index[idx].date()),
            "stress_score":  stress,
            "cvar":          cvar,
            "strategy_ret":  strat_ret,
            "benchmark_ret": bench_ret,
        })

        if (i + 1) % 10 == 0:
            print(f"  {i+1}/{len(indices)} | "
                  f"strat={strat_ret*100:.1f}% bench={bench_ret*100:.1f}%")

    df = pd.DataFrame(records)
    df["strategy_cum"]  = (1 + df["strategy_ret"]).cumprod()
    df["benchmark_cum"] = (1 + df["benchmark_ret"]).cumprod()

    n = len(df)
    ann = lambda x: ((x.iloc[-1]) ** (252 / n / 21) - 1) * 100
    print(f"\nBacktest results:")
    print(f"  Strategy  ann. return: {ann(df['strategy_cum']):.1f}%")
    print(f"  Benchmark ann. return: {ann(df['benchmark_cum']):.1f}%")
    print(f"  Avg CVaR:              {df['cvar'].mean()*100:.1f}%")
    return df


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["demo","train","infer","backtest"],
                        default="demo")
    parser.add_argument("--episodes", type=int, default=200)
    parser.add_argument("--n_scenarios", type=int, default=300)
    parser.add_argument("--max_cvar", type=float, default=-0.15)
    parser.add_argument("--rl_path", default="safe_rl_agent_mc.pt")
    args = parser.parse_args()

    print("=" * 60)
    print("  CRISIS DETECTION + SAFE PORTFOLIO (MONTE CARLO)")
    print(f"  Device: {DEVICE}")
    print("=" * 60)

    signals    = load_all_signals()
    signal_dim = signals.shape[1]
    state_dim  = signal_dim + N_ASSETS

    mc_engine = MonteCarloEngine(horizon=30, df_t=5)

    # Stress index
    print("\nComputing stress index...")
    results = run_full_pipeline(signals)
    snap    = get_current_snapshot(results)
    print(f"  Stress score: {snap['stress_score']:.1f}/100 "
          f"({snap['regime'].upper()}) — trend: {snap['trend']}")

    if args.mode == "demo":
        agent = SafeRLAgent(state_dim=state_dim, max_cvar=args.max_cvar)
        print("\nGenerating recommendation (untrained agent — for demo)...")
        action, info, metrics, _ = get_recommendation(
            signals, mc_engine, agent,
            n_scenarios=args.n_scenarios, max_cvar=args.max_cvar
        )
        print_recommendation(info, metrics)

    elif args.mode == "train":
        agent = train_rl_with_mc(
            signals, mc_engine,
            n_episodes=args.episodes,
            max_cvar=args.max_cvar,
            n_scenarios=args.n_scenarios,
            save_path=args.rl_path
        )
        print("\nTraining complete. Run --mode infer for recommendation.")

    elif args.mode == "infer":
        agent = SafeRLAgent.load(args.rl_path, state_dim=state_dim,
                                  max_cvar=args.max_cvar)
        action, info, metrics, _ = get_recommendation(
            signals, mc_engine, agent,
            n_scenarios=args.n_scenarios, max_cvar=args.max_cvar
        )
        print_recommendation(info, metrics)

    elif args.mode == "backtest":
        agent = SafeRLAgent.load(args.rl_path, state_dim=state_dim,
                                  max_cvar=args.max_cvar)
        df = backtest(signals, mc_engine, agent,
                      n_scenarios=args.n_scenarios)
        df.to_csv("backtest_mc_results.csv", index=False)
        print("Saved → backtest_mc_results.csv")


if __name__ == "__main__":
    main()
