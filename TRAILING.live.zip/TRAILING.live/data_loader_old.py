"""
data_loader.py
--------------
Fetches real VIX data from GitHub datasets.
Generates realistic synthetic signals for yield curve, credit spreads,
market breadth, and India-specific indicators — all calibrated to
reproduce real historical crisis signatures (2008, 2015, 2020, 2022).

In production, swap the synthetic generators with live API calls:
    - FRED API  → yield curve, TED spread, credit spreads
    - NSE India → FII flows, India VIX
    - yfinance  → VIX, equity indices, gold, USD
"""

import requests
import pandas as pd
import numpy as np
from io import StringIO
import warnings
warnings.filterwarnings("ignore")


# ---------------------------------------------------------------------------
# Crisis event calendar — used to inject stress into synthetic signals
# ---------------------------------------------------------------------------
CRISIS_EVENTS = {
    "2008-09-15": ("Lehman collapse",         90),
    "2008-03-17": ("Bear Stearns rescue",     60),
    "2010-05-06": ("Flash Crash",             45),
    "2011-08-05": ("US credit downgrade",     55),
    "2015-08-24": ("China flash crash",       50),
    "2016-06-24": ("Brexit vote",             40),
    "2018-12-24": ("Fed rate fears",          45),
    "2020-03-16": ("COVID crash low",         95),
    "2022-06-13": ("Rate shock / crypto",     65),
    "2023-03-10": ("SVB collapse",            50),
}

CRISIS_DATES = {pd.Timestamp(d): v for d, v in CRISIS_EVENTS.items()}


# ---------------------------------------------------------------------------
# Real data: VIX from GitHub datasets
# ---------------------------------------------------------------------------
def fetch_vix() -> pd.Series:
    url = (
        "https://raw.githubusercontent.com/datasets/finance-vix"
        "/main/data/vix-daily.csv"
    )
    resp = requests.get(url, timeout=15)
    resp.raise_for_status()
    df = pd.read_csv(StringIO(resp.text), parse_dates=["DATE"])
    df = df.set_index("DATE")["CLOSE"].rename("vix")
    df.index = pd.DatetimeIndex(df.index)
    return df.sort_index()


# ---------------------------------------------------------------------------
# Synthetic signal generators — calibrated to real crisis amplitudes
# ---------------------------------------------------------------------------
def _crisis_pulse(dates: pd.DatetimeIndex, severity: float,
                  lead_days: int = 15, decay_days: int = 30) -> np.ndarray:
    """
    Returns a pulse array that rises `lead_days` BEFORE each crisis date
    and decays over `decay_days` after. This simulates how macro signals
    typically build up before a crash and normalise slowly afterwards.
    """
    pulse = np.zeros(len(dates))
    for crisis_dt, (_, sev) in CRISIS_EVENTS.items():
        crisis_ts = pd.Timestamp(crisis_dt)
        for i, d in enumerate(dates):
            delta = (d - crisis_ts).days
            if -lead_days <= delta <= 0:
                # Build-up phase: linear ramp before crash
                pulse[i] += severity * (sev / 100) * (1 - abs(delta) / lead_days)
            elif 0 < delta <= decay_days:
                # Decay phase: exponential normalisation after crash
                pulse[i] += severity * (sev / 100) * np.exp(-delta / decay_days)
    return np.clip(pulse, 0, 1)


def generate_yield_curve(dates: pd.DatetimeIndex,
                         seed: int = 42) -> pd.Series:
    """
    10Y - 2Y US Treasury spread (percentage points).
    Normal: +1% to +2.5%
    Stressed: negative (inverted) — this is the recession signal.
    Typically inverts 6-18 months before a recession.
    """
    rng = np.random.default_rng(seed)
    n = len(dates)

    # Base: slow mean-reverting process around +1.5%
    base = np.zeros(n)
    base[0] = 1.5
    for i in range(1, n):
        base[i] = base[i-1] * 0.998 + 0.003 + rng.normal(0, 0.04)

    # Crisis: invert before each crash (yield curves invert early)
    stress = _crisis_pulse(dates, severity=2.5, lead_days=180, decay_days=120)

    spread = base - stress
    spread = pd.Series(spread, index=dates, name="yield_curve_spread")

    # 5-day smoothing (bonds don't move tick-by-tick)
    return spread.rolling(5).mean().bfill()


def generate_credit_spread(dates: pd.DatetimeIndex,
                           seed: int = 43) -> pd.Series:
    """
    High-yield corporate bond spread over Treasuries (percentage points).
    Normal: 3% - 5%
    Stressed: 8% - 20%
    Credit markets lead equities — they price in stress 2-4 weeks early.
    """
    rng = np.random.default_rng(seed)
    n = len(dates)

    base = np.zeros(n)
    base[0] = 4.0
    for i in range(1, n):
        base[i] = base[i-1] * 0.997 + 0.012 + rng.normal(0, 0.06)
        base[i] = np.clip(base[i], 2.5, 25.0)

    # Credit widens 2-3 weeks before equity crash
    stress = _crisis_pulse(dates, severity=16.0, lead_days=20, decay_days=60)

    spread = base + stress
    spread = pd.Series(spread, index=dates, name="credit_spread")
    return spread.rolling(3).mean().bfill()


def generate_ted_spread(dates: pd.DatetimeIndex,
                        seed: int = 44) -> pd.Series:
    """
    TED spread: 3-month LIBOR minus 3-month T-bill (percentage points).
    Normal: 0.1% - 0.5%
    Stressed: 1%+ (interbank lending freeze, classic liquidity crisis signal)
    Classic 2008 signal: TED spread hit 4.5% at peak.
    """
    rng = np.random.default_rng(seed)
    n = len(dates)

    base = np.zeros(n)
    base[0] = 0.25
    for i in range(1, n):
        base[i] = base[i-1] * 0.995 + 0.001 + abs(rng.normal(0, 0.02))
        base[i] = np.clip(base[i], 0.05, 5.0)

    stress = _crisis_pulse(dates, severity=3.5, lead_days=10, decay_days=45)
    spread = base + stress
    spread = pd.Series(spread, index=dates, name="ted_spread")
    return spread.rolling(3).mean().bfill()


def generate_market_breadth(dates: pd.DatetimeIndex,
                            seed: int = 45) -> pd.Series:
    """
    % of S&P 500 stocks trading above their 200-day moving average.
    Normal: 55% - 80%
    Stressed: below 30% (internal deterioration before headline index falls)
    """
    rng = np.random.default_rng(seed)
    n = len(dates)

    base = np.zeros(n)
    base[0] = 65.0
    for i in range(1, n):
        base[i] = base[i-1] * 0.999 + 0.065 + rng.normal(0, 1.2)
        base[i] = np.clip(base[i], 5.0, 95.0)

    # Breadth collapses before index (internal weakness shows first)
    stress = _crisis_pulse(dates, severity=50.0, lead_days=12, decay_days=40)

    breadth = base - stress
    breadth = pd.Series(np.clip(breadth, 5, 95), index=dates,
                        name="market_breadth")
    return breadth.rolling(5).mean().bfill()


def generate_put_call_ratio(dates: pd.DatetimeIndex,
                            seed: int = 46) -> pd.Series:
    """
    CBOE put/call ratio. Ratio of put options bought vs call options.
    Normal: 0.6 - 0.9 (more calls than puts = bullish)
    Stressed: 1.2+ (heavy put buying = hedging / fear)
    """
    rng = np.random.default_rng(seed)
    n = len(dates)

    base = np.zeros(n)
    base[0] = 0.75
    for i in range(1, n):
        base[i] = base[i-1] * 0.99 + 0.0075 + abs(rng.normal(0, 0.04))
        base[i] = np.clip(base[i], 0.3, 2.5)

    stress = _crisis_pulse(dates, severity=0.9, lead_days=8, decay_days=25)
    ratio = base + stress
    ratio = pd.Series(ratio, index=dates, name="put_call_ratio")
    return ratio.rolling(3).mean().bfill()


def generate_fii_flows(dates: pd.DatetimeIndex,
                       seed: int = 47) -> pd.Series:
    """
    Foreign Institutional Investor net flows into Indian markets
    (in ₹ crore, daily). Negative = outflow (selling).
    Normal: -500 to +1500 crore
    Stressed: -3000 to -8000 crore (FIIs flee EM first)
    """
    rng = np.random.default_rng(seed)
    n = len(dates)

    base = np.zeros(n)
    base[0] = 500.0
    for i in range(1, n):
        base[i] = base[i-1] * 0.97 + 500 * rng.normal(0.1, 0.8)
        base[i] = np.clip(base[i], -6000, 4000)

    # FIIs start selling 5-15 days before the crash is obvious
    stress = _crisis_pulse(dates, severity=6000, lead_days=12, decay_days=30)
    flows = base - stress
    flows = pd.Series(flows, index=dates, name="fii_flows")
    return flows.rolling(3).mean().bfill()


def generate_inr_usd(dates: pd.DatetimeIndex,
                     seed: int = 48) -> pd.Series:
    """
    USD/INR exchange rate (rupees per dollar).
    Normal: slow gradual depreciation ~3-5% per year
    Stressed: sharp depreciation spikes (INR weakens fast in EM crises)
    We track the 10-day rate of change (%) as the signal, not the level.
    """
    rng = np.random.default_rng(seed)
    n = len(dates)

    # Build realistic INR/USD level: starts ~45 in 2007, trends to ~84
    rate = np.zeros(n)
    rate[0] = 45.0
    for i in range(1, n):
        # Slow depreciation trend + noise
        years_elapsed = i / 252
        trend = 45.0 * (1 + 0.042) ** years_elapsed
        rate[i] = trend + rng.normal(0, 0.4)

    # Crisis: sharp depreciation episodes
    stress = _crisis_pulse(dates, severity=8.0, lead_days=5, decay_days=30)
    rate = rate + stress * np.linspace(0.5, 1.5, n)  # scale with time

    # Compute 10-day rate of change as the actual signal
    rate_series = pd.Series(rate, index=dates, name="inr_usd_roc")
    roc = rate_series.pct_change(10) * 100
    return roc.fillna(0)


def generate_india_vix(real_vix: pd.Series,
                       dates: pd.DatetimeIndex,
                       seed: int = 49) -> pd.Series:
    """
    India VIX — correlated with US VIX but with EM-specific spikes.
    India VIX is typically 15-30% higher than US VIX due to EM premium.
    """
    rng = np.random.default_rng(seed)

    # Align real VIX to our date range
    vix_aligned = real_vix.reindex(dates, method="ffill").fillna(20)

    # India VIX = 1.2x US VIX + EM premium + local noise
    em_premium = rng.normal(3.5, 1.5, len(dates))
    india_vix = vix_aligned.values * 1.2 + em_premium
    india_vix = np.clip(india_vix, 8, 100)

    return pd.Series(india_vix, index=dates, name="india_vix")


# ---------------------------------------------------------------------------
# Main loader: assemble everything into a single DataFrame
# ---------------------------------------------------------------------------
def load_all_signals(start: str = "2007-01-01",
                     end: str = "2024-01-01") -> pd.DataFrame:
    """
    Returns a DataFrame with all signals aligned to business days.
    Columns:
        vix             - CBOE VIX (real data)
        india_vix       - India VIX (synthetic, correlated to VIX)
        yield_curve_spread - 10Y-2Y spread
        credit_spread   - HY credit spread
        ted_spread      - TED spread
        market_breadth  - % stocks above 200dma
        put_call_ratio  - CBOE put/call ratio
        fii_flows       - FII net flows (₹ crore)
        inr_usd_roc     - INR/USD 10-day rate of change (%)
    """
    print("Fetching VIX data from GitHub...")
    try:
        real_vix = fetch_vix()
        print(f"  VIX: {len(real_vix)} days fetched")
    except Exception as e:
        print(f"  VIX fetch failed ({e}), using synthetic fallback")
        dates_tmp = pd.bdate_range(start, end)
        rng = np.random.default_rng(0)
        base = np.abs(rng.normal(20, 8, len(dates_tmp))) + 10
        real_vix = pd.Series(base, index=dates_tmp, name="vix")

    dates = pd.bdate_range(start, end)

    # Align VIX to our business day range
    vix = real_vix.reindex(dates, method="ffill").fillna(20)
    vix.name = "vix"

    print("Generating synthetic signals (calibrated to historical crises)...")
    signals = pd.DataFrame({
        "vix":                vix,
        "india_vix":          generate_india_vix(real_vix, dates),
        "yield_curve_spread": generate_yield_curve(dates),
        "credit_spread":      generate_credit_spread(dates),
        "ted_spread":         generate_ted_spread(dates),
        "market_breadth":     generate_market_breadth(dates),
        "put_call_ratio":     generate_put_call_ratio(dates),
        "fii_flows":          generate_fii_flows(dates),
        "inr_usd_roc":        generate_inr_usd(dates),
    })

    print(f"  Signals shape: {signals.shape}")
    print(f"  Date range: {signals.index[0].date()} → {signals.index[-1].date()}")
    return signals


if __name__ == "__main__":
    df = load_all_signals()
    print("\nFirst 3 rows:")
    print(df.head(3).to_string())
    print("\nSignal stats:")
    print(df.describe().round(2).to_string())
