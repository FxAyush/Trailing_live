"""
visualizer.py
-------------
Generates a comprehensive visual report:

  Page 1 – Stress Score vs Crisis Events (the headline chart)
  Page 2 – Category breakdown heatmap
  Page 3 – Individual signal Z-scores
  Page 4 – Portfolio protection comparison
  Page 5 – Backtest summary: detection performance per crisis
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.gridspec as gridspec
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
from typing import Dict

from signal_processor import CATEGORIES, classify_regime
from data_loader import CRISIS_EVENTS


# ---------------------------------------------------------------------------
# Colour constants
# ---------------------------------------------------------------------------
C_GREEN  = "#2d9e6b"
C_AMBER  = "#e08b25"
C_RED    = "#c94040"
C_BLUE   = "#3d7ab5"
C_DARK   = "#1a1a2e"
C_LIGHT  = "#f5f5f0"
C_GRID   = "#e0ddd8"
C_TEXT   = "#2c2c2a"
C_MUTED  = "#888780"

REGIME_COLORS = {"calm": C_GREEN, "elevated": C_AMBER, "critical": C_RED}
BG_COLOR      = "#fafaf8"


def _setup_ax(ax, title="", xlabel="", ylabel=""):
    ax.set_facecolor(BG_COLOR)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(C_GRID)
    ax.spines["bottom"].set_color(C_GRID)
    ax.tick_params(colors=C_MUTED, labelsize=9)
    ax.xaxis.label.set_color(C_MUTED)
    ax.yaxis.label.set_color(C_MUTED)
    ax.grid(axis="y", color=C_GRID, linewidth=0.5, zorder=0)
    if title:
        ax.set_title(title, color=C_TEXT, fontsize=11, fontweight="bold",
                     pad=10, loc="left")
    if xlabel:
        ax.set_xlabel(xlabel, fontsize=9)
    if ylabel:
        ax.set_ylabel(ylabel, fontsize=9)


def _add_crisis_lines(ax, index, alpha=0.6):
    """Adds vertical lines at each crisis event."""
    ymin, ymax = ax.get_ylim()
    for crisis_date, (label, _) in CRISIS_EVENTS.items():
        crisis_dt = pd.Timestamp(crisis_date)
        if crisis_dt < index[0] or crisis_dt > index[-1]:
            continue
        ax.axvline(crisis_dt, color=C_RED, linewidth=0.8,
                   linestyle="--", alpha=alpha, zorder=3)
        ax.text(crisis_dt, ymax * 0.95, label[:12],
                rotation=90, fontsize=6, color=C_RED,
                alpha=0.8, va="top", ha="right", zorder=4)


# ---------------------------------------------------------------------------
# Chart 1: Stress score over time
# ---------------------------------------------------------------------------
def plot_stress_score(ax, score: pd.Series):
    _setup_ax(ax, title="Financial stress index (0–100)", ylabel="Stress score")

    # Colour-band the background
    ax.axhspan(0,  35, color=C_GREEN, alpha=0.06, zorder=0)
    ax.axhspan(35, 65, color=C_AMBER, alpha=0.06, zorder=0)
    ax.axhspan(65, 100, color=C_RED,  alpha=0.06, zorder=0)

    # Threshold lines
    ax.axhline(35, color=C_AMBER, linewidth=0.8, linestyle=":", alpha=0.6)
    ax.axhline(65, color=C_RED,   linewidth=0.8, linestyle=":", alpha=0.6)
    ax.text(score.index[5], 36, "Elevated threshold (35)", color=C_AMBER,
            fontsize=7, va="bottom")
    ax.text(score.index[5], 66, "Critical threshold (65)", color=C_RED,
            fontsize=7, va="bottom")

    # Score line — colour by regime
    dates = score.index
    values = score.values

    for i in range(1, len(values)):
        regime, color, _ = classify_regime(values[i])
        ax.plot(dates[i-1:i+1], values[i-1:i+1],
                color=REGIME_COLORS[regime], linewidth=1.2, alpha=0.85)

    ax.set_ylim(0, 105)
    ax.set_xlim(dates[0], dates[-1])
    _add_crisis_lines(ax, dates)

    # Legend
    patches = [
        mpatches.Patch(color=C_GREEN, alpha=0.7, label="Calm (<35)"),
        mpatches.Patch(color=C_AMBER, alpha=0.7, label="Elevated (35-65)"),
        mpatches.Patch(color=C_RED,   alpha=0.7, label="Critical (>65)"),
        Line2D([0], [0], color=C_RED, linewidth=0.8, linestyle="--",
               alpha=0.7, label="Crisis event"),
    ]
    ax.legend(handles=patches, loc="upper left", fontsize=8,
              framealpha=0.9, edgecolor=C_GRID)


# ---------------------------------------------------------------------------
# Chart 2: Category heatmap
# ---------------------------------------------------------------------------
def plot_category_heatmap(ax, cat_df: pd.DataFrame):
    _setup_ax(ax, title="Category stress levels over time")

    cat_names = list(CATEGORIES.keys())
    labels    = [CATEGORIES[c]["label"] for c in cat_names]

    # Resample to weekly to reduce visual noise
    weekly = cat_df[cat_names].resample("W").mean()

    # Plot as filled area stacked
    colors = [C_RED, C_AMBER, C_BLUE, C_GREEN]
    for i, (col, label, color) in enumerate(
        zip(cat_names, labels, colors)
    ):
        if col not in weekly.columns:
            continue
        vals = weekly[col].clip(-2, 4)
        ax.plot(weekly.index, vals, color=color, linewidth=1.2,
                label=label, alpha=0.9)
        ax.fill_between(weekly.index, 0, vals.clip(0),
                        color=color, alpha=0.10)

    ax.axhline(0, color=C_MUTED, linewidth=0.5)
    ax.axhline(1.5, color=C_MUTED, linewidth=0.5, linestyle=":")
    ax.text(weekly.index[5], 1.6, "Stress Z > 1.5", color=C_MUTED, fontsize=7)
    ax.set_ylabel("Z-score", fontsize=9)
    ax.set_xlim(weekly.index[0], weekly.index[-1])
    ax.set_ylim(-2.5, 4.5)
    ax.legend(fontsize=8, loc="upper left", framealpha=0.9, edgecolor=C_GRID)
    _add_crisis_lines(ax, weekly.index, alpha=0.4)


# ---------------------------------------------------------------------------
# Chart 3: Individual signal Z-scores
# ---------------------------------------------------------------------------
def plot_signal_zscores(axes, z_df: pd.DataFrame):
    """Plots 6 key signals in a 2x3 grid of sub-axes."""
    signals = [
        ("vix",              "VIX (fear gauge)"),
        ("credit_spread",    "Credit spread"),
        ("yield_curve_spread","Yield curve spread"),
        ("ted_spread",       "TED spread"),
        ("market_breadth",   "Market breadth"),
        ("fii_flows",        "FII flows (India)"),
    ]

    # Resample to weekly
    weekly = z_df.resample("W").mean()

    for ax, (col, label) in zip(axes.flat, signals):
        _setup_ax(ax, title=label, ylabel="Z-score")
        if col not in weekly.columns:
            ax.text(0.5, 0.5, "No data", transform=ax.transAxes,
                    ha="center", va="center", color=C_MUTED)
            continue

        vals = weekly[col]
        ax.fill_between(weekly.index, 0, vals.clip(0),
                        color=C_RED, alpha=0.25, zorder=1)
        ax.fill_between(weekly.index, vals.clip(upper=0), 0,
                        color=C_BLUE, alpha=0.20, zorder=1)
        ax.plot(weekly.index, vals, color=C_DARK, linewidth=0.8, zorder=2)
        ax.axhline(0,   color=C_MUTED, linewidth=0.5)
        ax.axhline(1.5, color=C_AMBER, linewidth=0.5, linestyle=":")
        ax.axhline(2.5, color=C_RED,   linewidth=0.5, linestyle=":")
        ax.set_ylim(-3, 4.5)
        ax.set_xlim(weekly.index[0], weekly.index[-1])
        ax.tick_params(axis="x", labelrotation=30, labelsize=7)
        _add_crisis_lines(ax, weekly.index, alpha=0.35)


# ---------------------------------------------------------------------------
# Chart 4: Portfolio protection
# ---------------------------------------------------------------------------
def plot_portfolio_comparison(ax, portfolio: Dict):
    _setup_ax(ax, title="Portfolio protection: strategy vs benchmark",
              ylabel="Portfolio value (started at 100)")

    bench    = portfolio["benchmark_cumulative"]
    strategy = portfolio["strategy_cumulative"]
    eq_wt    = portfolio["equity_weight_series"]

    # Shade equity weight reduction on secondary axis
    ax2 = ax.twinx()
    eq_weekly = eq_wt.resample("W").mean()
    ax2.fill_between(eq_weekly.index, 0, eq_weekly * 100,
                     color=C_BLUE, alpha=0.08, zorder=0)
    ax2.set_ylim(0, 200)
    ax2.set_ylabel("Equity allocation %", fontsize=8, color=C_BLUE)
    ax2.tick_params(colors=C_BLUE, labelsize=8)
    ax2.spines["right"].set_color(C_BLUE)

    # Portfolio lines
    bench_w    = bench.resample("W").last()
    strategy_w = strategy.resample("W").last()

    ax.plot(bench_w.index, bench_w.values, color=C_MUTED, linewidth=1.5,
            label=f"Benchmark 80/20 (final: {portfolio['benchmark_final']:.0f})",
            zorder=3)
    ax.plot(strategy_w.index, strategy_w.values, color=C_GREEN, linewidth=1.5,
            label=f"Dynamic strategy (final: {portfolio['strategy_final']:.0f})",
            zorder=3)

    ax.set_xlim(bench_w.index[0], bench_w.index[-1])
    _add_crisis_lines(ax, bench_w.index, alpha=0.35)

    # Stats box
    stats_text = (
        f"Strategy ann. return: {portfolio['strategy_annualised_pct']:.1f}%\n"
        f"Benchmark ann. return: {portfolio['benchmark_annualised_pct']:.1f}%\n"
        f"Strategy max drawdown: {portfolio['strategy_max_drawdown_pct']:.1f}%\n"
        f"Benchmark max drawdown: {portfolio['benchmark_max_drawdown_pct']:.1f}%\n"
        f"Strategy Sharpe: {portfolio['strategy_sharpe']:.2f}\n"
        f"Benchmark Sharpe: {portfolio['benchmark_sharpe']:.2f}"
    )
    ax.text(0.98, 0.05, stats_text, transform=ax.transAxes,
            fontsize=8, va="bottom", ha="right", color=C_TEXT,
            bbox=dict(facecolor="white", edgecolor=C_GRID, alpha=0.9,
                      boxstyle="round,pad=0.4"))

    ax.legend(loc="upper left", fontsize=9, framealpha=0.9, edgecolor=C_GRID)


# ---------------------------------------------------------------------------
# Chart 5: Backtest results bar chart
# ---------------------------------------------------------------------------
def plot_backtest_results(ax, backtest: Dict):
    _setup_ax(ax, title="Crisis detection: days of early warning per event",
              ylabel="Days of early warning")

    crises = [r for r in backtest["per_crisis"]
              if not np.isnan(r.get("days_warning", np.nan))]

    labels    = [r["crisis"][:20] for r in crises]
    warnings  = [r["days_warning"] for r in crises]
    detected  = [r["warning_given"] for r in crises]
    colors    = [C_GREEN if d else C_RED for d in detected]

    x = np.arange(len(labels))
    bars = ax.bar(x, warnings, color=colors, alpha=0.8, width=0.6, zorder=2)

    # Detection threshold line
    ax.axhline(10, color=C_AMBER, linewidth=1, linestyle="--", alpha=0.7,
               label="10-day target")

    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=35, ha="right", fontsize=8)
    ax.set_ylim(0, max(warnings + [12]) * 1.2 if warnings else 30)

    # Annotate bars
    for bar, w in zip(bars, warnings):
        if w > 0:
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
                    f"{w}d", ha="center", va="bottom", fontsize=8, color=C_TEXT)

    # Summary text
    s = backtest["summary"]
    summary = (
        f"Detection rate: {s['detection_rate_pct']:.0f}%  |  "
        f"Avg warning: {s['avg_days_warning']:.0f} days  |  "
        f"False positive rate: {s['false_positive_rate']:.1f}%"
    )
    ax.set_title(ax.get_title(), color=C_TEXT, fontsize=11,
                 fontweight="bold", pad=10, loc="left")
    ax.text(0.5, -0.28, summary, transform=ax.transAxes,
            ha="center", fontsize=9, color=C_MUTED)

    patches = [
        mpatches.Patch(color=C_GREEN, label="Detected"),
        mpatches.Patch(color=C_RED,   label="Not detected"),
        Line2D([0], [0], color=C_AMBER, linewidth=1, linestyle="--",
               label="10-day target"),
    ]
    ax.legend(handles=patches, fontsize=8, loc="upper right",
              framealpha=0.9, edgecolor=C_GRID)


# ---------------------------------------------------------------------------
# Master report generator
# ---------------------------------------------------------------------------
def generate_full_report(results: Dict,
                         backtest: Dict,
                         portfolio: Dict,
                         output_path: str = "crisis_detection_report.pdf"):
    """
    Generates a 3-page PDF report.
    """
    from matplotlib.backends.backend_pdf import PdfPages

    print(f"\nGenerating report → {output_path}")

    with PdfPages(output_path) as pdf:

        # ---- Page 1: Stress score + category breakdown ----
        fig = plt.figure(figsize=(14, 10), facecolor=BG_COLOR)
        fig.suptitle("Financial Stress Index — Crisis Detection System",
                     fontsize=16, color=C_TEXT, fontweight="bold", y=0.98)

        gs = gridspec.GridSpec(2, 1, figure=fig, hspace=0.45,
                               top=0.93, bottom=0.07)
        ax1 = fig.add_subplot(gs[0])
        ax2 = fig.add_subplot(gs[1])

        plot_stress_score(ax1, results["score"])
        plot_category_heatmap(ax2, results["categories"])

        pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)
        print("  Page 1: Stress score + category breakdown ✓")

        # ---- Page 2: Individual signal Z-scores ----
        fig, axes = plt.subplots(2, 3, figsize=(14, 8),
                                 facecolor=BG_COLOR)
        fig.suptitle("Individual Signal Z-Scores",
                     fontsize=14, color=C_TEXT, fontweight="bold")
        fig.patch.set_facecolor(BG_COLOR)
        plt.subplots_adjust(hspace=0.55, wspace=0.35,
                            top=0.92, bottom=0.1)

        plot_signal_zscores(axes, results["z_scores"])

        pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)
        print("  Page 2: Signal Z-scores ✓")

        # ---- Page 3: Portfolio + backtest ----
        fig = plt.figure(figsize=(14, 10), facecolor=BG_COLOR)
        fig.suptitle("Backtest Results & Portfolio Protection",
                     fontsize=14, color=C_TEXT, fontweight="bold", y=0.98)

        gs = gridspec.GridSpec(2, 1, figure=fig, hspace=0.6,
                               top=0.93, bottom=0.12)
        ax3 = fig.add_subplot(gs[0])
        ax4 = fig.add_subplot(gs[1])

        plot_portfolio_comparison(ax3, portfolio)
        plot_backtest_results(ax4, backtest)

        pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)
        print("  Page 3: Portfolio + backtest ✓")

    print(f"  Report saved to {output_path}")
    return output_path


if __name__ == "__main__":
    from data_loader import load_all_signals
    from signal_processor import run_full_pipeline
    from backtester import run_full_backtest, compute_portfolio_protection

    df        = load_all_signals()
    results   = run_full_pipeline(df)
    backtest  = run_full_backtest(results["score"])
    portfolio = compute_portfolio_protection(results["score"])

    generate_full_report(results, backtest, portfolio,
                         "crisis_detection_report.pdf")
