"""
alpha_agent.py
--------------
Layer 3 — LLM-powered research agent.

Uses Claude (via Anthropic API) to:
  1. Read today's news signals + macro data
  2. Reason about geopolitical implications
  3. Identify sector-specific opportunities
  4. Generate investment thesis with confidence
  5. Produce CRASH_WARNING or BUY_OPPORTUNITY signals

This is the "brain" that connects:
  - What's happening in the world (news layer)
  - What macro signals say (stress index)
  - What it means for specific assets (reasoning)
  - What action to take (portfolio signal)

Usage:
  agent = AlphaResearchAgent()
  result = agent.research(news_data, macro_data, stress_score)
  print(result["thesis"])
  print(result["signals"])
"""

import json
import requests
import os
import sys
import numpy as np
import pandas as pd
from datetime import datetime
from typing import Dict, List
import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


# ---------------------------------------------------------------------------
# Sector opportunity detector (rule-based, fast, no API needed)
# ---------------------------------------------------------------------------

SECTOR_SIGNALS = {
    "ai_semiconductor": {
        "keywords": ["nvidia", "tsmc", "amd", "ai chip", "gpu",
                     "semiconductor", "data center", "llm", "openai",
                     "anthropic", "gemini", "inference"],
        "affected_assets": ["us_equity", "indian_equity"],
        "thesis_template": (
            "AI semiconductor demand signal. Companies building AI "
            "infrastructure need chips → NVIDIA/TSMC revenue grows → "
            "Indian IT companies (TCS, Infosys) benefit from AI services "
            "demand. Consider increasing us_equity and indian_equity."
        ),
        "signal": "BUY",
        "strength": 8,
    },
    "india_manufacturing": {
        "keywords": ["pli scheme", "make in india", "apple india",
                     "samsung india", "manufacturing", "fdi india",
                     "capex india", "infrastructure india"],
        "affected_assets": ["indian_equity", "bonds_india"],
        "thesis_template": (
            "India manufacturing opportunity. FDI inflows and PLI scheme "
            "driving domestic manufacturing growth. Historically leads to "
            "Nifty outperformance over 6-12 months."
        ),
        "signal": "BUY",
        "strength": 7,
    },
    "energy_crisis": {
        "keywords": ["oil price", "opec", "crude", "energy crisis",
                     "petroleum", "oil embargo", "oil spike"],
        "affected_assets": ["commodities", "gold", "indian_equity"],
        "thesis_template": (
            "Energy price shock detected. Rising oil hurts India (net importer) "
            "→ widens CAD → weakens INR → FII outflows → Nifty falls. "
            "Reduce indian_equity, increase gold and commodities."
        ),
        "signal": "CRASH_WARNING",
        "strength": 8,
    },
    "rate_cycle_turn": {
        "keywords": ["fed cut", "rate cut", "pivot", "dovish fed",
                     "interest rate cut", "fed pause", "disinflation"],
        "affected_assets": ["us_equity", "emerging_markets",
                           "bonds_us", "indian_equity"],
        "thesis_template": (
            "Fed rate cut cycle signal. Rate cuts → risk-on globally → "
            "EM markets including India re-rate higher. "
            "Increase emerging_markets and us_equity allocation."
        ),
        "signal": "BUY",
        "strength": 9,
    },
    "china_risk": {
        "keywords": ["china slowdown", "china property", "evergrande",
                     "china recession", "yuan devaluation", "china crackdown"],
        "affected_assets": ["emerging_markets", "commodities"],
        "thesis_template": (
            "China economic stress detected. China slowdown → commodity "
            "demand falls → EM selloff → India may benefit relatively "
            "but global risk-off hurts short term. Reduce emerging_markets."
        ),
        "signal": "CRASH_WARNING",
        "strength": 7,
    },
    "india_election": {
        "keywords": ["india election", "modi", "bjp", "opposition win",
                     "election result india", "budget india"],
        "affected_assets": ["indian_equity", "bonds_india"],
        "thesis_template": (
            "India political event detected. Market typically rallies on "
            "political stability. Monitor outcome — continuity positive "
            "for indian_equity, uncertainty negative short-term."
        ),
        "signal": "MONITOR",
        "strength": 6,
    },
    "crypto_catalyst": {
        "keywords": ["bitcoin etf", "crypto regulation", "bitcoin halving",
                     "institutional crypto", "blackrock bitcoin"],
        "affected_assets": ["crypto"],
        "thesis_template": (
            "Crypto catalyst detected. Institutional adoption or "
            "regulatory clarity historically drives 30-60 day rallies. "
            "Consider small crypto allocation increase within CVaR limits."
        ),
        "signal": "BUY",
        "strength": 6,
    },
}

# Geopolitical → market impact mapping
GEO_MARKET_IMPACT = {
    "israel": {
        "primary":   ["commodities", "gold"],
        "secondary": ["indian_equity", "emerging_markets"],
        "crash_weight": 0.8,
        "rationale": (
            "Israel-Iran conflict → Strait of Hormuz risk → oil spike "
            "→ India inflation → RBI holds rates → markets fall. "
            "Gold and commodities benefit as safe havens."
        ),
    },
    "iran": {
        "primary":   ["commodities", "gold"],
        "secondary": ["indian_equity", "bonds_india"],
        "crash_weight": 0.8,
        "rationale": (
            "Iran tensions → oil supply disruption risk → "
            "global inflation pressure → EM selloff. Increase gold."
        ),
    },
    "russia": {
        "primary":   ["commodities", "gold"],
        "secondary": ["emerging_markets"],
        "crash_weight": 0.6,
        "rationale": (
            "Russia conflict → energy price pressure → "
            "European recession risk → global risk-off."
        ),
    },
    "china": {
        "primary":   ["emerging_markets"],
        "secondary": ["us_equity", "commodities"],
        "crash_weight": 0.7,
        "rationale": (
            "China risk → global supply chain disruption → "
            "tech sector impact → EM contagion risk."
        ),
    },
    "taiwan": {
        "primary":   ["us_equity", "emerging_markets"],
        "secondary": ["crypto"],
        "crash_weight": 0.9,
        "rationale": (
            "Taiwan risk → semiconductor supply shock → "
            "global tech recession → worst-case scenario for markets."
        ),
    },
    "pakistan": {
        "primary":   ["indian_equity"],
        "secondary": ["bonds_india"],
        "crash_weight": 0.5,
        "rationale": (
            "India-Pakistan tensions → Indian market uncertainty → "
            "FII caution. Impact localised to Indian assets."
        ),
    },
}


# ---------------------------------------------------------------------------
# Rule-based alpha engine (works without any API)
# ---------------------------------------------------------------------------
class RuleBasedAlphaEngine:
    """
    Fast rule-based alpha signal generator.
    Processes news aggregate + macro data to produce signals.
    No API key needed — works offline.
    """

    def analyse(self, news_data: Dict,
                stress_score: float,
                macro_signals: Dict = None) -> Dict:
        """
        Produce alpha signals from news + macro data.

        Returns:
            signals:       list of BUY/SELL signals with confidence
            crash_prob:    0-1 combined crash probability
            buy_prob:      0-1 combined opportunity probability
            thesis:        plain-language investment thesis
            allocation_hint: suggested allocation changes
        """
        signals       = []
        crash_factors = []
        buy_factors   = []

        # 1. Process geopolitical signals
        for hotspot in news_data.get("active_hotspots", []):
            if hotspot in GEO_MARKET_IMPACT:
                impact = GEO_MARKET_IMPACT[hotspot]
                crash_factors.append({
                    "source":     f"geopolitical_{hotspot}",
                    "weight":     impact["crash_weight"],
                    "assets":     impact["primary"] + impact["secondary"],
                    "rationale":  impact["rationale"],
                })
                signals.append({
                    "type":       "CRASH_WARNING",
                    "source":     f"Geopolitical: {hotspot.title()}",
                    "confidence": impact["crash_weight"],
                    "assets":     impact["primary"],
                    "rationale":  impact["rationale"],
                })

        # 2. Process sector keywords from top stories
        all_text = " ".join([
            s.get("title", "") + " " + s.get("thesis", "")
            for s in (news_data.get("top_crash_stories", []) +
                      news_data.get("top_buy_stories", []))
        ]).lower()

        for sector, info in SECTOR_SIGNALS.items():
            hit_count = sum(1 for kw in info["keywords"] if kw in all_text)
            if hit_count >= 2:
                confidence = min(hit_count / len(info["keywords"]) * 2, 1.0)
                confidence *= info["strength"] / 10

                if info["signal"] == "BUY":
                    buy_factors.append({
                        "source":    sector,
                        "weight":    confidence,
                        "assets":    info["affected_assets"],
                        "rationale": info["thesis_template"],
                    })
                    signals.append({
                        "type":       "BUY_OPPORTUNITY",
                        "source":     f"Sector: {sector.replace('_',' ').title()}",
                        "confidence": confidence,
                        "assets":     info["affected_assets"],
                        "rationale":  info["thesis_template"],
                    })
                elif info["signal"] == "CRASH_WARNING":
                    crash_factors.append({
                        "source":    sector,
                        "weight":    confidence,
                        "assets":    info["affected_assets"],
                        "rationale": info["thesis_template"],
                    })
                    signals.append({
                        "type":       "CRASH_WARNING",
                        "source":     f"Sector: {sector.replace('_',' ').title()}",
                        "confidence": confidence,
                        "assets":     info["affected_assets"],
                        "rationale":  info["thesis_template"],
                    })

        # 3. Incorporate news aggregate scores
        news_crash = news_data.get("crash_signal", 0) / 100
        news_buy   = news_data.get("buy_signal",   0) / 100
        geo_risk   = news_data.get("geo_risk_score",0) / 100

        crash_factors.append({"source": "news_aggregate",
                              "weight": news_crash, "assets": [], "rationale": ""})
        buy_factors.append(  {"source": "news_aggregate",
                              "weight": news_buy,   "assets": [], "rationale": ""})

        # 4. Macro stress incorporation
        stress_factor = stress_score / 100
        crash_factors.append({"source": "macro_stress",
                              "weight": stress_factor * 0.5,
                              "assets": [], "rationale": ""})

        # 5. Combined probabilities
        crash_weights = [f["weight"] for f in crash_factors if f["weight"] > 0]
        buy_weights   = [f["weight"] for f in buy_factors   if f["weight"] > 0]

        crash_prob = float(np.mean(crash_weights)) if crash_weights else 0.0
        buy_prob   = float(np.mean(buy_weights))   if buy_weights   else 0.0

        # Normalise to 0-1
        crash_prob = float(np.clip(crash_prob, 0, 1))
        buy_prob   = float(np.clip(buy_prob * (1 - crash_prob * 0.5), 0, 1))

        # 6. Generate allocation hints
        allocation_hint = self._build_allocation_hint(
            signals, crash_prob, buy_prob, stress_score
        )

        # 7. Build master thesis
        thesis = self._build_thesis(
            signals, crash_prob, buy_prob,
            news_data, stress_score
        )

        return {
            "timestamp":       datetime.now().isoformat(),
            "crash_prob":      round(crash_prob, 3),
            "buy_prob":        round(buy_prob, 3),
            "geo_risk":        round(geo_risk, 3),
            "signals":         signals,
            "crash_factors":   crash_factors,
            "buy_factors":     buy_factors,
            "allocation_hint": allocation_hint,
            "thesis":          thesis,
            "stress_score":    stress_score,
            "n_signals":       len(signals),
        }

    def _build_allocation_hint(self, signals: List[Dict],
                                crash_prob: float,
                                buy_prob: float,
                                stress_score: float) -> Dict:
        """Build a suggested allocation adjustment."""

        # Assets to increase/decrease
        increase = {}
        decrease = {}

        for sig in signals:
            if sig["type"] == "BUY_OPPORTUNITY":
                for asset in sig["assets"]:
                    increase[asset] = increase.get(asset, 0) + sig["confidence"]
            elif sig["type"] == "CRASH_WARNING":
                for asset in sig["assets"]:
                    decrease[asset] = decrease.get(asset, 0) + sig["confidence"]

        # Safe haven assets increase in high crash scenarios
        if crash_prob > 0.5:
            increase["gold"]       = increase.get("gold",      0) + crash_prob
            increase["bonds_us"]   = increase.get("bonds_us",  0) + crash_prob * 0.7
            increase["cash"]       = increase.get("cash",      0) + crash_prob * 0.5

        # Normalise
        def norm(d):
            total = sum(d.values()) + 1e-8
            return {k: round(v/total, 2) for k, v in
                    sorted(d.items(), key=lambda x: -x[1])[:5]}

        return {
            "increase": norm(increase) if increase else {},
            "decrease": norm(decrease) if decrease else {},
            "action":   ("DEFENSIVE" if crash_prob > 0.5
                         else "OPPORTUNISTIC" if buy_prob > 0.5
                         else "HOLD"),
        }

    def _build_thesis(self, signals: List[Dict],
                       crash_prob: float, buy_prob: float,
                       news_data: Dict, stress_score: float) -> str:
        """Build a master investment thesis."""
        lines = []

        hotspots = news_data.get("active_hotspots", [])
        if hotspots:
            lines.append(
                f"GEOPOLITICAL ALERT: Active hotspots detected — "
                f"{', '.join(h.title() for h in hotspots)}."
            )

        if crash_prob > 0.6:
            lines.append(
                f"HIGH CRASH RISK ({crash_prob*100:.0f}%): Multiple crash "
                f"signals converging. Macro stress at {stress_score:.0f}/100. "
                f"Recommend defensive positioning."
            )
        elif crash_prob > 0.35:
            lines.append(
                f"ELEVATED RISK ({crash_prob*100:.0f}%): Stress building. "
                f"Maintain defensive tilt, reduce high-beta exposure."
            )

        if buy_prob > 0.5:
            buy_sigs = [s for s in signals if s["type"] == "BUY_OPPORTUNITY"]
            top_assets = list(set(
                a for s in buy_sigs for a in s["assets"]
            ))[:3]
            lines.append(
                f"OPPORTUNITY ({buy_prob*100:.0f}%): "
                f"Positive signals in {', '.join(top_assets)}. "
                f"Consider selective accumulation within CVaR limits."
            )

        crash_sigs = [s for s in signals if s["type"] == "CRASH_WARNING"]
        buy_sigs   = [s for s in signals if s["type"] == "BUY_OPPORTUNITY"]

        if crash_sigs:
            lines.append(
                f"Top crash driver: {crash_sigs[0]['source']} — "
                f"{crash_sigs[0]['rationale'][:100]}"
            )
        if buy_sigs:
            lines.append(
                f"Top opportunity: {buy_sigs[0]['source']} — "
                f"{buy_sigs[0]['rationale'][:100]}"
            )

        if not lines:
            lines.append(
                "No strong directional signal. Markets in neutral zone. "
                "Maintain current allocation."
            )

        return " | ".join(lines)


# ---------------------------------------------------------------------------
# LLM-powered agent (uses Claude API for deeper reasoning)
# ---------------------------------------------------------------------------
class LLMAlphaAgent:
    """
    Uses Claude API to generate deep investment research.
    Falls back to rule-based engine if API unavailable.

    To use: your Claude API key is automatically injected
    when running inside claude.ai artifacts.
    """

    def __init__(self):
        self.rule_engine = RuleBasedAlphaEngine()
        self.api_url     = "https://api.anthropic.com/v1/messages"

    def _call_claude(self, prompt: str) -> str:
        """Call Claude API for deep reasoning."""
        try:
            response = requests.post(
                self.api_url,
                headers={"Content-Type": "application/json"},
                json={
                    "model": "claude-sonnet-4-20250514",
                    "max_tokens": 1000,
                    "system": (
                        "You are a senior quantitative analyst and macro "
                        "researcher. Analyse market signals and generate "
                        "precise, actionable investment insights. "
                        "Be specific about asset classes, time horizons, "
                        "and confidence levels. Never give generic advice."
                    ),
                    "messages": [{"role": "user", "content": prompt}],
                },
                timeout=30,
            )
            if response.status_code == 200:
                data = response.json()
                return data["content"][0]["text"]
        except Exception:
            pass
        return None

    def research(self, news_data: Dict,
                 stress_score: float,
                 macro_signals: Dict = None) -> Dict:
        """
        Full research pipeline with LLM reasoning.
        Falls back to rule-based if LLM unavailable.
        """
        # Always run rule-based first
        rule_result = self.rule_engine.analyse(
            news_data, stress_score, macro_signals
        )

        # Try LLM enhancement
        hotspots  = news_data.get("active_hotspots", [])
        top_crash = news_data.get("top_crash_stories", [])[:2]
        top_buy   = news_data.get("top_buy_stories",   [])[:2]

        prompt = f"""
Today's market intelligence summary:

MACRO STRESS INDEX: {stress_score:.1f}/100
CRASH SIGNAL: {news_data.get('crash_signal', 0):.1f}/100
BUY SIGNAL: {news_data.get('buy_signal', 0):.1f}/100
ACTIVE GEOPOLITICAL HOTSPOTS: {', '.join(hotspots) if hotspots else 'None'}
AVERAGE MARKET SENTIMENT: {news_data.get('avg_sentiment', 0):+.3f}

TOP CRASH WARNING STORIES:
{chr(10).join(f"- {s['title']}: {s['thesis'][:80]}" for s in top_crash) or "None"}

TOP BUY OPPORTUNITY STORIES:
{chr(10).join(f"- {s['title']}: {s['thesis'][:80]}" for s in top_buy) or "None"}

Based on this data, provide:
1. PRIMARY SIGNAL: CRASH_WARNING or BUY_OPPORTUNITY or NEUTRAL
2. CONFIDENCE: 0-100%
3. TIME HORIZON: days until signal plays out
4. TOP 3 ASSETS TO INCREASE allocation in
5. TOP 3 ASSETS TO DECREASE allocation in
6. ONE-PARAGRAPH THESIS explaining the trade

Format as JSON with keys: signal, confidence, horizon_days, 
increase_assets, decrease_assets, thesis
"""

        llm_response = self._call_claude(prompt)
        llm_result   = None

        if llm_response:
            try:
                # Extract JSON from response
                import re
                json_match = re.search(r'\{.*\}', llm_response,
                                      re.DOTALL)
                if json_match:
                    llm_result = json.loads(json_match.group())
            except Exception:
                pass

        # Merge rule-based + LLM results
        if llm_result:
            rule_result["llm_signal"]     = llm_result.get("signal")
            rule_result["llm_confidence"] = llm_result.get("confidence")
            rule_result["llm_horizon"]    = llm_result.get("horizon_days")
            rule_result["llm_thesis"]     = llm_result.get("thesis")
            rule_result["llm_increase"]   = llm_result.get("increase_assets", [])
            rule_result["llm_decrease"]   = llm_result.get("decrease_assets", [])
            rule_result["enhanced"]       = True

            # Override thesis with LLM version if available
            if llm_result.get("thesis"):
                rule_result["thesis"] = (
                    f"[AI RESEARCH] {llm_result['thesis']}"
                )
        else:
            rule_result["enhanced"] = False

        return rule_result


# ---------------------------------------------------------------------------
# Standalone run
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    from news_fetcher import run_news_pipeline

    print("="*55)
    print("  ALPHA RESEARCH AGENT")
    print("="*55)

    print("\n[1] Running news pipeline...")
    news_data = run_news_pipeline()

    print("\n[2] Running alpha agent...")
    agent  = LLMAlphaAgent()
    result = agent.research(news_data, stress_score=69.7)

    print(f"\n  ALPHA SIGNALS GENERATED: {result['n_signals']}")
    print(f"  Crash probability:  {result['crash_prob']*100:.1f}%")
    print(f"  Buy probability:    {result['buy_prob']*100:.1f}%")
    print(f"  Geo risk:           {result['geo_risk']*100:.1f}%")
    print(f"  LLM enhanced:       {result['enhanced']}")

    print(f"\n  THESIS:")
    print(f"  {result['thesis']}")

    hint = result["allocation_hint"]
    print(f"\n  ALLOCATION HINTS ({hint['action']}):")
    if hint["increase"]:
        print(f"  Increase: {hint['increase']}")
    if hint["decrease"]:
        print(f"  Decrease: {hint['decrease']}")

    if result["signals"]:
        print(f"\n  INDIVIDUAL SIGNALS:")
        for s in result["signals"][:4]:
            icon = "🔴" if s["type"] == "CRASH_WARNING" else "🟢"
            print(f"  {icon} [{s['confidence']*100:.0f}%] "
                  f"{s['source']}: {s['rationale'][:70]}")
