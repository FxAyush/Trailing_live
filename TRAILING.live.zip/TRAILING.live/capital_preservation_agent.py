"""
capital_preservation_agent.py
------------------------------
AGENT 4: Capital Preservation Agent

This agent has VETO POWER over every other agent in the system.
It is deliberately simple, deterministic, and rule-based — not
machine-learned — because the one thing you never want to be
probabilistic about is "should we protect the user's capital right now."

Architecture position: this agent runs LAST, after Regime, Risk, and
FinRL have all produced their inputs. It takes the FinRL agent's
proposed allocation and either approves it unchanged, or overrides it
according to hard-coded rules that cannot be argued with by an LLM,
cannot be "confidence-weighted" away, and cannot silently degrade.

The rules implemented (exactly as specified):

  Portfolio drawdown > 12%        → reduce exposure by 30%
  Volatility spike                 → increase cash allocation
  Market crash detected (CRISIS)   → move 50% to Gold ETF

Plus additional rules that follow the same philosophy:

  Turbulence index > 95th pctile   → force minimum cash floor
  Correlation spike detected       → reduce all equity by 20%
  Drawdown > 20% (severe)          → reduce exposure by 50%
  OOD flagged by FinRL agent       → cap equity_growth at 10%

These rules compose: if multiple trigger, the MOST conservative
adjustment wins (we always err toward more protection, never less).
"""

import numpy as np
from typing import Dict, List, Tuple
from dataclasses import dataclass, field
import warnings
warnings.filterwarnings("ignore")

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from finrl_agent import ASSET_CLASSES


@dataclass
class PreservationVerdict:
    input_allocation:    Dict[str, float]
    final_allocation:     Dict[str, float]
    rules_triggered:       List[str]
    override_applied:      bool
    total_equity_before:    float
    total_equity_after:     float
    cash_before:             float
    cash_after:              float
    severity:                str    # NONE / MODERATE / SEVERE / CRITICAL


class CapitalPreservationAgent:
    """
    Deterministic rule engine. No learning, no LLM, no probabilistic
    reasoning. Every rule is auditable and explainable in one sentence.

    This is intentional design philosophy: in a system with multiple
    AI agents that could each individually fail or hallucinate, you
    need ONE component that is provably correct by construction —
    a simple if/then rule book that a compliance officer (or SEBI)
    can read in five minutes and verify.
    """

    # ── Rule thresholds (tunable, but changes should be logged/audited) ──
    DRAWDOWN_MODERATE_PCT   = -12.0   # triggers 30% exposure reduction
    DRAWDOWN_SEVERE_PCT     = -20.0   # triggers 50% exposure reduction
    VOL_SPIKE_THRESHOLD     = 0.32    # annualised vol that counts as "spike"
    TURBULENCE_PCTILE_CAP   = 95.0    # turbulence percentile that forces cash floor
    MIN_CASH_ON_TURBULENCE  = 0.25    # minimum cash if turbulence extreme
    CRISIS_GOLD_TARGET      = 0.50    # gold allocation forced during CRISIS regime

    def __init__(self):
        self.audit_log: List[Dict] = []

    def evaluate(self, proposed_allocation: Dict[str, float],
                regime: str,
                drawdown_pct: float,
                volatility_annualized: float,
                turbulence_percentile: float,
                correlation_spike: bool,
                is_ood: bool) -> PreservationVerdict:
        """
        Take the FinRL agent's proposed allocation and apply hard
        capital-preservation rules. Returns the final, protected
        allocation along with a full audit trail of what fired.

        Args:
            proposed_allocation: dict of asset -> weight from FinRL agent
            regime:              current regime classification (Agent 1)
            drawdown_pct:        current portfolio drawdown (negative %)
            volatility_annualized: current realized volatility
            turbulence_percentile: turbulence index percentile (Agent 2)
            correlation_spike:    bool, correlation breakdown detected (Agent 2)
            is_ood:               bool, FinRL flagged out-of-distribution

        Returns:
            PreservationVerdict with final allocation and full audit trail
        """
        allocation = {k: float(v) for k, v in proposed_allocation.items()}
        rules_triggered: List[str] = []

        equity_keys = [k for k in allocation if "equity" in k]
        equity_before = sum(allocation.get(k, 0) for k in equity_keys)
        cash_before   = allocation.get("cash", 0)

        # ── RULE 1: Portfolio drawdown > 12% → reduce exposure by 30% ──
        if drawdown_pct <= self.DRAWDOWN_MODERATE_PCT:
            allocation = self._reduce_equity_exposure(allocation, 0.30)
            rules_triggered.append(
                f"Drawdown {drawdown_pct:.1f}% exceeds -12% threshold "
                f"→ reduced equity exposure by 30%"
            )

        # ── RULE 1b: Severe drawdown > 20% → reduce exposure by 50% ──
        # (overrides rule 1 if both fire — more conservative wins)
        if drawdown_pct <= self.DRAWDOWN_SEVERE_PCT:
            allocation = self._reduce_equity_exposure(
                {k: float(v) for k, v in proposed_allocation.items()}, 0.50
            )
            rules_triggered.append(
                f"SEVERE drawdown {drawdown_pct:.1f}% exceeds -20% threshold "
                f"→ reduced equity exposure by 50% (overrides moderate rule)"
            )

        # ── RULE 2: Volatility spike → increase cash allocation ──
        if volatility_annualized >= self.VOL_SPIKE_THRESHOLD:
            allocation = self._boost_cash(allocation, target_min=0.20)
            rules_triggered.append(
                f"Volatility spike ({volatility_annualized*100:.1f}% annualised "
                f"≥ {self.VOL_SPIKE_THRESHOLD*100:.0f}% threshold) "
                f"→ cash allocation increased to ≥20%"
            )

        # ── RULE 3: Market crash detected (CRISIS regime) → 50% to gold ──
        if regime == "CRISIS":
            allocation = self._force_gold_allocation(
                allocation, self.CRISIS_GOLD_TARGET
            )
            rules_triggered.append(
                f"CRISIS regime detected → forced {self.CRISIS_GOLD_TARGET*100:.0f}% "
                f"allocation to Gold (safe haven)"
            )

        # ── RULE 4: Turbulence index extreme → force minimum cash floor ──
        if turbulence_percentile >= self.TURBULENCE_PCTILE_CAP:
            allocation = self._boost_cash(
                allocation, target_min=self.MIN_CASH_ON_TURBULENCE
            )
            rules_triggered.append(
                f"Turbulence index at {turbulence_percentile:.0f}th percentile "
                f"(≥95th) → minimum cash floor of "
                f"{self.MIN_CASH_ON_TURBULENCE*100:.0f}% enforced"
            )

        # ── RULE 5: Correlation spike → reduce all equity by 20% ──
        if correlation_spike:
            allocation = self._reduce_equity_exposure(allocation, 0.20)
            rules_triggered.append(
                "Correlation spike detected (assets moving together) "
                "→ reduced equity exposure by 20% (diversification compromised)"
            )

        # ── RULE 6: FinRL flagged OOD → cap growth equity at 10% ──
        if is_ood and allocation.get("equity_growth", 0) > 0.10:
            excess = allocation["equity_growth"] - 0.10
            allocation["equity_growth"] = 0.10
            allocation["bonds"] = allocation.get("bonds", 0) + excess * 0.6
            allocation["gold"]  = allocation.get("gold", 0)  + excess * 0.4
            rules_triggered.append(
                "FinRL agent flagged out-of-distribution state "
                "→ growth equity capped at 10%, excess moved to bonds/gold"
            )

        # ── Renormalize to sum to 1.0 ──
        total = sum(allocation.values())
        if total > 0:
            allocation = {k: v / total for k, v in allocation.items()}

        equity_after = sum(allocation.get(k, 0) for k in equity_keys)
        cash_after   = allocation.get("cash", 0)

        # ── Severity classification ──
        n_rules = len(rules_triggered)
        if n_rules == 0:
            severity = "NONE"
        elif n_rules <= 1:
            severity = "MODERATE"
        elif n_rules <= 3:
            severity = "SEVERE"
        else:
            severity = "CRITICAL"

        verdict = PreservationVerdict(
            input_allocation={k: round(v,3) for k,v in proposed_allocation.items()},
            final_allocation={k: round(v,3) for k,v in allocation.items()},
            rules_triggered=rules_triggered,
            override_applied=n_rules > 0,
            total_equity_before=round(equity_before, 3),
            total_equity_after=round(equity_after, 3),
            cash_before=round(cash_before, 3),
            cash_after=round(cash_after, 3),
            severity=severity,
        )

        self.audit_log.append({
            "regime": regime,
            "drawdown": drawdown_pct,
            "rules_fired": n_rules,
            "severity": severity,
        })

        return verdict

    # ── Rule implementations ──
    def _reduce_equity_exposure(self, allocation: Dict[str, float],
                                 reduction_pct: float) -> Dict[str, float]:
        """Reduce all equity positions by reduction_pct, move freed
        capital proportionally into bonds and gold (defensive assets)."""
        alloc = dict(allocation)
        equity_keys = [k for k in alloc if "equity" in k]
        freed = 0.0
        for k in equity_keys:
            cut = alloc[k] * reduction_pct
            alloc[k] -= cut
            freed += cut
        # Split freed capital: 60% bonds, 40% gold
        alloc["bonds"] = alloc.get("bonds", 0) + freed * 0.6
        alloc["gold"]  = alloc.get("gold", 0)  + freed * 0.4
        return alloc

    def _boost_cash(self, allocation: Dict[str, float],
                    target_min: float) -> Dict[str, float]:
        """Increase cash to at least target_min, taking proportionally
        from all other positions."""
        alloc = dict(allocation)
        current_cash = alloc.get("cash", 0)
        if current_cash >= target_min:
            return alloc

        shortfall = target_min - current_cash
        other_keys = [k for k in alloc if k != "cash"]
        other_total = sum(alloc[k] for k in other_keys)

        if other_total > 0:
            for k in other_keys:
                proportion = alloc[k] / other_total
                alloc[k] -= shortfall * proportion

        alloc["cash"] = target_min
        return alloc

    def _force_gold_allocation(self, allocation: Dict[str, float],
                               target_gold: float) -> Dict[str, float]:
        """Force gold to target_gold, taking proportionally from
        everything else (especially equity)."""
        alloc = dict(allocation)
        current_gold = alloc.get("gold", 0)
        if current_gold >= target_gold:
            return alloc

        shortfall = target_gold - current_gold
        other_keys = [k for k in alloc if k != "gold"]
        other_total = sum(alloc[k] for k in other_keys)

        if other_total > 0:
            for k in other_keys:
                proportion = alloc[k] / other_total
                alloc[k] = max(0, alloc[k] - shortfall * proportion)

        alloc["gold"] = target_gold
        return alloc


if __name__ == "__main__":
    print("=" * 60)
    print("  AGENT 4: CAPITAL PRESERVATION AGENT")
    print("=" * 60)

    agent = CapitalPreservationAgent()

    # ── Test 1: Normal conditions — no overrides should fire ──
    proposed_normal = {
        "equity_growth": 0.45, "equity_value": 0.25,
        "bonds": 0.15, "gold": 0.08, "cash": 0.07,
    }
    v1 = agent.evaluate(
        proposed_normal, regime="BULL",
        drawdown_pct=-2.0, volatility_annualized=0.13,
        turbulence_percentile=40, correlation_spike=False, is_ood=False,
    )
    print(f"\nTEST 1: Normal bull market")
    print(f"  Rules triggered: {len(v1.rules_triggered)} | Severity: {v1.severity}")
    print(f"  Input:  {v1.input_allocation}")
    print(f"  Output: {v1.final_allocation}")
    print(f"  (Should be unchanged — no rules fire in healthy conditions)")

    # ── Test 2: Your exact scenario — 12%+ drawdown ──
    proposed_aggressive = {
        "equity_growth": 0.60, "equity_value": 0.20,
        "bonds": 0.08, "gold": 0.07, "cash": 0.05,
    }
    v2 = agent.evaluate(
        proposed_aggressive, regime="BEAR",
        drawdown_pct=-14.5, volatility_annualized=0.24,
        turbulence_percentile=70, correlation_spike=False, is_ood=False,
    )
    print(f"\nTEST 2: Drawdown -14.5% (exceeds -12% threshold)")
    print(f"  Rules triggered: {len(v2.rules_triggered)} | Severity: {v2.severity}")
    for r in v2.rules_triggered:
        print(f"    • {r}")
    print(f"  Equity: {v2.total_equity_before*100:.0f}% → {v2.total_equity_after*100:.0f}%")
    print(f"  Final: {v2.final_allocation}")

    # ── Test 3: Full crisis — multiple rules fire simultaneously ──
    proposed_crisis = {
        "equity_growth": 0.50, "equity_value": 0.25,
        "bonds": 0.10, "gold": 0.10, "cash": 0.05,
    }
    v3 = agent.evaluate(
        proposed_crisis, regime="CRISIS",
        drawdown_pct=-22.0, volatility_annualized=0.41,
        turbulence_percentile=98, correlation_spike=True, is_ood=True,
    )
    print(f"\nTEST 3: FULL CRISIS — all 6 rules should fire")
    print(f"  Rules triggered: {len(v3.rules_triggered)} | Severity: {v3.severity}")
    for r in v3.rules_triggered:
        print(f"    • {r}")
    print(f"  Equity: {v3.total_equity_before*100:.0f}% → {v3.total_equity_after*100:.0f}%")
    print(f"  Cash:   {v3.cash_before*100:.0f}% → {v3.cash_after*100:.0f}%")
    print(f"  FINAL allocation: {v3.final_allocation}")
