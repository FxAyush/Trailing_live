TRAILING.live — Project State, Architecture, Results, and Development Rules

1. Project Overview

TRAILING.live is a multi-agent financial intelligence, crash-risk, and portfolio decision-support system.

The product goal is simple:

Every morning, estimate whether a meaningful market crash is likely in the next 15 trading sessions, explain why, and recommend a risk-aware portfolio allocation.

TRAILING is designed as an intelligence and advisory co-pilot, not as a fund. The user's money remains in the user's own brokerage/demat account. TRAILING provides signals, explanations, and recommended allocations; the user remains in control.

The system is being built for both:

US markets

Indian markets

The core philosophy is:

use real data wherever possible;

make every model input reproducible;

avoid look-ahead bias;

validate on out-of-sample / forward data;

never fabricate market signals;

never tune thresholds merely to make metrics look impressive;

explain every recommendation from real upstream evidence.

2. What We Are Building

We are building a 6-layer AI pipeline that reads global financial data and answers one main question:

Is a market crash likely in the next 15 trading sessions?

Layer 1 — Macro Stress Index

The first layer builds a broad systemic stress picture from live and historical financial signals.

Important inputs include:

VIX / volatility

yield-curve spread / inversion

credit-spread proxies

market breadth

TED / liquidity-style proxies

India VIX

FII-related proxies where reliable data is available

additional market-stress signals

These are transformed into a causal stress score between 0 and 100.

The stress score is not the same as crash probability.

Its purpose is to summarize the current financial environment:

low stress;

elevated stress;

critical stress.

Current signal processing is designed to be causal: only information available at the time should be used.

Layer 2 — News, Sentiment, and Geopolitical Risk

TRAILING ingests live geopolitical/news context and uses it as an explanation and monitoring layer.

Current live-news sources include:

Google News RSS

GDELT DOC 2.0 when available

Relevant geopolitical themes include:

Iran / Israel / US conflict

Strait of Hormuz

oil and LNG disruption

shipping disruption

sanctions

nuclear risk

major monetary-policy events

geopolitical escalation / de-escalation

The live geopolitical layer classifies fresh headlines into categories such as:

military escalation

shipping disruption

energy disruption

sanctions

nuclear risk

de-escalation

It also creates a 0–100 live geopolitical diagnostic score.

Important:

The live headline score is currently diagnostic/explanatory only.
It is not directly fed into the trained crash-probability model until an equivalent historical headline series has been backfilled and validated.

This avoids train/live mismatch.

Layer 3 — Enhanced Live Data

TRAILING is designed to combine market, macro, sentiment, and geopolitical data.

Current / planned data inputs include:

VIX

India VIX

S&P 500 / NIFTY

US Treasury rates

credit-market proxies

USD / INR

Brent crude

Gold

USD index

market breadth

volatility

economic calendar signals

FII / DII data when available from a reliable source

Fear & Greed-type sentiment indicators

live news and geopolitical event monitoring

All live data should have clearly documented sources.

Do not silently substitute random or synthetic values when a source fails.

Layer 4 — Alpha Research / Reasoning Agent

This layer is intended to reason across the structured signals like a macro research analyst.

Example reasoning chain:

Iran–Israel escalation
→ Strait of Hormuz disruption risk
→ oil price shock
→ higher Indian import bill
→ INR pressure
→ weaker foreign flows / higher inflation risk
→ possible NIFTY drawdown

The reasoning agent should never invent a causal claim.

Every explanation must trace back to real upstream signals or clearly labeled inference.

The reasoning layer should produce plain-language investment theses such as:

why crash risk changed;

what the important drivers are;

whether the risk is US-specific, India-specific, or global;

which assets are transmitting geopolitical stress;

why a portfolio shift is being recommended.

Layer 5 — Early Warning Model

The Early Warning system predicts:

Probability of a market crash during the next 15 trading sessions.

Current crash definition

A positive crash label occurs if either condition is met within the next 15 trading sessions:

forward close-to-close return <= -5%

maximum drawdown <= -7%

These thresholds are intentionally fixed.

Do not change the target merely to improve AUC, AP, Brier Score, or marketing claims.

Current model architecture

The current system uses an ensemble of:

Gradient Boosted Trees (GBT)

LSTM sequence model

The LSTM is being made deliberately smaller and uses:

chronological validation;

early stopping;

lower capacity;

no random validation split.

Training performance is diagnostic only.

Out-of-sample / time-series CV / forward performance matters more.

Layer 6 — Portfolio Risk / CVaR / Monte Carlo Layer

The portfolio layer takes:

crash probability;

current regime;

systemic stress;

risk limits;

market assumptions;

and recommends a portfolio allocation.

The system uses:

scenario generation;

Monte Carlo simulation;

portfolio risk estimates;

CVaR / worst-case loss control;

defensive allocation logic;

regime-aware allocation.

The goal is not to promise a fixed return.

The goal is:

maximize expected risk-adjusted return while respecting the user's risk constraints and capital-preservation rules.

Any claim such as "17–21% annualised return" must be treated as a target/illustrative scenario unless supported by frozen out-of-sample evidence.

3. The 5-Agent Multi-Agent System

The six analytical layers feed into a multi-agent decision system.

Agent 1 — Regime Detection

Classifies the current environment into one of:

BULL

BEAR

SIDEWAYS

CRISIS

Portfolio behavior can differ substantially by regime.

Agent 2 — Risk Assessment

Measures live risk using multiple independent signals such as:

VIX level

realized volatility

market drawdown

turbulence / unusual-state measures

correlation spikes

systemic stress indicators

Its role is to identify whether the current environment is becoming abnormal.

Agent 3 — FinRL / Reinforcement Learning Agent

The RL layer is intended to recommend portfolio allocations from historical market states.

Critical safeguards include:

regime-specific policies;

out-of-distribution detection;

confidence-weighted blending;

defensive safe-floor allocations.

A bull-market policy must not blindly dominate during crisis conditions.

If the current state looks unlike the training distribution, the system should reduce reliance on the RL output.

Agent 4 — Capital Preservation Agent

This agent has veto authority.

Its purpose is deliberately simple:

capital protection should not depend entirely on a complex learned model.

Examples of hard protective logic can include:

reducing equity when drawdown exceeds a threshold;

increasing cash when volatility spikes;

increasing gold / defensive exposure in CRISIS regimes;

enforcing portfolio-risk caps.

These rules should be explicit, auditable, and version-controlled.

No LLM or RL confidence score should silently override the preservation rules.

Agent 5 — Explanation Agent

The Explanation Agent converts the full decision into plain language.

Example:

"Equity exposure was reduced because market turbulence moved above its historical range, volatility increased, geopolitical risk rose, and the crash-probability model moved higher."

Every number in the explanation must trace back to a real upstream signal.

Never invent explanations after the fact.

4. How TRAILING Should Work in Practice

Every morning, the user should see:

crash probability for the next 15 sessions;

stress score;

current regime;

plain-language explanation;

recommended portfolio allocation;

exact rules that triggered changes;

India VIX / VIX;

oil / gold / USD moves;

live geopolitical headlines;

geopolitical risk level;

major risk drivers.

Example alert:

Crash probability rose overnight.
Geopolitical escalation increased, oil moved sharply higher, and foreign-risk indicators weakened. TRAILING recommends reducing equity exposure and increasing defensive assets.

The exact percentage and allocation should always come from the model / portfolio engine, not from templated text.

5. What Makes TRAILING Different

TRAILING is intended to be a financial intelligence co-pilot, not a black-box mutual fund.

The user:

keeps money in their own account;

sees the reasoning;

sees the upstream signals;

can override recommendations;

receives proactive risk warnings;

can understand why an allocation changed.

The core differentiator is the combination of:

market-crash early warning;

geopolitical and macro context;

multi-agent risk reasoning;

portfolio optimization;

capital-preservation veto;

explainable recommendations.

6. Important Data / Modeling Cleanup Already Completed

The original project contained several unrealistic or unsafe evaluation shortcuts.

These should never be reintroduced.

Old problems that were found

Synthetic historical stress signals

The old historical data loader generated synthetic signals and calibrated them around known crisis dates.

That made historical backtests look more predictive than they really were.

Synthetic market returns in the old backtester

The old backtester generated returns from:

stress score;

base daily return;

random noise.

Therefore the old catastrophic / impressive backtest output was not a valid evaluation of the model.

Random FII values

An earlier live-data implementation used randomly generated FII flows.

Random data must not be used in production decision logic.

Full-history percentile leakage

An earlier signal-processing implementation used:

smoothed.rank(pct=True)

over the full historical series.

That gave past observations information about future values.

The current signal-processing design uses causal trailing windows.

7. Current Preferred Real-Data Pipeline

Important current modules include:

data_loader_v2.py

signal_processor_v2.py

backtester_v2.py

forward_test_v2.py

early_warning_v2.py

early_warning_v3.py

geopolitical_risk.py

Other project modules include:

app.py

capital_preservation_agent.py

config.py

crisis_reporter.py

explanation_agent.py

explainability.py

live_data_v2.py

monte_carlo.py

multi_agent_system.py

ood_detector.py

portfolio_optimizer.py

regime_agent.py

risk_agent.py

safe_rl_agent.py

stress_tester.py

train_safe_rl.py

warning_portfolio.py

Codex should verify which are active, obsolete, or duplicated before deleting anything.

8. Historical Backtest Results From the Real-Return Backtester

These results came from the revised backtester using real market returns and lagged signals.

They are useful historical diagnostics, but should not be treated as proof of future performance.

US historical backtest

Approximate results:

Strategy final value: 421

Benchmark final value: 305.67

Strategy CAGR: 8.87%

Benchmark CAGR: 6.83%

Strategy volatility: 10.07%

Benchmark volatility: 13.64%

Strategy max drawdown: -30.82%

Benchmark max drawdown: -39.55%

Strategy Sharpe: 0.41

Benchmark Sharpe: 0.20

India historical backtest

Approximate results:

Strategy final value: 588.36

Benchmark final value: 381.53

Strategy CAGR: 11.21%

Benchmark CAGR: 8.36%

Strategy max drawdown: -27.12%

Benchmark max drawdown: -45.78%

Strategy Sharpe: 0.56

Benchmark Sharpe: 0.29

Important caveat

These backtests were later found to rely on historical stress signals that had originally been synthetic / crisis-calibrated.

Therefore:

These numbers are not sufficient evidence of real predictive edge and must not be marketed as validated production performance.

They remain useful only as historical engineering references.

9. Early Warning v2 — Real Crash Labels

Early Warning v2 changed the target from future stress to actual market crashes.

US v2

Approximate time-series CV:

Mean AUC: 0.581

Mean AP: 0.132

Mean Brier: 0.114

India v2

Approximate time-series CV:

Mean AUC: 0.486

Mean AP: 0.125

Mean Brier: 0.146

Interpretation:

US showed modest ranking ability.

India was approximately random under this specification.

Train AUC was approximately 0.999, indicating strong overfitting.

The model should be judged by CV / walk-forward / forward performance, not training AUC.

10. Early Warning v3 — Geopolitical Features

v3 adds historical geopolitical variables.

Current historical/model geopolitical inputs include:

gpr_ai

gpr_threats

gpr_acts

gpr_oil

Brent 5-day return

Brent 20-day volatility

Gold 5-day return

USD Index 5-day return

geopolitical market stress

Additional causal geopolitical features were added / are being added:

252-day causal z-scores

5-day log changes

20-day log change for AI-GPR

geopolitical acceleration measures

The goal is to model not just geopolitical level, but also:

abnormality;

rate of change;

acceleration;

market transmission.

11. Latest US v3 Run

A recent US run produced:

Dataset

Signals: approximately 5,080 rows

Date range: 2007-01-03 to 2026-09-08

Training samples: 4,881

Real crash labels: 559

Positive prevalence: 11.45%

Time-series CV

Fold results:

Fold 1 AUC: 0.679

Fold 2 AUC: 0.499

Fold 3 AUC: 0.597

Fold 4 AUC: 0.597

Fold 5 AUC: 0.543

Mean:

AUC: 0.583

AP: 0.112

Brier: 0.147

Current US inference from that run

Crash probability: 1.2%

Alert: LOW

Stress score: 15.8 / 100

Current geopolitical model values in that run

Approximate:

AI-GPR: 191.06

GPR Threats: 120.25

GPR Acts: 223.93

GPR Oil: 1023.54

Brent 5-day move: +7.13%

Brent 20-day annualized volatility: 30.14%

Gold 5-day move: +0.15%

USD Index 5-day move: -0.56%

geopolitical market stress: -0.1728

Important interpretation

The geopolitical environment was elevated, particularly oil-related risk, but the broader market-state features did not resemble historical 15-day crash setups strongly enough for the model to assign a high crash probability.

This is not necessarily contradictory.

Geopolitical risk and crash probability are different concepts.

12. What v3 Has and Has Not Proven

What is working

geopolitical data is entering the model;

real geopolitical variables appear in top model drivers;

live headlines are being collected;

Google News RSS works as the primary live source;

GDELT can be used as a secondary source when not rate-limited;

crash labels are based on actual future market outcomes;

the model target is more realistic than the original synthetic-stress target.

What is not yet proven

The geopolitical additions have not yet demonstrated a clear out-of-sample improvement.

Approximate comparison:

v2 US AUC: ~0.581

v3 US AUC: ~0.583

That difference is too small to claim meaningful improvement.

The next comparison must use identical:

dates;

labels;

benchmark data;

TimeSeriesSplit folds;

classifier settings.

Use compare_v2_v3_cv.py for this purpose.

13. Evaluation Metrics

Always report all three:

ROC AUC

Measures ranking quality.

higher = better

0.5 ≈ random ranking

Average Precision (AP)

Important for rare crash events.

higher = better

compare AP against crash prevalence

If crash prevalence is ~11%, an AP near ~0.11 is near the naive/random baseline.

Brier Score

Measures probability accuracy / calibration.

lower = better

0 = perfect

Do not judge the model by AUC alone.

For a crash-warning system, AP and Brier are particularly important.

14. Current LSTM Direction

Earlier LSTM training reached approximately:

train AUC: 0.999–1.000

This is an overfitting warning.

Current LSTM design should use:

smaller hidden dimension;

fewer layers;

chronological validation;

early stopping;

weight decay;

gradient clipping;

fixed final refit using the selected epoch count.

Do not increase LSTM capacity merely to make training performance look better.

15. Forward Testing

The forward-testing system is designed around frozen predictions.

Important rules:

save the timestamp;

save model version;

save crash probability;

save portfolio weights;

do not modify these after the prediction is made;

wait for the complete future horizon;

evaluate against actual future market outcomes.

Current horizon:

15 future trading sessions

Current crash outcome:

forward return <= -5%

OR max drawdown <= -7%

Some old forward predictions were made before the real-data cleanup and must remain frozen for auditability.

Do not rewrite them.

16. Portfolio / Forward Evaluation

The portfolio system should be evaluated on:

portfolio return;

benchmark return;

max drawdown;

volatility;

Sharpe;

turnover;

transaction costs;

CVaR / tail loss;

drawdown protection;

performance during actual stress regimes.

Monte Carlo assumptions must be documented.

Do not use optimistic hard-coded assumptions to market performance.

17. Critical Development Rules for Codex

Codex must follow these rules whenever editing the repository.

Data integrity

Use real data whenever possible.

Deterministic proxies are allowed only when documented.

Never fabricate market data.

Never inject crisis dates into model inputs.

Never use random market signals in production.

Never backward-fill future observations into past rows.

Rolling statistics must be causal.

Target integrity

Keep the current crash target fixed unless the project owner explicitly asks to redesign the target for a documented research reason.

Current target:

15 trading sessions

forward return <= -5%

OR max drawdown <= -7%

Do not tune these values merely to improve metrics.

Evaluation integrity

Use:

chronological / time-series validation;

walk-forward testing;

frozen forward testing;

identical-fold comparisons;

realistic transaction costs.

Training AUC is diagnostic only.

Geopolitical integrity

Historical ML inputs may include:

AI-GPR

GPR threats

GPR acts

GPR oil

causal changes

causal z-scores

causal acceleration

Brent

Gold

USD

geopolitical market transmission

Live headline scores remain diagnostic unless a comparable historical series has been backfilled.

Model integrity

Do not:

optimize solely for prettier AUC;

select features using future test results;

silently change the target;

tune thresholds on the forward set;

delete poor results.

If a model becomes more realistic but metrics fall, report that honestly.

18. Product Claims — Important Honesty Rule

Some original product descriptions used claims such as:

"70% crash detection"

"21 days average early warning"

"17–21% annualized return"

These claims must not be treated as validated facts unless they are reproduced using:

real historical data;

no leakage;

frozen out-of-sample / walk-forward evaluation;

documented methodology;

realistic costs;

fixed target definitions.

Until then, describe them as:

product goals;

historical experimental observations;

or aspirational performance targets.

Do not publish them as validated production statistics.

19. Current Development Priorities

Priority order:

Verify the final geopolitical_risk.py and early_warning_v3.py.

Run US v3.

Run India v3.

Compare v2 vs v3 using identical dates and folds.

Check AP and Brier, not only AUC.

Add full walk-forward evaluation for the entire GBT + LSTM ensemble.

Improve probability calibration using chronological calibration only.

Improve India-specific features.

Validate portfolio layer with realistic costs.

Connect only validated modules into multi_agent_system.py and app.py.

Audit obsolete / duplicate modules before deletion.

Continue frozen forward testing.

20. India-Specific Research Direction

India currently needs stronger India-specific signals.

Possible additions to research carefully:

NIFTY return / momentum

NIFTY realized volatility

NIFTY drawdown

NIFTY moving-average structure

Bank NIFTY

India VIX

USD/INR

India bond yields

reliable FII / DII flows

crude-oil transmission

INR volatility

India credit / liquidity proxies

Every new feature must be historically available and causal.

21. Intended Final User Experience

The long-term product experience should be:

Morning dashboard

crash probability

stress score

market regime

geopolitical risk

explanation

portfolio allocation

risk-rule triggers

live macro indicators

portfolio downside metrics

Alert example

Risk increased overnight.
Oil surged, geopolitical escalation intensified, volatility rose, and market breadth weakened. TRAILING recommends reducing equity exposure and increasing defensive assets.

The alert must use actual current model outputs.

No numbers should be hard-coded into the explanation.

22. Development Philosophy

The objective of TRAILING is not:

"make the backtest look amazing."

The objective is:

build a realistic, causal, reproducible financial early-warning and portfolio-risk system that can survive out-of-sample and live evaluation.

A lower but honest metric is more valuable than a high metric produced by leakage, synthetic crisis signals, or hindsight.

If a new feature does not improve out-of-sample performance, report it.

If a model cannot reliably predict crashes, say so.

If geopolitical risk is high but crash probability is low, explain the difference.

Transparency is part of the product.

23. Codex Onboarding Instruction

When starting work in Codex, first read:

AGENTS.md

PROJECT_STATE.md

Then inspect the whole repository before making large changes.

Recommended first instruction:

Read AGENTS.md and PROJECT_STATE.md first. Then inspect the entire TRAILING.live repository. Do not modify anything yet. Give me the architecture and data flow, identify active vs obsolete files, check for leakage or look-ahead risks, identify broken imports/version mismatches, and propose the top five engineering tasks in priority order. Follow AGENTS.md strictly.

24. Current Bottom Line

TRAILING already has:

a real-data stress pipeline;

a real market-crash target;

US and India model paths;

GBT + LSTM early-warning architecture;

geopolitical historical features;

current headline monitoring;

multi-agent risk architecture;

portfolio protection logic;

real-return backtesting tools;

frozen forward-testing infrastructure.

But the project should still be considered research / development, not a validated production trading system.

The next milestone is not a higher marketing number.

The next milestone is:

demonstrating stable out-of-sample predictive and portfolio value under identical, causal, reproducible evaluation.