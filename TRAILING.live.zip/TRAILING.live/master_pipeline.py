"""
master_pipeline.py
------------------
THE SINGLE FILE YOU RUN EVERY DAY.

Combines all layers:
  Layer 1: Macro signals (VIX, yield curve, credit spreads)
  Layer 2: News + sentiment (20+ RSS feeds, Reddit)
  Layer 3: Enhanced data (GDELT, Fear&Greed, NSE live, yfinance)
  Layer 4: LLM research agent (geopolitics, AI trends, sectors)
  Layer 5: Early warning model (GBT + LSTM ensemble)
  Layer 6: CVaR portfolio optimizer (Monte Carlo + safe RL)

Final output:
  - Crash probability (0-100%)
  - Buy opportunity score (0-100%)
  - Geopolitical risk score
  - Fear & Greed reading
  - Full portfolio allocation
  - Risk metrics (CVaR, Sharpe, expected return)
  - Investment thesis
  - Plain-language recommendation

Run:
  python master_pipeline.py              full run (~3 min)
  python master_pipeline.py --fast       skip slow sources (~45 sec)
  python master_pipeline.py --report     save PDF report
"""

import os, sys, json, argparse
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from typing import Dict, Optional, List
from datetime import datetime
from data_loader       import load_all_signals
from signal_processor  import run_full_pipeline, get_current_snapshot
from monte_carlo       import MonteCarloEngine, mc_portfolio_returns, ASSET_CLASSES, N_ASSETS
from early_warning     import EarlyWarningModel, LSTMNet, SAVE_PATH as EW_PATH
from warning_portfolio import optimize_with_warning
from news_fetcher      import run_news_pipeline
from alpha_agent       import LLMAlphaAgent
from enhanced_data     import EnhancedDataFetcher

MASTER_LOG = "master_signals_log.json"


# ─────────────────────────────────────────────────────────
# Signal combiner — weights all 6 layers into final scores
# ─────────────────────────────────────────────────────────
def combine_all_signals(
    stress_score:   float,    # 0-100, Layer 1
    ew_prob:        float,    # 0-100, Layer 5
    news_crash:     float,    # 0-100, Layer 2
    news_buy:       float,    # 0-100, Layer 2
    enhanced_crash: float,    # 0-100, Layer 3
    enhanced_buy:   float,    # 0-100, Layer 3
    geo_score:      float,    # 0-100, Layer 3+4
    alpha_crash:    float,    # 0-1,   Layer 4
    alpha_buy:      float,    # 0-1,   Layer 4
) -> Dict:
    """
    Evidence-weighted combination of all signal sources.

    Weights reflect empirical reliability:
      Early warning model:  30% (trained on history)
      Macro stress index:   20% (real-time indicators)
      Enhanced data:        20% (live market data)
      News sentiment:       15% (current events)
      Alpha agent:          15% (LLM reasoning)
    """
    crash_components = {
        "early_warning":  (ew_prob / 100,        0.30),
        "macro_stress":   (stress_score / 100,   0.20),
        "enhanced_data":  (enhanced_crash / 100, 0.20),
        "news_sentiment": (news_crash / 100,     0.15),
        "alpha_agent":    (alpha_crash,           0.15),
    }

    buy_components = {
        "news_buy":       (news_buy / 100,   0.35),
        "enhanced_buy":   (enhanced_buy / 100,0.35),
        "alpha_buy":      (alpha_buy,         0.30),
    }

    # Weighted sum
    crash_prob = sum(v * w for v, w in crash_components.values())
    buy_prob   = sum(v * w for v, w in buy_components.values())

    # Buy prob suppressed when crash is high
    buy_prob   = float(buy_prob * max(0, 1 - crash_prob * 0.7))
    crash_prob = float(np.clip(crash_prob, 0, 1))
    buy_prob   = float(np.clip(buy_prob,   0, 1))

    # Overall signal
    if crash_prob >= 0.65:
        signal, emoji = "CRITICAL CRASH WARNING", "🔴"
    elif crash_prob >= 0.45:
        signal, emoji = "ELEVATED CRASH RISK",    "🟠"
    elif buy_prob >= 0.55:
        signal, emoji = "BUY OPPORTUNITY",         "🟢"
    elif buy_prob >= 0.35:
        signal, emoji = "MILD OPPORTUNITY",        "🟡"
    else:
        signal, emoji = "NEUTRAL / HOLD",          "⚪"

    return {
        "crash_prob":        round(crash_prob, 3),
        "buy_prob":          round(buy_prob,   3),
        "geo_risk":          round(geo_score / 100, 3),
        "overall_signal":    signal,
        "emoji":             emoji,
        "crash_components":  {k: round(v*100, 1)
                              for k, (v,_) in crash_components.items()},
        "buy_components":    {k: round(v*100, 1)
                              for k, (v,_) in buy_components.items()},
    }

from typing import Dict, Optional, List


# ─────────────────────────────────────────────────────────
# Final output formatter
# ─────────────────────────────────────────────────────────
def build_final_output(
    date:        str,
    combined:    Dict,
    snapshot:    Dict,
    portfolio:   Dict,
    alpha:       Dict,
    enhanced:    Dict,
    ew_warning:  Dict,
    news_data:   Dict,
) -> Dict:
    """Build the complete final output dict."""

    comp = enhanced.get("composite", {})
    pct  = {f"p{p}": float(np.percentile(
                mc_portfolio_returns(portfolio["weights"],
                _get_scenarios()), p))
            for p in [5,10,25,50,75,90]} if "weights" in portfolio else {}

    return {
        "date":     date,
        "timestamp": datetime.now().isoformat(),

        # ── Core probabilities ──
        "crash_probability_pct":   round(combined["crash_prob"] * 100, 1),
        "buy_opportunity_pct":     round(combined["buy_prob"]   * 100, 1),
        "geo_risk_pct":            round(combined["geo_risk"]   * 100, 1),
        "overall_signal":          combined["overall_signal"],

        # ── Stress index ──
        "stress_score":    round(snapshot["stress_score"], 1),
        "stress_regime":   snapshot["regime"],
        "stress_trend":    snapshot["trend"],
        "stress_categories": {
            cat: info["percentile"]
            for cat, info in snapshot["categories"].items()
        },

        # ── Market sentiment ──
        "fear_greed_score":    comp.get("fear_greed_score", 50),
        "market_sentiment":    comp.get("market_sentiment", "NEUTRAL"),
        "india_vix_live":      comp.get("india_vix_live", 0),
        "nifty_change_pct":    comp.get("nifty_change_pct", 0),
        "fii_flow_crore":      comp.get("fii_flow_crore", 0),
        "vix_live":            comp.get("vix_live", 0),
        "yield_spread":        comp.get("yield_spread", 0),

        # ── Early warning ──
        "ew_crash_prob_pct":   ew_warning.get("probability", 0),
        "ew_alert":            ew_warning.get("alert", ""),
        "ew_recommendation":   ew_warning.get("recommendation", ""),
        "ew_top_drivers":      ew_warning.get("top_drivers", []),

        # ── News signals ──
        "active_hotspots":     news_data.get("active_hotspots", []),
        "news_crash_score":    news_data.get("crash_signal", 0),
        "news_buy_score":      news_data.get("buy_signal", 0),
        "news_geo_risk":       news_data.get("geo_risk_score", 0),
        "top_crash_news":      [s["title"] for s in
                                news_data.get("top_crash_stories", [])[:3]],
        "top_buy_news":        [s["title"] for s in
                                news_data.get("top_buy_stories",   [])[:3]],

        # ── Alpha agent ──
        "alpha_thesis":        alpha.get("llm_thesis") or alpha.get("thesis", ""),
        "alpha_signals":       [
            {"type": s["type"], "source": s["source"],
             "confidence": round(s["confidence"]*100,1),
             "assets": s["assets"]}
            for s in alpha.get("signals", [])[:5]
        ],

        # ── Portfolio ──
        "portfolio_profile":   portfolio.get("profile_label", "Balanced"),
        "portfolio_weights":   {k: round(v*100, 1)
                               for k, v in portfolio["weights_named"].items()
                               if v > 0.005},
        "portfolio_cvar":      round(portfolio["cvar"]*100, 1),
        "portfolio_expected_return": round(portfolio["expected_ret"]*100, 1),
        "portfolio_sharpe":    round(portfolio["sharpe"], 2),
        "portfolio_is_safe":   portfolio["is_safe"],
        "portfolio_max_cvar_limit": round(portfolio.get("max_cvar",-0.15)*100,1),
        "alpha_adjusted":      portfolio.get("alpha_adjusted", False),

        # ── Signal breakdown ──
        "signal_components":   combined["crash_components"],
        "buy_components":      combined["buy_components"],
    }

_mc_cache = None
def _get_scenarios():
    global _mc_cache
    if _mc_cache is None:
        mc = MonteCarloEngine(horizon=30, df_t=7)
        s  = load_all_signals()
        _mc_cache = mc.generate_scenarios(s.iloc[-1].values.astype(float), 200)
    return _mc_cache


# ─────────────────────────────────────────────────────────
# Pretty print
# ─────────────────────────────────────────────────────────
def print_master_report(out: Dict):
    sep = "═" * 65

    print(f"\n{sep}")
    print(f"  {out['emoji'] if 'emoji' in out else ''}  FINSHIELD INTELLIGENCE REPORT")
    print(f"  {out['date']}  |  {out['timestamp'][11:16]} IST")
    print(sep)

    # Overall signal
    print(f"\n  {'─'*60}")
    print(f"  OVERALL SIGNAL:   {out['overall_signal']}")
    print(f"  {'─'*60}")
    print(f"  Crash probability:     {out['crash_probability_pct']:>6.1f}%")
    print(f"  Buy opportunity:       {out['buy_opportunity_pct']:>6.1f}%")
    print(f"  Geopolitical risk:     {out['geo_risk_pct']:>6.1f}%")

    # Signal breakdown
    print(f"\n  Signal components (crash probability drivers):")
    for k, v in out["signal_components"].items():
        bar = "█" * int(v / 5)
        print(f"    {k:20s}  {v:5.1f}%  {bar}")

    # Stress index
    print(f"\n  {'─'*60}")
    print(f"  MACRO STRESS INDEX")
    print(f"  {'─'*60}")
    score  = out["stress_score"]
    regime = out["stress_regime"].upper()
    bar    = "█" * int(score / 5)
    print(f"  Score:   {score:.1f}/100  {bar}")
    print(f"  Regime:  {regime}  |  Trend: {out['stress_trend']}")
    print(f"\n  Category breakdown:")
    for cat, pct in out["stress_categories"].items():
        b = "█" * int(pct / 10)
        print(f"    {cat[:32]:32s} {b:10s} {pct:.0f}th pct")

    # Market sentiment
    print(f"\n  {'─'*60}")
    print(f"  LIVE MARKET SENTIMENT")
    print(f"  {'─'*60}")
    print(f"  Fear & Greed:      {out['fear_greed_score']}/100  "
          f"({out['market_sentiment']})")
    print(f"  India VIX:         {out['india_vix_live']:.1f}")
    print(f"  Nifty change:      {out['nifty_change_pct']:+.2f}%")
    print(f"  FII flow:          ₹{out['fii_flow_crore']:+.0f} Cr")
    print(f"  US VIX:            {out['vix_live']:.1f}")
    print(f"  Yield spread:      {out['yield_spread']:+.3f}%")

    # Early warning
    print(f"\n  {'─'*60}")
    print(f"  EARLY WARNING  ({out['ew_alert']})")
    print(f"  {'─'*60}")
    print(f"  Crash probability (15d): {out['ew_crash_prob_pct']:.1f}%")
    print(f"  {out['ew_recommendation']}")
    if out["ew_top_drivers"]:
        print(f"\n  Top crash drivers:")
        for name, imp in out["ew_top_drivers"][:3]:
            print(f"    {name:30s} {imp:.1f}% importance")

    # Geopolitics & news
    if out["active_hotspots"]:
        print(f"\n  ⚠  GEOPOLITICAL HOTSPOTS:")
        for h in out["active_hotspots"]:
            print(f"     • {h.title()}")

    if out["top_crash_news"]:
        print(f"\n  Top crash signals from news:")
        for title in out["top_crash_news"]:
            print(f"    • {title[:70]}")

    if out["top_buy_news"]:
        print(f"\n  Top buy signals from news:")
        for title in out["top_buy_news"]:
            print(f"    • {title[:70]}")

    # Alpha thesis
    if out["alpha_thesis"]:
        print(f"\n  {'─'*60}")
        print(f"  INVESTMENT THESIS (AI Research)")
        print(f"  {'─'*60}")
        thesis = out["alpha_thesis"]
        words  = thesis.split()
        line   = "  "
        for w in words:
            if len(line) + len(w) > 64:
                print(line)
                line = "    " + w + " "
            else:
                line += w + " "
        if line.strip():
            print(line)

    # Alpha signals
    if out["alpha_signals"]:
        print(f"\n  Active signals:")
        for s in out["alpha_signals"][:4]:
            icon = "🔴" if s["type"] == "CRASH_WARNING" else "🟢"
            print(f"    {icon} [{s['confidence']:.0f}%] {s['source']}")
            print(f"       → {', '.join(s['assets'][:3])}")

    # Portfolio
    print(f"\n  {'─'*60}")
    print(f"  PORTFOLIO RECOMMENDATION  [{out['portfolio_profile']}]"
          f"{'  [alpha-adj]' if out['alpha_adjusted'] else ''}")
    print(f"  {'─'*60}")
    for asset, w in sorted(out["portfolio_weights"].items(),
                           key=lambda x: -x[1]):
        bar = "█" * int(w / 3)
        print(f"  {asset:20s}  {w:5.1f}%  {bar}")

    print(f"\n  Risk metrics:")
    print(f"    Expected return (30d): {out['portfolio_expected_return']:+.1f}%")
    print(f"    CVaR — worst 5%:       {out['portfolio_cvar']:.1f}%")
    print(f"    Sharpe ratio:          {out['portfolio_sharpe']:.2f}")
    safe = "✓ SAFE" if out["portfolio_is_safe"] else "✗ UNSAFE"
    print(f"    Safety:                {safe}  "
          f"(limit: {out['portfolio_max_cvar_limit']:.0f}%)")

    print(f"\n{sep}")
    print(f"  Run `python master_pipeline.py` daily for live updates")
    print(sep)


# ─────────────────────────────────────────────────────────
# Log output
# ─────────────────────────────────────────────────────────
def log_output(out: Dict):
    existing = []
    if os.path.exists(MASTER_LOG):
        with open(MASTER_LOG) as f:
            try:
                existing = json.load(f)
            except Exception:
                existing = []

    # Remove duplicate dates
    existing = [e for e in existing if e.get("date") != out["date"]]
    # Keep summary (not full nested dicts)
    summary = {k: v for k, v in out.items()
               if not isinstance(v, dict) or k == "portfolio_weights"}
    existing.append(summary)

    with open(MASTER_LOG, "w") as f:
        json.dump(existing[-90:], f, indent=2)
    print(f"\n  Logged → {MASTER_LOG}")


# ─────────────────────────────────────────────────────────
# Master run
# ─────────────────────────────────────────────────────────
def run_master_pipeline(fast: bool = False,
                         n_scenarios: int = 400,
                         risk: str = "medium") -> Dict:

    date = datetime.now().strftime("%Y-%m-%d")
    RISK_MAP = {
        "low":    {"max_cvar": -0.10, "risk_tol": 0.2},
        "medium": {"max_cvar": -0.15, "risk_tol": 0.5},
        "high":   {"max_cvar": -0.22, "risk_tol": 0.8},
    }
    rp = RISK_MAP.get(risk, RISK_MAP["medium"])

    print("═"*65)
    print("  FINSHIELD — MASTER INTELLIGENCE PIPELINE")
    print(f"  {date}  |  Risk profile: {risk.upper()}")
    print("═"*65)

    # ── Layer 1: Macro signals ──
    print("\n[1/6] Macro signals...")
    signals = load_all_signals()
    results = run_full_pipeline(signals)
    score   = results["score"]
    snap    = get_current_snapshot(results)
    stress  = snap["stress_score"]
    regime  = snap["regime"]
    print(f"  Stress: {stress:.1f}/100 ({regime.upper()}) "
          f"trend: {snap['trend']}")

    # ── Layer 2: News + sentiment ──
    print("\n[2/6] News + sentiment...")
    if fast:
        print("  Skipped (--fast mode)")
        news_data = {
            "crash_signal": 0, "buy_signal": 0,
            "geo_risk_score": 0, "avg_sentiment": 0,
            "active_hotspots": [], "top_crash_stories": [],
            "top_buy_stories": [], "overall_signal": "NEUTRAL",
            "total_articles": 0,
        }
    else:
        news_data = run_news_pipeline()
        print(f"  {news_data['total_articles']} articles | "
              f"crash: {news_data['crash_articles']} | "
              f"buy: {news_data['buy_articles']} | "
              f"geo: {news_data['geo_articles']}")
        if news_data["active_hotspots"]:
            print(f"  ⚠ Hotspots: {', '.join(news_data['active_hotspots'])}")

    # ── Layer 3: Enhanced data ──
    print("\n[3/6] Enhanced data (live market feeds)...")
    if fast:
        print("  Fetching critical sources only...")
        fetcher  = EnhancedDataFetcher()
        enhanced = fetcher.fetch_all(verbose=False)
    else:
        fetcher  = EnhancedDataFetcher()
        enhanced = fetcher.fetch_all(verbose=True)
    comp = enhanced.get("composite", {})
    print(f"  Crash score: {comp.get('crash_score',0):.1f} | "
          f"Buy score: {comp.get('buy_score',0):.1f} | "
          f"F&G: {comp.get('fear_greed_score',50)}")

    # ── Layer 4: Alpha research agent ──
    print("\n[4/6] Alpha research agent...")
    agent = LLMAlphaAgent()
    # Merge news + enhanced data for richer context
    enriched_news = {
        **news_data,
        "geo_risk_score": max(
            news_data.get("geo_risk_score", 0),
            comp.get("geo_conflict_score", 0)
        ),
    }
    alpha = agent.research(enriched_news, stress_score=stress)
    print(f"  {alpha['n_signals']} signals | "
          f"crash: {alpha['crash_prob']*100:.0f}% | "
          f"buy: {alpha['buy_prob']*100:.0f}% | "
          f"LLM: {alpha['enhanced']}")

    # ── Layer 5: Early warning model ──
    print("\n[5/6] Early warning model...")
    if os.path.exists(EW_PATH):
        ew_model = EarlyWarningModel.load(EW_PATH)
    else:
        print("  Training early warning model (first run)...")
        ew_model = EarlyWarningModel()
        ew_model.train(signals, score, lstm_epochs=60)
        ew_model.save()
    ew_warning = ew_model.predict_today(signals, score)
    ew_prob    = ew_warning["probability"]
    print(f"  Crash prob: {ew_prob:.1f}%  ({ew_warning['alert']})")

    # ── Combine all signals ──
    combined = combine_all_signals(
        stress_score=stress,
        ew_prob=ew_prob,
        news_crash=news_data.get("crash_signal", 0),
        news_buy=news_data.get("buy_signal", 0),
        enhanced_crash=comp.get("crash_score", 0),
        enhanced_buy=comp.get("buy_score", 0),
        geo_score=max(news_data.get("geo_risk_score", 0),
                      comp.get("geo_conflict_score", 0)),
        alpha_crash=alpha["crash_prob"],
        alpha_buy=alpha["buy_prob"],
    )
    combined["emoji"] = combined.get("emoji", "⚪")

    # ── Layer 6: Portfolio ──
    print(f"\n[6/6] Generating portfolio "
          f"(crash={combined['crash_prob']*100:.0f}%)...")
    mc_engine     = MonteCarloEngine(horizon=30, df_t=7)
    current_state = signals.iloc[-1].values.astype(np.float32)

    portfolio = optimize_with_warning(
        crash_prob=combined["crash_prob"],
        current_state=current_state,
        mc_engine=mc_engine,
        n_scenarios=n_scenarios,
        regime=regime,
    )
    portfolio["max_cvar"] = rp["max_cvar"]

    # Apply alpha hints
    from alpha_pipeline import apply_alpha_to_portfolio
    portfolio = apply_alpha_to_portfolio(
        portfolio, alpha, mc_engine, current_state,
        n_scenarios=min(n_scenarios, 200)
    )

    # ── Build final output ──
    out = build_final_output(
        date=date,
        combined=combined,
        snapshot=snap,
        portfolio=portfolio,
        alpha=alpha,
        enhanced=enhanced,
        ew_warning=ew_warning,
        news_data=news_data,
    )
    out["emoji"] = combined.get("emoji", "⚪")

    # ── Print + log ──
    print_master_report(out)
    log_output(out)

    return out


# ─────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="FinShield Master Intelligence Pipeline"
    )
    parser.add_argument("--fast",    action="store_true",
                        help="Skip slow sources (news + enhanced)")
    parser.add_argument("--risk",    choices=["low","medium","high"],
                        default="medium")
    parser.add_argument("--scenarios", type=int, default=400)
    parser.add_argument("--report",  action="store_true",
                        help="Save PDF report")
    args = parser.parse_args()

    import argparse as _ap
    result = run_master_pipeline(
        fast=args.fast,
        n_scenarios=args.scenarios,
        risk=args.risk,
    )

    if args.report:
        try:
            from compare_portfolios import generate_comparison_report
            from data_loader import load_all_signals as _las
            from signal_processor import run_full_pipeline as _rfp
            sigs = _las()
            res  = _rfp(sigs)
            from early_warning import EarlyWarningModel, LSTMNet
            mdl  = EarlyWarningModel.load(EW_PATH)
            mc   = MonteCarloEngine(horizon=30, df_t=7)
            generate_comparison_report(sigs, res["score"], mc, mdl,
                                       "master_report.pdf")
            print("  PDF saved → master_report.pdf")
        except Exception as e:
            print(f"  PDF generation failed: {e}")
