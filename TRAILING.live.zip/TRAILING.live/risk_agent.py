"""
risk_agent.py
-------------
AGENT 2: Risk Agent

Tracks real-time risk metrics that feed into capital preservation decisions:
  - VIX level and term structure
  - Realized volatility (multiple windows)
  - Drawdown from recent highs
  - Turbulence Index (Mahalanobis distance — detects "unusual" markets)
  - Correlation spike detection (assets moving together = systemic risk)

The Turbulence Index is the most powerful and least-known metric here.
Developed by Kritzman & Li (2010), it measures how statistically unusual
today's returns are relative to history, accounting for how assets
normally move together. A turbulence spike often precedes drawdowns
even when volatility alone looks normal.
"""

import numpy as np
import pandas as pd
from typing import Dict, List
from dataclasses import dataclass, field
import warnings
warnings.filterwarnings("ignore")


@dataclass
class RiskState:
    vix_level:           float
    vix_percentile:       float    # where today's VIX sits vs 1yr history
    realized_vol_20d:     float
    realized_vol_60d:     float
    vol_regime:           str       # LOW / NORMAL / ELEVATED / EXTREME
    drawdown_pct:         float
    drawdown_duration:    int       # days since last high
    turbulence_index:     float
    turbulence_percentile: float
    correlation_spike:    bool
    avg_correlation:      float
    risk_score:           float     # 0-100 composite
    risk_level:           str       # LOW / MEDIUM / HIGH / EXTREME
    alerts:               List[str] = field(default_factory=list)


class RiskAgent:
    """
    Computes composite risk metrics from multi-asset return data.

    Turbulence Index formula (Mahalanobis distance):
        TI_t = (y_t - μ)ᵀ Σ⁻¹ (y_t - μ)

    where y_t = asset returns today, μ = historical mean,
    Σ = historical covariance matrix.

    High turbulence = today's pattern of returns across assets
    is statistically unusual — even if no single asset moved much,
    the RELATIONSHIP between assets broke down. This often precedes
    crises because correlations spike right before crashes.
    """

    def __init__(self, vol_window_short: int = 20,
                 vol_window_long: int = 60,
                 turbulence_window: int = 252):
        self.vol_window_short  = vol_window_short
        self.vol_window_long   = vol_window_long
        self.turbulence_window = turbulence_window
        self._vix_history: List[float] = []
        self._turbulence_history: List[float] = []

    def compute_turbulence(self, returns_matrix: pd.DataFrame) -> float:
        """
        Compute today's turbulence index from a multi-asset return matrix.

        Args:
            returns_matrix: DataFrame, columns=assets, rows=days
                            (most recent row = today)

        Returns:
            Turbulence index (higher = more unusual market behaviour)
        """
        if len(returns_matrix) < 30:
            return 0.0

        hist    = returns_matrix.iloc[:-1]   # historical window
        today   = returns_matrix.iloc[-1].values

        mu      = hist.mean().values
        cov     = hist.cov().values

        try:
            cov_inv = np.linalg.pinv(cov)   # pseudo-inverse for stability
            diff    = today - mu
            ti      = float(diff @ cov_inv @ diff.T)
            return ti
        except Exception:
            return 0.0

    def compute_correlation_spike(self, returns_matrix: pd.DataFrame,
                                   short_window: int = 10,
                                   long_window: int = 60) -> tuple:
        """
        Detect correlation spikes — when assets that normally move
        independently start moving together. This is THE classic
        early signal of systemic stress (everything sells off together).

        Returns:
            (is_spike: bool, avg_correlation_today: float)
        """
        if len(returns_matrix) < long_window:
            return False, 0.0

        recent_corr = returns_matrix.iloc[-short_window:].corr()
        normal_corr = returns_matrix.iloc[-long_window:-short_window].corr()

        # Average off-diagonal correlation
        n = len(recent_corr)
        mask = ~np.eye(n, dtype=bool)

        recent_avg = float(recent_corr.values[mask].mean())
        normal_avg = float(normal_corr.values[mask].mean())

        spike = (recent_avg - normal_avg) > 0.15   # 15pp jump = spike
        return spike, recent_avg

    def compute_drawdown(self, prices: pd.Series) -> tuple:
        """Compute current drawdown % and days since last high."""
        running_max = prices.cummax()
        drawdown = (prices - running_max) / running_max
        current_dd = float(drawdown.iloc[-1] * 100)

        # Days since the running max was last updated
        is_at_high = (prices == running_max)
        last_high_idx = is_at_high[::-1].idxmax() if is_at_high.any() else prices.index[0]
        duration = len(prices) - prices.index.get_loc(last_high_idx) - 1

        return current_dd, max(duration, 0)

    def assess(self, single_asset_returns: pd.Series,
               multi_asset_returns: pd.DataFrame = None,
               vix: float = 20.0,
               vix_history: List[float] = None) -> RiskState:
        """
        Full risk assessment from market data.

        Args:
            single_asset_returns: returns of the primary index (e.g. Nifty)
            multi_asset_returns:  DataFrame of multiple asset returns
                                   (for turbulence + correlation calc)
            vix:                  current VIX level
            vix_history:          list of recent VIX values for percentile calc

        Returns:
            RiskState with full risk breakdown
        """
        alerts = []

        # ── Volatility ──
        vol_20d = float(single_asset_returns.iloc[-self.vol_window_short:].std()
                        * np.sqrt(252) * 100)
        vol_60d = float(single_asset_returns.iloc[-self.vol_window_long:].std()
                        * np.sqrt(252) * 100)

        if vol_20d < 12:
            vol_regime = "LOW"
        elif vol_20d < 20:
            vol_regime = "NORMAL"
        elif vol_20d < 32:
            vol_regime = "ELEVATED"
            alerts.append(f"Volatility elevated: {vol_20d:.1f}% annualised")
        else:
            vol_regime = "EXTREME"
            alerts.append(f"EXTREME volatility: {vol_20d:.1f}% annualised")

        # ── Drawdown ──
        prices = (1 + single_asset_returns).cumprod()
        drawdown_pct, dd_duration = self.compute_drawdown(prices)

        if drawdown_pct < -12:
            alerts.append(f"Drawdown {drawdown_pct:.1f}% exceeds 12% threshold")
        if drawdown_pct < -20:
            alerts.append(f"SEVERE drawdown {drawdown_pct:.1f}% — capital preservation critical")

        # ── VIX percentile ──
        vix_history = vix_history or [vix] * 252
        vix_percentile = float(
            (np.array(vix_history) < vix).mean() * 100
        )

        # ── Turbulence Index ──
        turbulence = 0.0
        turbulence_pctile = 0.0
        if multi_asset_returns is not None and len(multi_asset_returns) > 30:
            turbulence = self.compute_turbulence(multi_asset_returns)
            self._turbulence_history.append(turbulence)
            if len(self._turbulence_history) > 5:
                hist_arr = np.array(self._turbulence_history)
                turbulence_pctile = float((hist_arr < turbulence).mean() * 100)
            if turbulence_pctile > 90:
                alerts.append(
                    f"Turbulence index at {turbulence_pctile:.0f}th percentile "
                    f"— unusual cross-asset behaviour detected"
                )

        # ── Correlation spike ──
        corr_spike = False
        avg_corr   = 0.0
        if multi_asset_returns is not None and len(multi_asset_returns) > 60:
            corr_spike, avg_corr = self.compute_correlation_spike(multi_asset_returns)
            if corr_spike:
                alerts.append(
                    f"Correlation spike detected: assets moving together "
                    f"(avg correlation {avg_corr:.2f}) — diversification breaking down"
                )

        # ── Composite risk score (0-100) ──
        vol_component   = np.clip(vol_20d / 40 * 100, 0, 100) * 0.30
        dd_component     = np.clip(abs(drawdown_pct) / 25 * 100, 0, 100) * 0.30
        vix_component    = np.clip(vix_percentile, 0, 100) * 0.20
        turb_component   = np.clip(turbulence_pctile, 0, 100) * 0.15
        corr_component   = (30 if corr_spike else 0) * 0.05

        risk_score = float(
            vol_component + dd_component + vix_component +
            turb_component + corr_component
        )
        risk_score = float(np.clip(risk_score, 0, 100))

        if risk_score < 25:
            risk_level = "LOW"
        elif risk_score < 50:
            risk_level = "MEDIUM"
        elif risk_score < 75:
            risk_level = "HIGH"
        else:
            risk_level = "EXTREME"

        return RiskState(
            vix_level=round(vix, 1),
            vix_percentile=round(vix_percentile, 1),
            realized_vol_20d=round(vol_20d, 1),
            realized_vol_60d=round(vol_60d, 1),
            vol_regime=vol_regime,
            drawdown_pct=round(drawdown_pct, 1),
            drawdown_duration=dd_duration,
            turbulence_index=round(turbulence, 2),
            turbulence_percentile=round(turbulence_pctile, 1),
            correlation_spike=corr_spike,
            avg_correlation=round(avg_corr, 3),
            risk_score=round(risk_score, 1),
            risk_level=risk_level,
            alerts=alerts,
        )


if __name__ == "__main__":
    print("=" * 55)
    print("  AGENT 2: RISK AGENT")
    print("=" * 55)

    agent = RiskAgent()
    rng = np.random.default_rng(7)

    # ── Scenario 1: Normal market ──
    normal_returns = pd.Series(rng.normal(0.0005, 0.009, 100))
    multi_normal = pd.DataFrame({
        "equity":  rng.normal(0.0005, 0.009, 100),
        "bonds":   rng.normal(0.0002, 0.003, 100),
        "gold":    rng.normal(0.0003, 0.006, 100),
        "crypto":  rng.normal(0.001,  0.025, 100),
    })

    state = agent.assess(normal_returns, multi_normal, vix=15.5,
                         vix_history=list(rng.normal(18, 4, 252)))
    print("\nScenario: NORMAL MARKET")
    print(f"  Risk score:  {state.risk_score:.0f}/100  ({state.risk_level})")
    print(f"  Vol regime:  {state.vol_regime} ({state.realized_vol_20d:.1f}%)")
    print(f"  Drawdown:    {state.drawdown_pct:.1f}%")
    print(f"  Turbulence:  {state.turbulence_index:.2f}")
    print(f"  Alerts: {state.alerts or 'None'}")

    # ── Scenario 2: Crisis with correlation breakdown ──
    crisis_returns = pd.Series(
        list(rng.normal(0.0005, 0.009, 80)) +
        list(rng.normal(-0.03, 0.04, 20))
    )
    # During crisis, everything falls together (correlation spike)
    crisis_shock = rng.normal(-0.025, 0.03, 20)
    multi_crisis = pd.DataFrame({
        "equity": list(rng.normal(0.0005, 0.009, 80)) + list(crisis_shock),
        "bonds":  list(rng.normal(0.0002, 0.003, 80)) + list(crisis_shock * 0.6),
        "gold":   list(rng.normal(0.0003, 0.006, 80)) + list(-crisis_shock * 0.3),
        "crypto": list(rng.normal(0.001,  0.025, 80)) + list(crisis_shock * 1.8),
    })

    state2 = agent.assess(crisis_returns, multi_crisis, vix=38.2,
                          vix_history=list(rng.normal(18, 4, 252)))
    print("\nScenario: CRISIS (correlation breakdown)")
    print(f"  Risk score:  {state2.risk_score:.0f}/100  ({state2.risk_level})")
    print(f"  Vol regime:  {state2.vol_regime} ({state2.realized_vol_20d:.1f}%)")
    print(f"  Drawdown:    {state2.drawdown_pct:.1f}%  ({state2.drawdown_duration}d)")
    print(f"  Turbulence:  {state2.turbulence_index:.2f} "
          f"({state2.turbulence_percentile:.0f}th pctile)")
    print(f"  Correlation spike: {state2.correlation_spike} "
          f"(avg corr: {state2.avg_correlation:.2f})")
    print(f"  Alerts:")
    for a in state2.alerts:
        print(f"    - {a}")
