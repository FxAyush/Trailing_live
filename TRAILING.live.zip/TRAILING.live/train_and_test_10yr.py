"""
train_and_test_10yr.py
------------------------
THE COMPLETE PIPELINE you asked for:

  1. Fetch 10 years of REAL historical data — both India and US markets
  2. Auto-segment into BULL/BEAR/SIDEWAYS/CRISIS using Agent 1's
     own classifier (so training labels exactly match inference labels)
  3. Train FinRL's regime-conditioned Q-tables on ALL FOUR regimes
     using REAL historical episodes (including real crisis periods
     like COVID 2020 and the 2022 bear market — not synthetic noise)
  4. Run the full 5-agent pipeline on TODAY'S LIVE market data
  5. Report results, with an explicit train/test split so you can see
     how the system would have performed on data it never trained on

This directly answers: train on 10 years, test on live data, get
real (not synthetic) results.

Requirements:
  pip install yfinance pandas numpy

Run:
  python train_and_test_10yr.py --market india
  python train_and_test_10yr.py --market us
  python train_and_test_10yr.py --market both --years 10
"""

import numpy as np
import pandas as pd
from datetime import datetime
from typing import Dict, Optional
import argparse
import sys, os
import warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from multi_agent_system import MultiAgentPortfolioSystem
from historical_data_fetcher import (
    prepare_training_data, fetch_market_history,
    segment_into_regimes, build_regime_episodes,
    build_multi_asset_matrix, validate_segmentation_logic,
    years_covered,
)
from regime_agent import REGIMES


def train_test_split_episodes(episodes: Dict, test_fraction: float = 0.2) -> tuple:
    """
    Split each regime's episodes into train/test chronologically
    (NOT randomly — random split would leak future info into training,
    which is a classic and serious mistake in time-series ML).

    The LAST `test_fraction` of each regime's history is held out.
    This means: if you have 2015-2025 BULL data, you train on
    2015-2023 BULL days and test on 2023-2025 BULL days — simulating
    genuinely not having seen the most recent regime instance.
    """
    train_episodes = {}
    test_episodes  = {}

    for regime, data in episodes.items():
        n = len(data["returns"])
        split_idx = int(n * (1 - test_fraction))

        train_episodes[regime] = {
            "returns": data["returns"].iloc[:split_idx].reset_index(drop=True),
            "vol":     data["vol"].iloc[:split_idx].reset_index(drop=True),
            "dd":      data["dd"].iloc[:split_idx].reset_index(drop=True),
        }
        test_episodes[regime] = {
            "returns": data["returns"].iloc[split_idx:].reset_index(drop=True),
            "vol":     data["vol"].iloc[split_idx:].reset_index(drop=True),
            "dd":      data["dd"].iloc[split_idx:].reset_index(drop=True),
        }

    return train_episodes, test_episodes


def backtest_on_holdout(system: MultiAgentPortfolioSystem,
                        test_episodes: Dict,
                        multi_asset: pd.DataFrame,
                        vix_history: list) -> Dict:
    """
    Run the trained system against the HELD-OUT test period for each
    regime — data the FinRL agent never trained on. This is the
    honest measure of how well the system generalizes, not just how
    well it memorized training data.
    """
    print(f"\n  Backtesting on held-out (never-trained-on) data...")
    results = {}

    for regime, data in test_episodes.items():
        returns = data["returns"]
        if len(returns) < 25:
            print(f"    {regime}: insufficient holdout data, skipping")
            continue

        # Build cumulative price series over the FULL holdout period first,
        # so drawdown is measured from the true regime-period peak —
        # not artificially reset to 1.0 at each sampled window's start
        # (that earlier approach overstated drawdown in down-trending
        # windows sampled mid-decline).
        full_prices = (1 + returns).cumprod()

        n_windows = min(5, len(returns) // 20)
        window_results = []

        for w in range(n_windows):
            start = w * (len(returns) // n_windows)
            end   = min(start + 60, len(returns))
            if end - start < 25:
                continue

            window_returns = returns.iloc[start:end]
            # Drawdown relative to the running max of the FULL series
            # up to this point, not reset per-window
            window_prices  = full_prices.iloc[:end]
            running_max    = window_prices.cummax()
            true_drawdown  = float(
                ((window_prices.iloc[-1] - running_max.iloc[-1]) /
                 running_max.iloc[-1]) * 100
            )

            vix_estimate = float(20 + data["vol"].iloc[start:end].mean() * 50)

            output = system.run(
                recent_returns=window_returns,
                vix=vix_estimate,
                vix_history=vix_history,
                multi_asset_returns=multi_asset.iloc[-200:] if len(multi_asset) > 200 else multi_asset,
            )

            equity_total = sum(
                v for k, v in output.final_allocation.items() if "equity" in k
            )
            window_results.append({
                "regime_detected":     output.regime_state.regime,
                "regime_actual":         regime,
                "matched":                output.regime_state.regime == regime,
                "equity_allocation":        equity_total,
                "rules_fired":                len(output.preservation_verdict.rules_triggered),
                "ood_flagged":                  output.finrl_decision.is_ood,
                "true_drawdown_pct":              round(true_drawdown, 1),
            })

        if window_results:
            match_rate = sum(r["matched"] for r in window_results) / len(window_results)
            avg_equity = np.mean([r["equity_allocation"] for r in window_results])
            results[regime] = {
                "windows_tested":     len(window_results),
                "regime_match_rate":     round(match_rate * 100, 1),
                "avg_equity_allocation":   round(avg_equity * 100, 1),
                "details":                   window_results,
            }
            print(f"    {regime:10s}: {len(window_results)} windows | "
                  f"regime-ID match: {match_rate*100:.0f}% | "
                  f"avg equity allocation: {avg_equity*100:.0f}%")

    return results


def run_full_pipeline(market: str, years: int = 10,
                      use_synthetic_fallback: bool = True) -> Optional[Dict]:
    print("=" * 65)
    print(f"  10-YEAR TRAIN + LIVE TEST PIPELINE — {market.upper()}")
    print("=" * 65)

    # ── STEP 1: Fetch + segment real historical data ──
    print(f"\n[STEP 1/5] Fetching {years}-year history & auto-segmenting regimes...")
    prep = prepare_training_data(market, years)

    used_synthetic = False
    if prep is None or len(prep["episodes"]) == 0:
        if not use_synthetic_fallback:
            print("  Live data unavailable and synthetic fallback disabled. Aborting.")
            return None
        print(f"\n  ⚠ Live data unavailable for {market} in this environment.")
        print(f"  Using synthetic 10-year multi-cycle data so you can see")
        print(f"  exactly how the full pipeline behaves — on your machine,")
        print(f"  this same code path pulls REAL yfinance data instead.\n")
        episodes = validate_segmentation_logic()
        multi_asset = _synthetic_multi_asset(episodes)
        vix_history = list(np.random.default_rng(1).normal(18, 5, 252).clip(8, 60))
        vix_current = float(vix_history[-1])
        used_synthetic = True
    else:
        episodes    = prep["episodes"]
        multi_asset = prep["multi_asset"]
        vix_history = prep["vix_history"] or list(np.random.default_rng(1).normal(18,5,252))
        vix_current = prep["vix_current"]

    if len(episodes) == 0:
        print("  No regimes had sufficient data. Aborting.")
        return None

    # ── STEP 2: Chronological train/test split ──
    print(f"\n[STEP 2/5] Splitting each regime 80% train / 20% holdout "
          f"(chronological, no leakage)...")
    train_episodes, test_episodes = train_test_split_episodes(episodes, 0.2)
    for regime in train_episodes:
        print(f"    {regime:10s}: {len(train_episodes[regime]['returns']):4d} train days "
              f"| {len(test_episodes[regime]['returns']):4d} holdout days")

    # ── STEP 3: Train FinRL on the 80% training split ──
    print(f"\n[STEP 3/5] Training FinRL agent's regime-conditioned policies...")
    system = MultiAgentPortfolioSystem()
    system.train(train_episodes, n_episodes_per_regime=400)

    # ── STEP 4: Backtest on the 20% holdout (never seen during training) ──
    print(f"\n[STEP 4/5] Backtesting on held-out data (true generalization test)...")
    backtest_results = backtest_on_holdout(
        system, test_episodes, multi_asset, vix_history
    )

    # ── STEP 5: Run on TODAY'S live data ──
    print(f"\n[STEP 5/5] Running on live/current market state...")
    if used_synthetic:
        print(f"  (using most recent synthetic window as 'today' proxy — "
              f"on your machine this pulls actual live data)")
        last_regime = list(episodes.keys())[-1]
        # Use a longer trailing window so drawdown reflects true recent
        # peak-to-trough, not an artificially reset short slice
        live_returns = episodes[last_regime]["returns"].iloc[-150:]
        live_vix = vix_current
    else:
        # Use the most recent real data as "today" — longer window
        # for a stable, realistic drawdown calculation
        all_returns = pd.concat([e["returns"] for e in episodes.values()])
        live_returns = all_returns.iloc[-150:]
        live_vix = vix_current

    live_output = system.run(
        recent_returns=live_returns,
        vix=live_vix,
        vix_history=vix_history,
        multi_asset_returns=multi_asset.iloc[-200:] if len(multi_asset) > 200 else multi_asset,
    )

    print(f"\n{'═'*65}")
    print(f"  LIVE RECOMMENDATION — {market.upper()}")
    print(f"{'═'*65}")
    system.print_report(live_output)
    print(f"\n  Full explanation:")
    print(live_output.explanation.full_narrative)

    return {
        "market":             market,
        "used_synthetic":        used_synthetic,
        "train_episodes":           train_episodes,
        "test_episodes":              test_episodes,
        "backtest_results":              backtest_results,
        "live_output":                     live_output,
        "system":                            system,
    }


def _synthetic_multi_asset(episodes: Dict) -> pd.DataFrame:
    """Build a synthetic multi-asset matrix matching episode length."""
    rng = np.random.default_rng(99)
    all_returns = pd.concat([e["returns"] for e in episodes.values()]).reset_index(drop=True)
    n = len(all_returns)
    return pd.DataFrame({
        "equity_growth": all_returns.values,
        "equity_value":  all_returns.values * 0.7 + rng.normal(0, 0.005, n),
        "bonds":         rng.normal(0.0002, 0.003, n),
        "gold":          -all_returns.values * 0.2 + rng.normal(0.0003, 0.006, n),
    })


def print_final_summary(result: Dict):
    if result is None:
        return

    print(f"\n\n{'#'*65}")
    print(f"  FINAL SUMMARY — {result['market'].upper()}")
    print(f"{'#'*65}")

    if result["used_synthetic"]:
        print(f"  ⚠ DATA SOURCE: Synthetic (yfinance unavailable in this "
              f"environment)")
        print(f"  → Run this same script on your machine for real results")
    else:
        print(f"  ✓ DATA SOURCE: Real {result['live_output'] and 'yfinance'} "
              f"historical market data")

    print(f"\n  Holdout generalization test results:")
    for regime, r in result["backtest_results"].items():
        print(f"    {regime:10s}: regime-ID accuracy "
              f"{r['regime_match_rate']:.0f}% | "
              f"avg equity exposure {r['avg_equity_allocation']:.0f}%")

    print(f"\n  Today's live recommendation:")
    out = result["live_output"]
    print(f"    Regime:      {out.regime_state.regime} "
          f"({out.regime_state.confidence*100:.0f}% confidence)")
    print(f"    Risk level:  {out.risk_state.risk_level} "
          f"({out.risk_state.risk_score:.0f}/100)")
    print(f"    Alert:       {out.explanation.alert_level}")
    print(f"    {out.explanation.summary}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--market", choices=["india", "us", "both"],
                        default="india")
    parser.add_argument("--years", type=int, default=10)
    args = parser.parse_args()

    markets = ["india", "us"] if args.market == "both" else [args.market]

    all_results = {}
    for market in markets:
        result = run_full_pipeline(market, args.years)
        all_results[market] = result
        print_final_summary(result)

    if len(markets) > 1 and all(all_results.values()):
        print(f"\n\n{'#'*65}")
        print(f"  CROSS-MARKET COMPARISON")
        print(f"{'#'*65}")
        for market, result in all_results.items():
            if result:
                out = result["live_output"]
                print(f"  {market.upper():8s}: regime={out.regime_state.regime:9s} "
                      f"risk={out.risk_state.risk_level:8s} "
                      f"alert={out.explanation.alert_level}")
