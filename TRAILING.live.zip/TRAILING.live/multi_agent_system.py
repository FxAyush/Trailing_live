"""
multi_agent_system.py — v2 (bug fixes)
Bug 1 fixed: CRISIS+LOW risk contradiction — consistency override added after Stage 2
Bug 2 fixed: missing space in train_and_test_10yr.py output
"""

import numpy as np
import pandas as pd
from typing import Dict, Optional
from dataclasses import dataclass
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from regime_agent import RegimeDetectionAgent, RegimeState
from risk_agent import RiskAgent, RiskState
from finrl_agent import RegimeConditionedQAgent, FinRLDecision
from capital_preservation_agent import CapitalPreservationAgent, PreservationVerdict
from explanation_agent import ExplanationAgent, Explanation


@dataclass
class SystemOutput:
    regime_state:          RegimeState
    risk_state:            RiskState
    finrl_decision:        FinRLDecision
    preservation_verdict:  PreservationVerdict
    explanation:           Explanation
    final_allocation:      Dict[str, float]


class MultiAgentPortfolioSystem:

    def __init__(self):
        self.regime_agent       = RegimeDetectionAgent()
        self.risk_agent         = RiskAgent()
        self.finrl_agent        = RegimeConditionedQAgent()
        self.preservation_agent = CapitalPreservationAgent()
        self.explanation_agent  = ExplanationAgent()
        self._trained = False

    def train(self, regime_episodes: Dict[str, Dict],
              n_episodes_per_regime: int = 300):
        print("Training FinRL agent (regime-conditioned)...")
        for regime, data in regime_episodes.items():
            result = self.finrl_agent.train_on_episode(
                regime, data["returns"], data["vol"], data["dd"],
                n_episodes=n_episodes_per_regime
            )
            status = "✓" if result.get("trained") else "✗"
            print(f"  {status} {regime}: {result}")
        self._trained = True

    def run(self,
            recent_returns: pd.Series,
            vix: float,
            vix_history: list,
            multi_asset_returns: Optional[pd.DataFrame] = None,
            ) -> SystemOutput:

        # ── Stage 1: Regime ──
        regime_state = self.regime_agent.classify(recent_returns)

        # ── Stage 2: Risk ──
        risk_state = self.risk_agent.assess(
            recent_returns,
            multi_asset_returns=multi_asset_returns,
            vix=vix,
            vix_history=vix_history,
        )

        # ── CONSISTENCY OVERRIDE (Bug 1 fix) ──
        # Root cause: Agent 2 uses VIX-percentile against a 252-day
        # rolling baseline. When VIX was elevated for months, today's
        # VIX=17 reads LOW percentile against that baseline — even
        # though Agent 1 correctly sees CRISIS from momentum/skew/drawdown.
        # Fix: Agent 1 (broader, slower context) overrides Agent 2 when
        # they contradict each other.
        if regime_state.regime == "CRISIS" and \
                risk_state.risk_level in ("LOW", "MEDIUM"):
            risk_state.risk_level = "HIGH"
            risk_state.risk_score = max(risk_state.risk_score, 65.0)
            risk_state.alerts.append(
                "Risk overridden LOW/MEDIUM → HIGH: CRISIS regime "
                "(Agent 1: 60d window, skew, drawdown shape) contradicted "
                "VIX-percentile which was miscalibrated against elevated baseline"
            )

        if regime_state.regime == "BEAR" and \
                risk_state.risk_level == "LOW":
            risk_state.risk_level = "MEDIUM"
            risk_state.risk_score = max(risk_state.risk_score, 40.0)
            risk_state.alerts.append(
                "Risk overridden LOW → MEDIUM: BEAR regime active "
                "but VIX-percentile reading LOW against baseline"
            )

        # ── Stage 3: FinRL ──
        momentum_5d = float(recent_returns.iloc[-5:].sum())
        finrl_decision = self.finrl_agent.decide(
            regime=regime_state.regime,
            momentum_5d=momentum_5d,
            vol_annualized=risk_state.realized_vol_20d / 100,
            drawdown_pct=risk_state.drawdown_pct,
        )

        # ── Stage 4: Capital Preservation ──
        preservation_verdict = self.preservation_agent.evaluate(
            proposed_allocation=finrl_decision.final_allocation,
            regime=regime_state.regime,
            drawdown_pct=risk_state.drawdown_pct,
            volatility_annualized=risk_state.realized_vol_20d / 100,
            turbulence_percentile=risk_state.turbulence_percentile,
            correlation_spike=risk_state.correlation_spike,
            is_ood=finrl_decision.is_ood,
        )

        # ── Stage 5: Explanation ──
        explanation = self.explanation_agent.explain(
            regime_state, risk_state, finrl_decision, preservation_verdict
        )

        return SystemOutput(
            regime_state=regime_state,
            risk_state=risk_state,
            finrl_decision=finrl_decision,
            preservation_verdict=preservation_verdict,
            explanation=explanation,
            final_allocation=preservation_verdict.final_allocation,
        )

    def print_report(self, output: SystemOutput):
        print("\n" + "═" * 65)
        print(f"  MULTI-AGENT PORTFOLIO RECOMMENDATION")
        print("═" * 65)

        print(f"\n  [{output.explanation.alert_level}]  "
              f"{output.explanation.headline}")
        print(f"\n  {output.explanation.summary}")

        print(f"\n  ── Pipeline trace ──")
        print(f"  1. Regime:            {output.regime_state.regime} "
              f"({output.regime_state.confidence*100:.0f}% conf)")
        print(f"  2. Risk:              {output.risk_state.risk_level} "
              f"({output.risk_state.risk_score:.0f}/100)")
        # Show override note if it fired
        override_alerts = [a for a in output.risk_state.alerts
                          if "overridden" in a]
        for a in override_alerts:
            print(f"     ⚡ {a[:75]}")
        print(f"  3. FinRL:             regime={output.finrl_decision.regime_used}, "
              f"OOD={output.finrl_decision.is_ood}, "
              f"blend={output.finrl_decision.blend_weight*100:.0f}%")
        print(f"  4. Capital Pres:      "
              f"{len(output.preservation_verdict.rules_triggered)} rule(s) "
              f"({output.preservation_verdict.severity})")
        for r in output.preservation_verdict.rules_triggered:
            print(f"     • {r[:72]}")
        print(f"  5. Explanation:       generated ({output.explanation.alert_level})")

        print(f"\n  ── Final allocation ──")
        for asset, w in sorted(output.final_allocation.items(),
                               key=lambda x: -x[1]):
            bar = "█" * int(w * 40)
            print(f"  {asset:18s}  {w*100:5.1f}%  {bar}")
        print("═" * 65)


# ── Standalone demo ──
def build_training_data(rng):
    return {
        "BULL": {
            "returns": pd.Series(rng.normal(0.0009, 0.008, 250)),
            "vol":     pd.Series(rng.normal(0.13, 0.02, 250)).clip(0.08, 0.22),
            "dd":      pd.Series(-np.abs(rng.normal(2, 2, 250))).clip(-15, 0),
        },
        "BEAR": {
            "returns": pd.Series(rng.normal(-0.0015, 0.016, 200)),
            "vol":     pd.Series(rng.normal(0.24, 0.04, 200)).clip(0.15, 0.38),
            "dd":      pd.Series(-np.abs(rng.normal(10, 5, 200))).clip(-35, 0),
        },
        "SIDEWAYS": {
            "returns": pd.Series(rng.normal(0.0001, 0.009, 200)),
            "vol":     pd.Series(rng.normal(0.14, 0.02, 200)).clip(0.09, 0.20),
            "dd":      pd.Series(-np.abs(rng.normal(4, 3, 200))).clip(-15, 0),
        },
    }


if __name__ == "__main__":
    print("=" * 65)
    print("  MULTI-AGENT SYSTEM — v2 (bug fixes)")
    print("=" * 65)

    rng = np.random.default_rng(42)
    system = MultiAgentPortfolioSystem()
    system.train(build_training_data(rng), n_episodes_per_regime=300)

    # Test the exact contradiction scenario from your output
    print("\n▶ BUG REGRESSION TEST: CRISIS regime should never show LOW risk")
    returns_crisis = pd.Series(
        list(rng.normal(0.0008, 0.008, 80)) +
        [-0.035, -0.05, -0.025, -0.06, -0.04,
         -0.03, -0.055, -0.02, -0.045, -0.038]
    )
    out = system.run(
        recent_returns=returns_crisis,
        vix=36.8,
        vix_history=list(rng.normal(16, 3, 252)),
    )
    system.print_report(out)

    regime = out.regime_state.regime
    risk   = out.risk_state.risk_level
    if regime == "CRISIS" and risk in ("LOW", "MEDIUM"):
        print(f"\n  ✗ Bug still present: {regime} + {risk}")
    else:
        print(f"\n  ✓ FIXED: {regime} regime → {risk} risk (consistent)")
