"""
finshield.py
============
THE ONLY FILE YOU NEED TO RUN.

Integrates all 10 data sources and 6 model layers into one
clean pipeline. Run this every morning.

Commands:
  python finshield.py                 Full run (all sources)
  python finshield.py --fast          Quick run (skip slow sources)
  python finshield.py --risk low      Conservative portfolio
  python finshield.py --risk high     Growth portfolio
  python finshield.py --history       Show last 30 days of signals
  python finshield.py --backtest      Run historical backtest

Output includes:
  Crash probability      (0-100%)
  Buy opportunity score  (0-100%)
  Geopolitical risk      (0-100%)
  Fear & Greed reading
  Put/Call ratio
  FII flow (India)
  Active hotspots
  Investment thesis
  Full portfolio allocation
  CVaR, Sharpe, expected return
  Top signal drivers
"""

import os, sys, json, argparse
import numpy as np
import pandas as pd
from datetime import datetime
from typing import Dict
import warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ── core layers ──
from data_loader       import load_all_signals
from signal_processor  import run_full_pipeline, get_current_snapshot
from monte_carlo       import MonteCarloEngine, mc_portfolio_returns, ASSET_CLASSES, N_ASSETS
from early_warning     import EarlyWarningModel, LSTMNet, SAVE_PATH as EW_PATH
from warning_portfolio import optimize_with_warning
from portfolio_optimizer import CVaROptimizer

# ── data sources ──
from news_fetcher      import run_news_pipeline
from alpha_agent       import LLMAlphaAgent
from enhanced_data     import EnhancedDataFetcher
from missing_sources   import CompleteMissingSourcesFetcher
from forex_calendar    import EconomicCalendarAggregator

LOG_FILE = "finshield_log.json"

RISK_PROFILES = {
    "low":    {"max_cvar": -0.10, "label": "Conservative"},
    "medium": {"max_cvar": -0.15, "label": "Balanced"},
    "high":   {"max_cvar": -0.22, "label": "Growth"},
}


# ══════════════════════════════════════════════════════════
# SIGNAL COMBINER
# Weights every source by its empirical reliability
# ══════════════════════════════════════════════════════════
def combine_signals(
    stress:       float,   # macro stress 0-100
    ew_prob:      float,   # early warning 0-100
    news_crash:   float,   # news crash 0-100
    news_buy:     float,   # news buy 0-100
    enh_crash:    float,   # enhanced crash 0-100
    enh_buy:      float,   # enhanced buy 0-100
    miss_crash:   float,   # missing sources crash 0-100
    miss_buy:     float,   # missing sources buy 0-100
    alpha_crash:  float,   # alpha agent 0-1
    alpha_buy:    float,   # alpha agent 0-1
    geo_score:    float,   # geopolitical 0-100
) -> Dict:

    # Crash probability — weighted evidence combination
    crash_raw = (
        ew_prob       / 100 * 0.30 +   # strongest signal
        stress        / 100 * 0.18 +
        enh_crash     / 100 * 0.15 +
        news_crash    / 100 * 0.12 +
        miss_crash    / 100 * 0.12 +
        alpha_crash         * 0.08 +
        geo_score     / 100 * 0.05
    )

    # Buy probability — weighted
    buy_raw = (
        enh_buy       / 100 * 0.30 +
        news_buy      / 100 * 0.25 +
        miss_buy      / 100 * 0.25 +
        alpha_buy           * 0.20
    )

    crash_prob = float(np.clip(crash_raw, 0, 1))
    buy_prob   = float(np.clip(buy_raw * (1 - crash_prob * 0.65), 0, 1))

    # Signal label
    if crash_prob >= 0.65:
        label, icon = "CRITICAL CRASH WARNING", "🔴"
    elif crash_prob >= 0.45:
        label, icon = "ELEVATED CRASH RISK",    "🟠"
    elif buy_prob  >= 0.55:
        label, icon = "BUY OPPORTUNITY",         "🟢"
    elif buy_prob  >= 0.30:
        label, icon = "MILD OPPORTUNITY",        "🟡"
    else:
        label, icon = "NEUTRAL — HOLD",          "⚪"

    return {
        "crash_prob":  round(crash_prob, 3),
        "buy_prob":    round(buy_prob,   3),
        "geo_risk":    round(geo_score / 100, 3),
        "label":       label,
        "icon":        icon,
        "breakdown": {
            "early_warning_model": round(ew_prob, 1),
            "macro_stress_index":  round(stress, 1),
            "enhanced_live_data":  round(enh_crash, 1),
            "news_sentiment":      round(news_crash, 1),
            "options_insider":     round(miss_crash, 1),
            "alpha_agent":         round(alpha_crash * 100, 1),
            "geopolitical_risk":   round(geo_score, 1),
        },
    }


# ══════════════════════════════════════════════════════════
# PORTFOLIO BUILDER
# ══════════════════════════════════════════════════════════
def build_portfolio(crash_prob: float, current_state: np.ndarray,
                    mc_engine: MonteCarloEngine, regime: str,
                    max_cvar: float, n_scenarios: int,
                    alpha_hints: Dict) -> Dict:

    # Base CVaR-optimized portfolio
    portfolio = optimize_with_warning(
        crash_prob=crash_prob,
        current_state=current_state,
        mc_engine=mc_engine,
        n_scenarios=n_scenarios,
        regime=regime,
    )
    portfolio["max_cvar"] = max_cvar

    # Apply alpha buy/sell hints (max 5% shift per asset)
    increase = alpha_hints.get("increase", {})
    decrease = alpha_hints.get("decrease", {})
    asset_idx = {a: i for i, a in enumerate(ASSET_CLASSES)}

    if increase or decrease:
        w = portfolio["weights"].copy()
        for asset, strength in increase.items():
            if asset in asset_idx:
                w[asset_idx[asset]] += min(0.05 * strength, 0.07)
        for asset, strength in decrease.items():
            if asset in asset_idx:
                w[asset_idx[asset]] -= min(0.05 * strength, 0.07)
        w = np.clip(w, 0, 0.45)
        w /= w.sum()

        # Check CVaR still safe
        sc = mc_engine.generate_scenarios(current_state, 150)
        pr = mc_portfolio_returns(w, sc)
        tn = max(1, int(np.ceil(0.05 * len(pr))))
        new_cvar = float(np.sort(pr)[:tn].mean())

        if new_cvar >= max_cvar:
            exp  = float(pr.mean())
            vol  = float(pr.std()) + 1e-8
            portfolio["weights"]        = w
            portfolio["weights_named"]  = dict(zip(ASSET_CLASSES, w))
            portfolio["cvar"]           = new_cvar
            portfolio["expected_ret"]   = exp
            portfolio["sharpe"]         = exp / vol * np.sqrt(12)
            portfolio["alpha_adjusted"] = True

    return portfolio


# ══════════════════════════════════════════════════════════
# PRINT FINAL REPORT
# ══════════════════════════════════════════════════════════
def print_report(out: Dict):
    W = 65
    bar = lambda v, w=30: "█" * int(v / 100 * w)

    print(f"\n{'═'*W}")
    print(f"  FINSHIELD — MARKET INTELLIGENCE")
    print(f"  {out['date']}  |  {out['time']}")
    print(f"{'═'*W}")

    # ── Overall signal ──
    print(f"\n  {out['icon']}  {out['signal']}")
    print(f"\n  {'Crash probability':<28} {out['crash_prob_pct']:>5.1f}%  "
          f"{bar(out['crash_prob_pct'])}")
    print(f"  {'Buy opportunity':<28} {out['buy_prob_pct']:>5.1f}%  "
          f"{bar(out['buy_prob_pct'])}")
    print(f"  {'Geopolitical risk':<28} {out['geo_risk_pct']:>5.1f}%  "
          f"{bar(out['geo_risk_pct'])}")

    # ── Signal breakdown ──
    print(f"\n  Crash signal breakdown:")
    for k, v in out["breakdown"].items():
        b = "█" * int(v / 10)
        print(f"    {k:<28} {v:>5.1f}  {b}")

    # ── Macro stress ──
    print(f"\n  {'─'*W}")
    print(f"  MACRO STRESS INDEX")
    s = out["stress_score"]
    print(f"  Score: {s:.1f}/100  {bar(s)}  [{out['stress_regime'].upper()}]")
    print(f"  Trend: {out['stress_trend']}")
    print(f"\n  Categories:")
    for cat, pct in out["stress_categories"].items():
        b = "█" * int(pct / 10)
        col = "⚠" if pct > 70 else "→"
        print(f"  {col}  {cat[:32]:<32} {b} {pct:.0f}th")

    # ── Live market ──
    print(f"\n  {'─'*W}")
    print(f"  LIVE MARKET DATA")
    items = [
        ("Fear & Greed",      f"{out['fear_greed']}/100 ({out['sentiment']})"),
        ("India VIX",         f"{out['india_vix']:.1f}"),
        ("Nifty change",      f"{out['nifty_pct']:+.2f}%"),
        ("FII flow",          f"₹{out['fii_flow']:+.0f} Cr  ({out.get('fii_source','est')})"),
        ("US VIX",            f"{out['us_vix']:.1f}"),
        ("Put/Call ratio",    f"{out['put_call']:.2f} ({out['options_signal']})"),
        ("Yield spread",      f"{out['yield_spread']:+.3f}%"),
        ("Insider signal",    out['insider_signal']),
        ("IMF India GDP",     f"{out['imf_gdp']:.1f}% ({out['imf_signal']})"),
        ("Patent trend",      out['patent_trend']),
    ]
    for label, val in items:
        print(f"  {'·'} {label:<22} {val}")

    # ── Early warning ──
    print(f"\n  {'─'*W}")
    print(f"  EARLY WARNING  ({out['ew_alert']})")
    print(f"  Crash prob (15d): {out['ew_prob']:.1f}%")
    print(f"  {out['ew_rec']}")
    if out["ew_drivers"]:
        print(f"\n  Top drivers:")
        for name, imp in out["ew_drivers"][:3]:
            print(f"    {name:<32} {imp:.1f}% importance")

    # ── Geopolitics ──
    if out["hotspots"]:
        print(f"\n  ⚠  GEOPOLITICAL HOTSPOTS: "
              f"{', '.join(h.title() for h in out['hotspots'])}")

    # ── News ──
    if out["crash_news"]:
        print(f"\n  Top crash news:")
        for h in out["crash_news"][:2]:
            print(f"    🔴 {h[:68]}")
    if out["buy_news"]:
        print(f"\n  Top buy signals:")
        for h in out["buy_news"][:2]:
            print(f"    🟢 {h[:68]}")

    # ── Alpha thesis ──
    if out["thesis"]:
        print(f"\n  {'─'*W}")
        print(f"  AI RESEARCH THESIS")
        words, line = out["thesis"].split(), "  "
        for w in words:
            if len(line) + len(w) > W - 2:
                print(line)
                line = "    " + w + " "
            else:
                line += w + " "
        if line.strip():
            print(line)

    # ── Alpha signals ──
    if out["alpha_signals"]:
        print(f"\n  Active signals:")
        for s in out["alpha_signals"][:4]:
            icon = "🔴" if s["type"] == "CRASH_WARNING" else "🟢"
            print(f"  {icon} [{s['conf']:.0f}%] {s['src']}")
            print(f"       → {', '.join(s['assets'][:3])}")

    # ── Portfolio ──
    print(f"\n  {'─'*W}")
    print(f"  PORTFOLIO [{out['portfolio_profile']}]"
          f"{'  ✦ alpha-adjusted' if out['alpha_adj'] else ''}")
    for asset, w in sorted(out["weights"].items(), key=lambda x: -x[1]):
        if w > 0.5:
            b = "█" * int(w / 3)
            print(f"  {asset:<22} {w:5.1f}%  {b}")

    print(f"\n  Risk metrics (30-day, 400 scenarios):")
    print(f"    Expected return:   {out['exp_ret']:+.1f}%")
    print(f"    CVaR (worst 5%):   {out['cvar']:.1f}%")
    print(f"    Sharpe ratio:      {out['sharpe']:.2f}")
    safe = "✓ SAFE" if out["is_safe"] else "✗ UNSAFE"
    print(f"    Safety:            {safe}  (limit {out['cvar_limit']:.0f}%)")

    print(f"\n  ACTION: {out['action']}")
    print(f"{'═'*W}")
    print(f"  Logged → {LOG_FILE}")
    print(f"{'═'*W}")


# ══════════════════════════════════════════════════════════
# LOG
# ══════════════════════════════════════════════════════════
def save_log(out: Dict):
    existing = []
    if os.path.exists(LOG_FILE):
        try:
            with open(LOG_FILE) as f:
                existing = json.load(f)
        except Exception:
            existing = []
    existing = [e for e in existing if e.get("date") != out["date"]]
    existing.append({k: v for k, v in out.items()
                     if not isinstance(v, (np.ndarray, pd.Series))})
    with open(LOG_FILE, "w") as f:
        json.dump(existing[-90:], f, indent=2, default=str)


# ══════════════════════════════════════════════════════════
# HISTORY VIEW
# ══════════════════════════════════════════════════════════
def show_history():
    if not os.path.exists(LOG_FILE):
        print("No history yet. Run: python finshield.py")
        return
    with open(LOG_FILE) as f:
        log = json.load(f)
    print(f"\n{'Date':12s} {'Signal':28s} {'Crash%':>7s} "
          f"{'Buy%':>6s} {'Ret%':>6s} {'CVaR%':>6s}")
    print("─" * 72)
    for e in log[-30:]:
        print(f"{e.get('date',''):12s} "
              f"{e.get('signal','')[:28]:28s} "
              f"{e.get('crash_prob_pct',0):>7.1f} "
              f"{e.get('buy_prob_pct',0):>6.1f} "
              f"{e.get('exp_ret',0):>6.1f} "
              f"{e.get('cvar',0):>6.1f}")


# ══════════════════════════════════════════════════════════
# MAIN PIPELINE
# ══════════════════════════════════════════════════════════
def run(fast: bool = False, risk: str = "medium",
        n_scenarios: int = 400) -> Dict:

    date = datetime.now().strftime("%Y-%m-%d")
    time_str = datetime.now().strftime("%H:%M")
    rp   = RISK_PROFILES.get(risk, RISK_PROFILES["medium"])

    print("═"*65)
    print("  FINSHIELD — COMPLETE INTELLIGENCE PIPELINE")
    print(f"  {date}  |  Risk: {rp['label']}")
    print("═"*65)

    # ── Layer 1: Macro signals ──
    print("\n[1/6] Macro stress index...")
    signals = load_all_signals()
    results = run_full_pipeline(signals)
    score   = results["score"]
    snap    = get_current_snapshot(results)
    stress  = snap["stress_score"]
    regime  = snap["regime"]
    print(f"  Stress: {stress:.1f}/100 ({regime.upper()})")

    # ── Layer 2: News ──
    print("\n[2/6] News + sentiment (20+ sources)...")
    if fast:
        print("  Skipped (--fast)")
        news = {"crash_signal":0,"buy_signal":0,"geo_risk_score":0,
                "active_hotspots":[],"top_crash_stories":[],
                "top_buy_stories":[],"total_articles":0}
    else:
        news = run_news_pipeline()
        print(f"  {news['total_articles']} articles | "
              f"crash:{news['crash_articles']} | "
              f"buy:{news['buy_articles']}")
        geo_from_news = news.get("geo_risk_score", 0)
        hotspots = news.get("active_hotspots", [])
        if hotspots:
            print(f"  ⚠ Hotspots detected: {', '.join(h.title() for h in hotspots)}")
            print(f"  Geo risk score: {geo_from_news:.1f}/100")

    # ── Layer 3: Enhanced live data ──
    print("\n[3/6] Enhanced live data (Fear&Greed, NSE, yfinance, GDELT)...")
    enh_fetcher = EnhancedDataFetcher()
    enhanced    = enh_fetcher.fetch_all(verbose=not fast)
    enh_comp    = enhanced.get("composite", {})
    print(f"  F&G:{enh_comp.get('fear_greed_score',50)} | "
          f"India VIX:{enh_comp.get('india_vix_live',0):.1f} | "
          f"FII:₹{enh_comp.get('fii_flow_crore',0):+.0f}Cr | "
          f"crash:{enh_comp.get('crash_score',0):.0f}")

    # ── Layer 4: Missing sources ──
    print("\n[4/6] Options, insider, patents, IMF, earnings...")
    miss_fetcher = CompleteMissingSourcesFetcher()
    missing      = miss_fetcher.fetch_all(verbose=not fast)
    miss_comp    = missing.get("composite", {})
    print(f"  P/C:{miss_comp.get('put_call_ratio',0.8):.2f} | "
          f"insider:{miss_comp.get('insider_signal','N/A')} | "
          f"patents:{miss_comp.get('patent_trend','N/A')} | "
          f"IMF:{miss_comp.get('imf_india_growth',0):.1f}%")

    # ── Forex Factory + Economic Calendar ──
    print("\n[4b/6] Forex Factory + economic calendar...")

    cal_crash, cal_buy, cal_events = 0, 0, []
    try:
        from forex_calendar import EconomicCalendarAggregator
        cal_agg  = EconomicCalendarAggregator()
        cal_data = cal_agg.fetch_all_events()
        cal_crash = cal_data.get("crash_score", 0)
        cal_buy   = cal_data.get("buy_score",   0)
        cal_events= cal_data.get("key_events",  [])
        print(f"  {cal_data['total_events']} events | high-impact:{cal_data['high_impact']} | crash:{cal_crash:.0f} buy:{cal_buy:.0f}")
        if cal_events:
            print(f"  Top event: {cal_events[0]['title']}")
        # Blend into missing sources signals
        miss_comp["crash_score"] = miss_comp.get("crash_score",0)*0.6 + cal_crash*0.4
        miss_comp["buy_score"]   = miss_comp.get("buy_score",0)*0.6   + cal_buy*0.4
    except Exception as e:
        print(f"  Calendar unavailable: {e}")

    # ── Layer 5: Alpha agent ──
    print("\n[5/6] Alpha research agent (LLM + geopolitics)...")
    enriched = {**news,
                "geo_risk_score": max(news.get("geo_risk_score",0),
                                     enh_comp.get("geo_conflict_score",0))}
    agent  = LLMAlphaAgent()
    alpha  = agent.research(enriched, stress_score=stress)
    print(f"  {alpha['n_signals']} signals | "
          f"crash:{alpha['crash_prob']*100:.0f}% | "
          f"buy:{alpha['buy_prob']*100:.0f}% | "
          f"LLM:{alpha['enhanced']}")

    # ── Early warning model ──
    print("  Running early warning model...")
    if os.path.exists(EW_PATH):
        ew_model = EarlyWarningModel.load(EW_PATH)
    else:
        print("  Training early warning model (first run ~2 min)...")
        ew_model = EarlyWarningModel()
        ew_model.train(signals, score, lstm_epochs=60)
        ew_model.save()
    ew_warn = ew_model.predict_today(signals, score)
    ew_prob = ew_warn["probability"]
    print(f"  EW crash prob: {ew_prob:.1f}% ({ew_warn['alert']})")

    # ── Geopolitical baseline (ensures conflicts are always counted) ──
    # Even when news feeds are blocked, we detect geo risk from
    # multiple sources: alpha signals, forex calendar, news hotspots
    geo_from_alpha    = alpha.get("geo_risk", 0) * 100
    geo_from_news     = news.get("geo_risk_score", 0)
    geo_from_enhanced = enh_comp.get("geo_conflict_score", 0)
    geo_from_calendar = cal_crash * 0.5  # calendar crash = geopolitical event
    geo_from_hotspots = len(news.get("active_hotspots", [])) * 20.0

    # Also detect from alpha signals directly
    geo_from_signals = sum(
        s.get("confidence", 0) * 100
        for s in alpha.get("signals", [])
        if "Geopolitical" in s.get("source", "")
    )

    final_geo_score = max(
        geo_from_alpha, geo_from_news, geo_from_enhanced,
        geo_from_calendar, geo_from_hotspots, geo_from_signals
    )

    print(f"  Geo risk sources: "
          f"alpha={geo_from_alpha:.0f} "
          f"news={geo_from_news:.0f} "
          f"calendar={geo_from_calendar:.0f} "
          f"hotspots={geo_from_hotspots:.0f} "
          f"→ final={final_geo_score:.0f}/100")

    # ── Combine all signals ──
    combined = combine_signals(
        stress=stress,
        ew_prob=ew_prob,
        news_crash=news.get("crash_signal", 0),
        news_buy=news.get("buy_signal", 0),
        enh_crash=enh_comp.get("crash_score", 0),
        enh_buy=enh_comp.get("buy_score", 0),
        miss_crash=miss_comp.get("crash_score", 0),
        miss_buy=miss_comp.get("buy_score", 0),
        alpha_crash=alpha["crash_prob"],
        alpha_buy=alpha["buy_prob"],
        geo_score=final_geo_score,
    )

    # ── Layer 6: Portfolio ──
    print(f"\n[6/6] Building portfolio "
          f"(crash={combined['crash_prob']*100:.0f}%, "
          f"buy={combined['buy_prob']*100:.0f}%)...")
    mc_engine     = MonteCarloEngine(horizon=30, df_t=7)
    current_state = signals.iloc[-1].values.astype(np.float32)
    hints         = alpha.get("allocation_hint", {})
    portfolio     = build_portfolio(
        crash_prob=combined["crash_prob"],
        current_state=current_state,
        mc_engine=mc_engine,
        regime=regime,
        max_cvar=rp["max_cvar"],
        n_scenarios=n_scenarios,
        alpha_hints=hints,
    )

    # ── Action ──
    if combined["crash_prob"] > 0.65:
        action = "Move to maximum defensive. Reduce equity, raise bonds + gold."
    elif combined["crash_prob"] > 0.45:
        action = "Trim high-beta exposure. Raise defensive allocation."
    elif combined["buy_prob"] > 0.55:
        action = "Selective accumulation. Increase signalled assets."
    else:
        action = "Hold current allocation. Monitor for changes."

    # ── Build output dict ──
    out = {
        "date":      date,
        "time":      time_str,
        "icon":      combined["icon"],
        "signal":    combined["label"],

        # Probabilities
        "crash_prob_pct": round(combined["crash_prob"]*100, 1),
        "buy_prob_pct":   round(combined["buy_prob"]*100,   1),
        "geo_risk_pct":   round(combined["geo_risk"]*100,   1),
        "breakdown":      combined["breakdown"],

        # Stress
        "stress_score":      round(stress, 1),
        "stress_regime":     regime,
        "stress_trend":      snap["trend"],
        "stress_categories": {cat: info["percentile"]
                               for cat, info in snap["categories"].items()},

        # Live market
        "fear_greed":     enh_comp.get("fear_greed_score", 50),
        "sentiment":      enh_comp.get("market_sentiment", "NEUTRAL"),
        "india_vix":      enh_comp.get("india_vix_live", 0),
        "nifty_pct":      enh_comp.get("nifty_change_pct", 0),
        "fii_flow":       enh_comp.get("fii_flow_crore", 0),
        "fii_source":     enhanced.get("nse_fii", {}).get("source", "est"),
        "us_vix":         enh_comp.get("vix_live", 0),
        "yield_spread":   enh_comp.get("yield_spread", 0),
        "put_call":       miss_comp.get("put_call_ratio", 0.8),
        "options_signal": miss_comp.get("options_signal", "NEUTRAL"),
        "insider_signal": miss_comp.get("insider_signal", "N/A"),
        "imf_gdp":        miss_comp.get("imf_india_growth", 0),
        "imf_signal":     miss_comp.get("imf_signal", "STABLE"),
        "patent_trend":   miss_comp.get("patent_trend", "N/A"),

        # Early warning
        "ew_prob":    round(ew_prob, 1),
        "ew_alert":   ew_warn["alert"],
        "ew_rec":     ew_warn["recommendation"],
        "ew_drivers": ew_warn.get("top_drivers", []),

        # News
        "hotspots":   news.get("active_hotspots", []),
        "crash_news": [s["title"] for s in
                      news.get("top_crash_stories",[])[:3]],
        "buy_news":   [s["title"] for s in
                      news.get("top_buy_stories",[])[:3]],

        # Alpha
        "thesis": alpha.get("llm_thesis") or alpha.get("thesis",""),
        "alpha_signals": [
            {"type": s["type"],
             "src":  s["source"],
             "conf": s["confidence"]*100,
             "assets": s["assets"]}
            for s in alpha.get("signals",[])[:5]
        ],

        # Portfolio
        "portfolio_profile": portfolio.get("profile_label", rp["label"]),
        "weights": {k: round(v*100,1) for k,v in
                    portfolio["weights_named"].items() if v > 0.005},
        "exp_ret":   round(portfolio["expected_ret"]*100, 1),
        "cvar":      round(portfolio["cvar"]*100, 1),
        "sharpe":    round(portfolio["sharpe"], 2),
        "is_safe":   portfolio["is_safe"],
        "cvar_limit":round(rp["max_cvar"]*100, 1),
        "alpha_adj": portfolio.get("alpha_adjusted", False),
        "action":    action,
        "calendar_events": [e["title"] for e in
                            cal_events[:3]] if "cal_events" in dir() else [],
    }

    print_report(out)
    save_log(out)
    return out


# ══════════════════════════════════════════════════════════
# ENTRY POINT
# ══════════════════════════════════════════════════════════
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="FinShield — Complete Market Intelligence"
    )
    parser.add_argument("--fast",      action="store_true",
                        help="Skip slow sources (~45 sec)")
    parser.add_argument("--risk",      choices=["low","medium","high"],
                        default="medium")
    parser.add_argument("--scenarios", type=int, default=400)
    parser.add_argument("--history",   action="store_true",
                        help="Show signal history")
    parser.add_argument("--backtest",  action="store_true",
                        help="Run historical backtest")
    args = parser.parse_args()

    import argparse

    if args.history:
        show_history()
    elif args.backtest:
        from compare_portfolios import generate_comparison_report
        from early_warning import EarlyWarningModel, LSTMNet
        sigs = load_all_signals()
        res  = run_full_pipeline(sigs)
        mc   = MonteCarloEngine(horizon=30, df_t=7)
        if os.path.exists(EW_PATH):
            mdl = EarlyWarningModel.load(EW_PATH)
        else:
            mdl = EarlyWarningModel()
            mdl.train(sigs, res["score"], lstm_epochs=60)
            mdl.save()
        generate_comparison_report(sigs, res["score"], mc, mdl,
                                   "finshield_backtest.pdf")
    else:
        run(fast=args.fast, risk=args.risk,
            n_scenarios=args.scenarios)
