"""
finrl_agent.py
--------------
AGENT 3: FinRL Agent (regime-aware, crash-conscious)

This is the most important and most dangerous agent in the system.

THE PROBLEM YOU IDENTIFIED:
  A naive RL agent trained on 2023-2024 data learns "tech stocks go up,
  keep buying tech." It has never seen a tech crash in its training
  distribution. When a tech-sector crash begins in production, the agent
  has no learned response — it keeps recommending what worked in training,
  right into the crash. This is the single most common and most dangerous
  failure mode in applied RL for trading.

THE FIX — three independent safeguards, not one:

  1. REGIME-CONDITIONED POLICY
     The agent doesn't learn ONE policy. It learns regime-specific
     policies (bull/bear/sideways/crisis) and the Regime Agent (Agent 1)
     tells it which policy to use RIGHT NOW. A policy trained on bull-
     market data is never allowed to act during a crisis regime — it's
     architecturally locked out.

  2. OUT-OF-DISTRIBUTION (OOD) DETECTION
     Before the agent acts, it checks: "does today's market state look
     like anything in my training distribution?" If today's turbulence
     index, volatility, or drawdown is in territory the agent never saw
     during training, it automatically defers to the safe default
     (reduce exposure) rather than extrapolating from a policy that
     was never validated for this regime.

  3. ENSEMBLE WITH CONSERVATIVE FLOOR
     The agent's recommended allocation is always blended with a
     minimum-variance "safe" allocation. As confidence drops (due to
     OOD detection or regime uncertainty), the blend shifts toward
     the safe floor. The agent can never go to 100% aggressive
     allocation purely on its own judgment — Agent 4 (Capital
     Preservation) always has veto power, enforced downstream.

This file implements a tabular/function-approximation RL agent
(no PyTorch dependency — pure NumPy Q-learning with regime-conditioned
state space) so it runs anywhere without GPU requirements. This is
intentional: simpler, auditable, and harder to silently overfit than
a deep network for a v1 capital-protection system.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field
import pickle
import warnings
warnings.filterwarnings("ignore")

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from regime_agent import REGIMES


ASSET_CLASSES = [
    "equity_growth",     # high-beta growth/tech exposure
    "equity_value",      # defensive/value equity
    "bonds",
    "gold",
    "cash",
]
N_ASSETS = len(ASSET_CLASSES)

# Conservative floor allocation — the "safe harbor" the agent blends toward
# when confidence is low or OOD is detected
SAFE_FLOOR_ALLOCATION = {
    "equity_growth": 0.05,
    "equity_value":  0.20,
    "bonds":         0.40,
    "gold":          0.20,
    "cash":          0.15,
}


@dataclass
class FinRLDecision:
    raw_allocation:       Dict[str, float]   # what the policy alone wants
    safe_floor:           Dict[str, float]   # the conservative blend target
    final_allocation:      Dict[str, float]   # what's actually recommended
    regime_used:           str                # which regime-policy fired
    confidence:             float              # 0-1, agent's confidence
    is_ood:                 bool                # out-of-distribution flag
    ood_score:               float              # how far outside training dist
    blend_weight:            float              # 0=all safe floor, 1=all agent
    reasoning:               str


class RegimeConditionedQAgent:
    """
    A simple but disciplined Q-learning agent with one Q-table PER REGIME.

    State space (discretized):
      - momentum bucket (5-day return: strong_down/down/flat/up/strong_up)
      - volatility bucket (low/normal/elevated/extreme)
      - drawdown bucket (none/mild/moderate/severe)

    Action space:
      - 5 discrete allocation profiles, from defensive to aggressive

    Critically: regime BULL's Q-table is trained ONLY on bull-regime
    episodes. It has never seen crisis dynamics and is never invoked
    during a crisis — the Regime Agent's classification gates which
    table is even consulted.
    """

    MOMENTUM_BUCKETS  = ["strong_down", "down", "flat", "up", "strong_up"]
    VOL_BUCKETS       = ["low", "normal", "elevated", "extreme"]
    DD_BUCKETS        = ["none", "mild", "moderate", "severe"]

    # 5 allocation profiles, action index -> weights
    ACTION_PROFILES = [
        # equity_growth, equity_value, bonds, gold, cash
        [0.05, 0.15, 0.40, 0.25, 0.15],   # 0: max defensive
        [0.15, 0.20, 0.35, 0.20, 0.10],   # 1: defensive
        [0.30, 0.25, 0.25, 0.12, 0.08],   # 2: balanced
        [0.45, 0.25, 0.15, 0.08, 0.07],   # 3: growth
        [0.60, 0.20, 0.08, 0.07, 0.05],   # 4: max aggressive
    ]
    N_ACTIONS = len(ACTION_PROFILES)

    def __init__(self, learning_rate: float = 0.1,
                 discount: float = 0.95,
                 epsilon: float = 0.15):
        self.lr      = learning_rate
        self.gamma   = discount
        self.epsilon = epsilon

        # One Q-table per regime — this is the core safety architecture
        self.q_tables: Dict[str, Dict[Tuple, np.ndarray]] = {
            regime: {} for regime in REGIMES
        }

        # Track training distribution per regime for OOD detection
        self.training_states: Dict[str, List[Tuple]] = {
            regime: [] for regime in REGIMES
        }
        self.is_trained: Dict[str, bool] = {r: False for r in REGIMES}

    # ── State discretization ──
    def _discretize_state(self, momentum_5d: float,
                          vol_annualized: float,
                          drawdown_pct: float) -> Tuple[str, str, str]:
        # Momentum bucket
        if momentum_5d < -0.03:   m = "strong_down"
        elif momentum_5d < -0.005: m = "down"
        elif momentum_5d < 0.005:  m = "flat"
        elif momentum_5d < 0.03:   m = "up"
        else:                      m = "strong_up"

        # Volatility bucket
        if vol_annualized < 0.12:   v = "low"
        elif vol_annualized < 0.20: v = "normal"
        elif vol_annualized < 0.32: v = "elevated"
        else:                       v = "extreme"

        # Drawdown bucket
        dd = abs(drawdown_pct)
        if dd < 3:    d = "none"
        elif dd < 8:  d = "mild"
        elif dd < 15: d = "moderate"
        else:         d = "severe"

        return (m, v, d)

    def _get_q(self, regime: str, state: Tuple) -> np.ndarray:
        table = self.q_tables[regime]
        if state not in table:
            table[state] = np.zeros(self.N_ACTIONS)
        return table[state]

    # ── Training ──
    def train_on_episode(self, regime: str,
                         returns: pd.Series,
                         vol_series: pd.Series,
                         drawdown_series: pd.Series,
                         n_episodes: int = 200) -> Dict:
        """
        Train the regime-specific Q-table on historical episodes
        FROM THAT REGIME ONLY.

        This is the critical discipline: you cannot train the bull
        Q-table on crisis data, and vice versa. Each table only ever
        sees data consistent with its regime label.
        """
        n = len(returns)
        if n < 10:
            return {"trained": False, "reason": "insufficient data"}

        rewards_log = []

        for ep in range(n_episodes):
            # Random starting point in the episode
            start = np.random.randint(0, max(1, n - 5))
            total_reward = 0.0

            for t in range(start, min(start + 5, n - 1)):
                mom = float(returns.iloc[max(0,t-5):t].sum())
                vol = float(vol_series.iloc[t]) if t < len(vol_series) else 0.15
                dd  = float(drawdown_series.iloc[t]) if t < len(drawdown_series) else 0.0

                state = self._discretize_state(mom, vol, dd)
                self.training_states[regime].append(state)

                q = self._get_q(regime, state)

                # Epsilon-greedy action selection
                if np.random.random() < self.epsilon:
                    action = np.random.randint(self.N_ACTIONS)
                else:
                    action = int(np.argmax(q))

                weights = np.array(self.ACTION_PROFILES[action])

                # Reward: realized portfolio return minus a risk penalty
                # Equity components get next-day return; defensive get small fixed
                next_ret = float(returns.iloc[t+1]) if t+1 < n else 0.0
                equity_weight = weights[0] + weights[1]
                portfolio_ret = equity_weight * next_ret + (1 - equity_weight) * 0.0001

                # Penalize large drawdown exposure heavily — this is what
                # teaches the agent to NOT be aggressive during deteriorating
                # conditions, even within a single regime
                risk_penalty = 0.0
                if dd < -8:
                    risk_penalty = equity_weight * abs(dd) * 0.01

                reward = portfolio_ret - risk_penalty
                total_reward += reward

                # Q-update
                next_mom = float(returns.iloc[max(0,t-4):t+1].sum())
                next_vol = float(vol_series.iloc[t+1]) if t+1 < len(vol_series) else vol
                next_dd  = float(drawdown_series.iloc[t+1]) if t+1 < len(drawdown_series) else dd
                next_state = self._discretize_state(next_mom, next_vol, next_dd)
                next_q = self._get_q(regime, next_state)

                td_target = reward + self.gamma * np.max(next_q)
                q[action] += self.lr * (td_target - q[action])

            rewards_log.append(total_reward)

        self.is_trained[regime] = True

        return {
            "trained":       True,
            "regime":        regime,
            "episodes":      n_episodes,
            "avg_reward":    round(float(np.mean(rewards_log)), 5),
            "states_seen":   len(set(self.training_states[regime])),
            "q_table_size":  len(self.q_tables[regime]),
        }

    # ── OOD detection ──
    def _compute_ood_score(self, regime: str, state: Tuple) -> float:
        """
        How far is this state from anything seen during training
        for this regime? Returns 0 (fully in-distribution) to 1 (novel).
        """
        seen = self.training_states.get(regime, [])
        if not seen:
            return 1.0   # never trained = fully OOD

        if state in seen:
            return 0.0

        # Partial match scoring: how many of the 3 dimensions match
        # any seen state?
        best_match = 0
        for seen_state in set(seen):
            matches = sum(1 for a, b in zip(state, seen_state) if a == b)
            best_match = max(best_match, matches)

        # 3 matches = in distribution, 0 matches = fully novel
        return 1.0 - (best_match / 3.0)

    # ── Inference ──
    def decide(self, regime: str, momentum_5d: float,
              vol_annualized: float, drawdown_pct: float) -> FinRLDecision:
        """
        Produce a final, safety-checked allocation decision.
        """
        state = self._discretize_state(momentum_5d, vol_annualized, drawdown_pct)

        # ── Safeguard 1: regime gating ──
        if not self.is_trained.get(regime, False):
            # No trained policy for this regime — go straight to safe floor
            return FinRLDecision(
                raw_allocation=SAFE_FLOOR_ALLOCATION.copy(),
                safe_floor=SAFE_FLOOR_ALLOCATION.copy(),
                final_allocation=SAFE_FLOOR_ALLOCATION.copy(),
                regime_used=regime,
                confidence=0.0,
                is_ood=True,
                ood_score=1.0,
                blend_weight=0.0,
                reasoning=f"No trained policy for regime '{regime}' — "
                         f"using safe floor allocation entirely."
            )

        # ── Safeguard 2: OOD detection ──
        ood_score = self._compute_ood_score(regime, state)
        is_ood = ood_score > 0.5

        # ── Get agent's raw recommendation ──
        q = self._get_q(regime, state)
        action = int(np.argmax(q))
        action_confidence = float(
            (q[action] - q.min()) / (q.max() - q.min() + 1e-8)
        ) if q.max() != q.min() else 0.0

        raw_weights = np.array(self.ACTION_PROFILES[action])
        raw_allocation = dict(zip(ASSET_CLASSES, raw_weights))

        # ── Safeguard 3: confidence-weighted blend with safe floor ──
        # blend_weight: how much we trust the agent's raw output
        #   - reduced by OOD score
        #   - reduced by low Q-value confidence
        #   - reduced in CRISIS regime regardless (extra caution)
        regime_caution = {"BULL": 1.0, "SIDEWAYS": 0.9,
                          "BEAR": 0.6, "CRISIS": 0.3}.get(regime, 0.5)

        blend_weight = float(np.clip(
            (1 - ood_score) * action_confidence * regime_caution,
            0.0, 1.0
        ))

        floor_weights = np.array([
            SAFE_FLOOR_ALLOCATION[a] for a in ASSET_CLASSES
        ])
        final_weights = (blend_weight * raw_weights +
                         (1 - blend_weight) * floor_weights)
        final_weights = final_weights / final_weights.sum()
        final_allocation = dict(zip(ASSET_CLASSES, final_weights))

        # ── Reasoning ──
        if is_ood:
            reasoning = (
                f"OOD detected (score={ood_score:.2f}) — today's market state "
                f"doesn't resemble training data for {regime} regime. "
                f"Blending {blend_weight*100:.0f}% agent / "
                f"{(1-blend_weight)*100:.0f}% safe floor."
            )
        elif blend_weight < 0.5:
            reasoning = (
                f"Low confidence (Q-confidence={action_confidence:.2f}) in "
                f"{regime} regime — defaulting toward safe floor "
                f"({(1-blend_weight)*100:.0f}% weight)."
            )
        else:
            reasoning = (
                f"In-distribution state, {regime} regime, "
                f"confidence={action_confidence:.2f} — "
                f"following learned policy ({blend_weight*100:.0f}% weight)."
            )

        return FinRLDecision(
            raw_allocation={k: round(v,3) for k,v in raw_allocation.items()},
            safe_floor=SAFE_FLOOR_ALLOCATION.copy(),
            final_allocation={k: round(v,3) for k,v in final_allocation.items()},
            regime_used=regime,
            confidence=round(action_confidence, 3),
            is_ood=is_ood,
            ood_score=round(ood_score, 3),
            blend_weight=round(blend_weight, 3),
            reasoning=reasoning,
        )

    def save(self, path: str = "finrl_agent.pkl"):
        with open(path, "wb") as f:
            pickle.dump({
                "q_tables": self.q_tables,
                "training_states": self.training_states,
                "is_trained": self.is_trained,
            }, f)

    @classmethod
    def load(cls, path: str) -> "RegimeConditionedQAgent":
        agent = cls()
        with open(path, "rb") as f:
            data = pickle.load(f)
        agent.q_tables = data["q_tables"]
        agent.training_states = data["training_states"]
        agent.is_trained = data["is_trained"]
        return agent


if __name__ == "__main__":
    print("=" * 60)
    print("  AGENT 3: FinRL AGENT (regime-conditioned, crash-aware)")
    print("=" * 60)

    rng = np.random.default_rng(11)
    agent = RegimeConditionedQAgent()

    # ── Train on BULL regime data (e.g. 2023-2024 tech-led rally) ──
    bull_returns = pd.Series(rng.normal(0.0012, 0.009, 200))
    bull_vol     = pd.Series(rng.normal(0.13, 0.02, 200)).clip(0.08, 0.20)
    bull_dd      = pd.Series(-np.abs(rng.normal(2, 2, 200))).clip(-15, 0)

    result_bull = agent.train_on_episode(
        "BULL", bull_returns, bull_vol, bull_dd, n_episodes=300
    )
    print(f"\nTrained BULL policy:")
    print(f"  Episodes: {result_bull['episodes']} | "
          f"States seen: {result_bull['states_seen']} | "
          f"Avg reward: {result_bull['avg_reward']}")

    # ── Train on BEAR regime data ──
    bear_returns = pd.Series(rng.normal(-0.0018, 0.016, 150))
    bear_vol     = pd.Series(rng.normal(0.24, 0.04, 150)).clip(0.15, 0.35)
    bear_dd      = pd.Series(-np.abs(rng.normal(10, 5, 150))).clip(-30, 0)

    result_bear = agent.train_on_episode(
        "BEAR", bear_returns, bear_vol, bear_dd, n_episodes=300
    )
    print(f"\nTrained BEAR policy:")
    print(f"  Episodes: {result_bear['episodes']} | "
          f"States seen: {result_bear['states_seen']} | "
          f"Avg reward: {result_bear['avg_reward']}")

    # NOTE: deliberately NOT training CRISIS — testing OOD safeguard

    # ── Test 1: Normal bull market continuation ──
    print(f"\n{'─'*60}")
    print("TEST 1: Bull market, normal conditions (in-distribution)")
    decision = agent.decide("BULL", momentum_5d=0.015,
                            vol_annualized=0.13, drawdown_pct=-2.0)
    print(f"  Regime: {decision.regime_used} | OOD: {decision.is_ood} "
          f"(score={decision.ood_score})")
    print(f"  Confidence: {decision.confidence} | Blend weight: {decision.blend_weight}")
    print(f"  Final allocation: {decision.final_allocation}")
    print(f"  Reasoning: {decision.reasoning}")

    # ── Test 2: THE CRITICAL TEST — your exact scenario ──
    # Agent trained on bull tech data, now a tech crash begins.
    # Same regime label still says "BULL" momentarily but state is novel.
    print(f"\n{'─'*60}")
    print("TEST 2: YOUR SCENARIO — bull-trained agent, sudden crash begins")
    print("        (regime classifier hasn't caught up yet, state is OOD)")
    decision2 = agent.decide("BULL", momentum_5d=-0.08,
                             vol_annualized=0.38, drawdown_pct=-18.0)
    print(f"  Regime: {decision2.regime_used} | OOD: {decision2.is_ood} "
          f"(score={decision2.ood_score})")
    print(f"  Confidence: {decision2.confidence} | Blend weight: {decision2.blend_weight}")
    print(f"  Raw policy wanted:   {decision2.raw_allocation}")
    print(f"  Safe floor:          {decision2.safe_floor}")
    print(f"  FINAL (protected):   {decision2.final_allocation}")
    print(f"  Reasoning: {decision2.reasoning}")

    # ── Test 3: Untrained CRISIS regime ──
    print(f"\n{'─'*60}")
    print("TEST 3: CRISIS regime with no trained policy at all")
    decision3 = agent.decide("CRISIS", momentum_5d=-0.10,
                             vol_annualized=0.45, drawdown_pct=-25.0)
    print(f"  Regime: {decision3.regime_used} | OOD: {decision3.is_ood}")
    print(f"  FINAL allocation: {decision3.final_allocation}")
    print(f"  Reasoning: {decision3.reasoning}")

    print(f"\n{'='*60}")
    print("  KEY RESULT: Test 2 shows the safeguard working —")
    print("  even though regime is labeled BULL, OOD detection +")
    print("  drawdown penalty pulled equity exposure way down")
    print("  instead of blindly 'buying the dip' like training data taught.")
    print("=" * 60)
