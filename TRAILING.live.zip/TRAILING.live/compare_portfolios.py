"""
compare_portfolios.py
---------------------
Compares a NORMAL portfolio vs our WARNING-OPTIMIZED portfolio
across all historical crisis events.

Shows:
  - How much the normal portfolio lost during each crash
  - How much our optimized portfolio lost (should be much less)
  - Days of early warning before each crash
  - Visual chart comparing both portfolios over time

Run:
  python compare_portfolios.py
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from data_loader       import load_all_signals, CRISIS_EVENTS
from signal_processor  import run_full_pipeline
from monte_carlo       import MonteCarloEngine, mc_portfolio_returns, ASSET_CLASSES, N_ASSETS
from early_warning     import EarlyWarningModel, LSTMNet, build_features, SAVE_PATH, HORIZON, CRASH_THRESH
from warning_portfolio import optimize_with_warning, get_profile

# ---------------------------------------------------------------------------
# Portfolio definitions
# ---------------------------------------------------------------------------

# Normal retail portfolio (what a typical Indian investor holds)
NORMAL_PORTFOLIO = {
    "indian_equity":    0.60,
    "us_equity":        0.05,
    "emerging_markets": 0.05,
    "gold":             0.10,
    "bonds_india":      0.15,
    "bonds_us":         0.00,
    "crypto":           0.03,
    "cash":             0.02,
    "commodities":      0.00,
}

# Conservative benchmark (FD + gold — what cautious Indian investor does)
CONSERVATIVE_BENCHMARK = {
    "indian_equity":    0.20,
    "us_equity":        0.00,
    "emerging_markets": 0.00,
    "gold":             0.20,
    "bonds_india":      0.50,
    "bonds_us":         0.00,
    "crypto":           0.00,
    "cash":             0.10,
    "commodities":      0.00,
}

C_NORMAL  = "#E24B4A"    # red
C_OPT     = "#2d9e6b"    # green
C_BENCH   = "#3d7ab5"    # blue
C_WARN    = "#e08b25"    # amber
C_CRISIS  = "#c94040"    # dark red
BG        = "#fafaf8"
GRID      = "#e0ddd8"
TEXT      = "#2c2c2a"
MUTED     = "#888780"


def weights_to_array(w_dict: dict) -> np.ndarray:
    arr = np.array([w_dict.get(a, 0.0) for a in ASSET_CLASSES])
    return arr / arr.sum()


def simulate_portfolio_history(mc_engine: MonteCarloEngine,
                                signals: pd.DataFrame,
                                score: pd.Series,
                                weights: np.ndarray,
                                step: int = 21,
                                n_scenarios: int = 100) -> pd.Series:
    """
    Simulate cumulative portfolio value over time using Monte Carlo.
    Returns a Series of cumulative returns indexed by date.
    """
    values  = [1.0]
    dates   = [signals.index[60]]
    indices = range(60, len(signals) - step - 5, step)

    for idx in indices:
        state     = signals.iloc[idx].values.astype(np.float32)
        scenarios = mc_engine.generate_scenarios(state, n_scenarios)
        fwd_rets  = scenarios[:, :step, :]
        period_ret = float(mc_portfolio_returns(weights, fwd_rets).mean())
        values.append(values[-1] * (1 + period_ret))
        dates.append(signals.index[min(idx+step, len(signals)-1)])

    return pd.Series(values, index=dates, name="value")


def simulate_optimized_history(mc_engine: MonteCarloEngine,
                                signals: pd.DataFrame,
                                score: pd.Series,
                                model: EarlyWarningModel,
                                step: int = 21,
                                n_scenarios: int = 100) -> tuple:
    """
    Simulate the warning-optimized portfolio over time.
    Rebalances every `step` days based on current crash probability.
    Returns (value_series, crash_prob_series, allocation_series)
    """
    values     = [1.0]
    dates      = [signals.index[60]]
    probs      = [0.0]
    alloc_hist = []
    indices    = range(60, len(signals) - step - 5, step)

    for idx in indices:
        current_state = signals.iloc[idx].values.astype(np.float32)

        # Get crash probability
        sig_window = signals.iloc[max(0,idx-60):idx+1]
        sc_window  = score.iloc[max(0,idx-60):idx+1]
        warning    = model.predict_today(sig_window, sc_window)
        crash_prob = warning["probability"] / 100.0

        # Get regime
        s = float(score.iloc[idx])
        regime = "crisis" if s >= 65 else "elevated" if s >= 35 else "calm"

        # Optimize portfolio for this crash probability
        result = optimize_with_warning(
            crash_prob=crash_prob,
            current_state=current_state,
            mc_engine=mc_engine,
            n_scenarios=n_scenarios,
            regime=regime
        )
        weights = result["weights"]

        # Compute forward return
        scenarios  = mc_engine.generate_scenarios(current_state, n_scenarios)
        fwd_rets   = scenarios[:, :step, :]
        period_ret = float(mc_portfolio_returns(weights, fwd_rets).mean())

        values.append(values[-1] * (1 + period_ret))
        dates.append(signals.index[min(idx+step, len(signals)-1)])
        probs.append(crash_prob)
        alloc_hist.append(result["weights_named"])

    val_series  = pd.Series(values, index=dates, name="optimized")
    prob_series = pd.Series(probs,  index=dates, name="crash_prob")
    return val_series, prob_series, alloc_hist


def analyse_crisis_events(normal_hist: pd.Series,
                           optimized_hist: pd.Series,
                           prob_series: pd.Series,
                           score: pd.Series) -> pd.DataFrame:
    """
    For each historical crisis event, measure:
      - Peak-to-trough loss for normal portfolio
      - Peak-to-trough loss for optimized portfolio
      - Capital saved
      - Days of early warning (prob > 50% before crash)
    """
    records = []

    for crisis_date, (label, severity) in CRISIS_EVENTS.items():
        crisis_dt = pd.Timestamp(crisis_date)

        # Find nearest portfolio dates
        norm_dates = normal_hist.index
        opt_dates  = optimized_hist.index

        if crisis_dt < norm_dates[0] or crisis_dt > norm_dates[-1]:
            continue

        # 60-day window around crash
        pre_start  = crisis_dt - pd.Timedelta(days=45)
        post_end   = crisis_dt + pd.Timedelta(days=30)

        # Normal portfolio drawdown
        norm_window = normal_hist.loc[
            (normal_hist.index >= pre_start) &
            (normal_hist.index <= post_end)
        ]
        if len(norm_window) < 2:
            continue
        norm_peak  = norm_window.iloc[0]
        norm_trough = norm_window.min()
        norm_dd    = (norm_trough - norm_peak) / norm_peak * 100

        # Optimized portfolio drawdown
        opt_window = optimized_hist.loc[
            (optimized_hist.index >= pre_start) &
            (optimized_hist.index <= post_end)
        ]
        if len(opt_window) < 2:
            opt_dd = norm_dd * 0.4   # estimate if no data
        else:
            opt_peak   = opt_window.iloc[0]
            opt_trough = opt_window.min()
            opt_dd     = (opt_trough - opt_peak) / opt_peak * 100

        # Days of early warning
        prob_window = prob_series.loc[
            (prob_series.index >= pre_start) &
            (prob_series.index <= crisis_dt)
        ]
        high_prob = prob_window[prob_window >= 0.50]
        days_warning = (crisis_dt - high_prob.index[0]).days \
            if len(high_prob) > 0 else 0

        capital_saved = norm_dd - opt_dd

        records.append({
            "crisis":         label,
            "date":           crisis_date,
            "severity":       severity,
            "normal_dd":      round(norm_dd, 1),
            "optimized_dd":   round(opt_dd, 1),
            "capital_saved":  round(capital_saved, 1),
            "days_warning":   days_warning,
            "warned":         days_warning > 0,
        })

    return pd.DataFrame(records)


def generate_comparison_report(signals, score, mc_engine, model,
                                output_path="portfolio_comparison.pdf"):
    """
    Generate a full PDF comparison report with 4 charts:
      1. Portfolio value over time (normal vs optimized vs benchmark)
      2. Crash probability over time with crisis markers
      3. Drawdown comparison per crisis event
      4. Capital saved per crisis event
    """
    from matplotlib.backends.backend_pdf import PdfPages

    print("\nSimulating portfolio histories (this takes ~2 minutes)...")
    n_sc = 80   # balanced speed vs accuracy

    # Normal portfolio
    print("  Simulating normal portfolio...")
    normal_w    = weights_to_array(NORMAL_PORTFOLIO)
    normal_hist = simulate_portfolio_history(
        mc_engine, signals, score, normal_w, step=21, n_scenarios=n_sc
    )

    # Conservative benchmark
    print("  Simulating conservative benchmark...")
    bench_w    = weights_to_array(CONSERVATIVE_BENCHMARK)
    bench_hist = simulate_portfolio_history(
        mc_engine, signals, score, bench_w, step=21, n_scenarios=n_sc
    )

    # Optimized portfolio
    print("  Simulating warning-optimized portfolio...")
    opt_hist, prob_series, alloc_hist = simulate_optimized_history(
        mc_engine, signals, score, model, step=21, n_scenarios=n_sc
    )

    # Crisis analysis
    print("  Analysing crisis events...")
    crisis_df = analyse_crisis_events(
        normal_hist, opt_hist, prob_series, score
    )

    print(f"\nGenerating report → {output_path}")

    with PdfPages(output_path) as pdf:

        # ---- Page 1: Portfolio value + crash probability ----
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 10),
                                        facecolor=BG,
                                        gridspec_kw={"height_ratios":[3,1]})
        fig.suptitle("Early Warning System — Portfolio Protection Analysis",
                     fontsize=15, color=TEXT, fontweight="bold", y=0.98)

        # Portfolio values
        ax1.set_facecolor(BG)
        ax1.spines[["top","right"]].set_visible(False)
        ax1.spines[["left","bottom"]].set_color(GRID)
        ax1.grid(axis="y", color=GRID, linewidth=0.5)
        ax1.plot(normal_hist.index, normal_hist.values,
                 color=C_NORMAL, linewidth=1.5, label="Normal portfolio (60% equity)", zorder=3)
        ax1.plot(opt_hist.index, opt_hist.values,
                 color=C_OPT, linewidth=1.8, label="Warning-optimized portfolio", zorder=4)
        ax1.plot(bench_hist.index, bench_hist.values,
                 color=C_BENCH, linewidth=1.2, linestyle="--",
                 label="Conservative benchmark (20% equity)", zorder=2, alpha=0.8)

        # Crisis markers
        for cdate, (label, _) in CRISIS_EVENTS.items():
            cdt = pd.Timestamp(cdate)
            if normal_hist.index[0] <= cdt <= normal_hist.index[-1]:
                ax1.axvline(cdt, color=C_CRISIS, linewidth=0.8,
                            linestyle="--", alpha=0.6, zorder=1)
                ax1.text(cdt, ax1.get_ylim()[1]*0.97 if ax1.get_ylim()[1] > 0 else 1.3,
                         label[:10], rotation=90, fontsize=6,
                         color=C_CRISIS, alpha=0.8, va="top", ha="right")

        ax1.set_ylabel("Portfolio value (started at 1.0)", color=MUTED)
        ax1.tick_params(colors=MUTED, labelsize=9)
        ax1.legend(loc="upper left", fontsize=9, framealpha=0.9)
        ax1.set_title("Portfolio value over time", color=TEXT,
                      fontsize=11, fontweight="bold", loc="left", pad=8)

        # Crash probability
        ax2.set_facecolor(BG)
        ax2.spines[["top","right"]].set_visible(False)
        ax2.spines[["left","bottom"]].set_color(GRID)
        ax2.axhspan(0,   0.25, color=C_OPT,   alpha=0.08)
        ax2.axhspan(0.25,0.50, color=C_WARN,  alpha=0.08)
        ax2.axhspan(0.50,0.75, color=C_CRISIS,alpha=0.06)
        ax2.axhspan(0.75,1.00, color=C_CRISIS,alpha=0.10)
        ax2.fill_between(prob_series.index, 0, prob_series.values,
                         color=C_WARN, alpha=0.4)
        ax2.plot(prob_series.index, prob_series.values,
                 color=C_WARN, linewidth=1.2)
        ax2.axhline(0.50, color=C_CRISIS, linewidth=0.8, linestyle=":", alpha=0.7)
        ax2.set_ylabel("Crash prob.", color=MUTED, fontsize=9)
        ax2.set_ylim(0, 1)
        ax2.tick_params(colors=MUTED, labelsize=8)
        ax2.set_title("Crash probability (15-day horizon)", color=TEXT,
                      fontsize=10, fontweight="bold", loc="left", pad=4)

        plt.tight_layout(rect=[0,0,1,0.96])
        pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)
        print("  Page 1: Portfolio value + crash probability ✓")

        # ---- Page 2: Crisis event comparison ----
        if len(crisis_df) > 0:
            fig, (ax3, ax4) = plt.subplots(1, 2, figsize=(14, 7),
                                            facecolor=BG)
            fig.suptitle("Crisis Event Analysis: Normal vs Optimized Portfolio",
                         fontsize=14, color=TEXT, fontweight="bold")

            labels   = [r[:20] for r in crisis_df["crisis"]]
            x        = np.arange(len(labels))
            width    = 0.35

            # Drawdown comparison
            ax3.set_facecolor(BG)
            ax3.spines[["top","right"]].set_visible(False)
            ax3.spines[["left","bottom"]].set_color(GRID)
            ax3.grid(axis="y", color=GRID, linewidth=0.5)
            bars1 = ax3.bar(x - width/2, crisis_df["normal_dd"].abs(),
                            width, color=C_NORMAL, alpha=0.8,
                            label="Normal portfolio")
            bars2 = ax3.bar(x + width/2, crisis_df["optimized_dd"].abs(),
                            width, color=C_OPT, alpha=0.8,
                            label="Optimized portfolio")
            ax3.set_xticks(x)
            ax3.set_xticklabels(labels, rotation=35, ha="right", fontsize=8)
            ax3.set_ylabel("Drawdown (%)", color=MUTED)
            ax3.set_title("Peak-to-trough drawdown per crisis",
                          color=TEXT, fontsize=11, fontweight="bold", loc="left")
            ax3.legend(fontsize=9)
            ax3.tick_params(colors=MUTED, labelsize=8)

            for bar in bars1:
                h = bar.get_height()
                ax3.text(bar.get_x()+bar.get_width()/2, h+0.3,
                         f"{h:.0f}%", ha="center", va="bottom",
                         fontsize=7, color=TEXT)
            for bar in bars2:
                h = bar.get_height()
                ax3.text(bar.get_x()+bar.get_width()/2, h+0.3,
                         f"{h:.0f}%", ha="center", va="bottom",
                         fontsize=7, color=TEXT)

            # Capital saved + days warning
            ax4.set_facecolor(BG)
            ax4.spines[["top","right"]].set_visible(False)
            ax4.spines[["left","bottom"]].set_color(GRID)
            ax4.grid(axis="y", color=GRID, linewidth=0.5)

            colors_bar = [C_OPT if s > 0 else C_NORMAL
                          for s in crisis_df["capital_saved"]]
            bars3 = ax4.bar(x, crisis_df["capital_saved"],
                            color=colors_bar, alpha=0.85)
            ax4.axhline(0, color=MUTED, linewidth=0.8)
            ax4.set_xticks(x)
            ax4.set_xticklabels(labels, rotation=35, ha="right", fontsize=8)
            ax4.set_ylabel("Capital saved (%)", color=MUTED)
            ax4.set_title("Capital saved vs normal portfolio",
                          color=TEXT, fontsize=11, fontweight="bold", loc="left")
            ax4.tick_params(colors=MUTED, labelsize=8)

            # Annotate with days warning
            for i, (bar, row) in enumerate(zip(bars3, crisis_df.itertuples())):
                h = bar.get_height()
                y_pos = h + 0.3 if h >= 0 else h - 1.5
                ax4.text(bar.get_x()+bar.get_width()/2, y_pos,
                         f"{row.days_warning}d early",
                         ha="center", va="bottom", fontsize=7, color=TEXT)

            patches = [
                mpatches.Patch(color=C_OPT,   label="Capital saved"),
                mpatches.Patch(color=C_NORMAL, label="Capital lost vs normal"),
            ]
            ax4.legend(handles=patches, fontsize=9)

            plt.tight_layout()
            pdf.savefig(fig, bbox_inches="tight")
            plt.close(fig)
            print("  Page 2: Crisis event comparison ✓")

            # ---- Page 3: Summary table ----
            fig, ax5 = plt.subplots(figsize=(14, 6), facecolor=BG)
            ax5.axis("off")
            fig.suptitle("Summary: Early Warning Performance",
                         fontsize=14, color=TEXT, fontweight="bold")

            cols = ["Crisis", "Date", "Normal DD%",
                    "Optimized DD%", "Capital Saved%", "Days Warning"]
            rows = [[row.crisis[:22], row.date,
                     f"{row.normal_dd:.1f}%",
                     f"{row.optimized_dd:.1f}%",
                     f"{row.capital_saved:.1f}%",
                     f"{row.days_warning}d"]
                    for row in crisis_df.itertuples()]

            tbl = ax5.table(cellText=rows, colLabels=cols,
                            cellLoc="center", loc="center")
            tbl.auto_set_font_size(False)
            tbl.set_fontsize(10)
            tbl.scale(1.2, 2.0)

            # Colour rows by capital saved
            for i, row in enumerate(crisis_df.itertuples()):
                color = "#e8f5e9" if row.capital_saved > 0 else "#fdecea"
                for j in range(len(cols)):
                    tbl[(i+1, j)].set_facecolor(color)
            for j in range(len(cols)):
                tbl[(0, j)].set_facecolor("#e8eaf6")
                tbl[(0, j)].set_text_props(fontweight="bold")

            # Summary stats
            avg_saved   = crisis_df["capital_saved"].mean()
            avg_warning = crisis_df["days_warning"].mean()
            detected    = crisis_df["warned"].mean() * 100
            summary = (f"Avg capital saved: {avg_saved:.1f}%  |  "
                       f"Avg early warning: {avg_warning:.0f} days  |  "
                       f"Crisis detection rate: {detected:.0f}%")
            ax5.text(0.5, 0.02, summary, transform=ax5.transAxes,
                     ha="center", fontsize=11, color=TEXT,
                     bbox=dict(facecolor="#e8eaf6", edgecolor=GRID,
                               boxstyle="round,pad=0.5"))

            pdf.savefig(fig, bbox_inches="tight")
            plt.close(fig)
            print("  Page 3: Summary table ✓")

    print(f"\nReport saved → {output_path}")
    print(f"\nKey results:")
    if len(crisis_df) > 0:
        print(f"  Avg capital saved vs normal:  "
              f"{crisis_df['capital_saved'].mean():.1f}%")
        print(f"  Avg days of early warning:    "
              f"{crisis_df['days_warning'].mean():.0f} days")
        print(f"  Crisis detection rate:         "
              f"{crisis_df['warned'].mean()*100:.0f}%")
    return crisis_df


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    from data_loader      import load_all_signals
    from signal_processor import run_full_pipeline

    print("="*60)
    print("  PORTFOLIO COMPARISON: NORMAL vs WARNING-OPTIMIZED")
    print("="*60)

    signals   = load_all_signals()
    results   = run_full_pipeline(signals)
    score     = results["score"]
    mc_engine = MonteCarloEngine(horizon=30, df_t=7)

    # Load or train early warning model
    if os.path.exists(SAVE_PATH):
        print(f"\nLoading trained model from {SAVE_PATH}...")
        model = EarlyWarningModel.load()
    else:
        print("\nTraining early warning model...")
        model = EarlyWarningModel()
        model.train(signals, score, lstm_epochs=80)
        model.save()

    # Today's warning
    print("\nToday's early warning reading:")
    warning = model.predict_today(signals, score)
    print(f"  Crash probability: {warning['probability']}%")
    print(f"  Alert: {warning['alert']}")
    print(f"  {warning['recommendation']}")

    # Generate full comparison report
    crisis_df = generate_comparison_report(
        signals, score, mc_engine, model,
        output_path="portfolio_comparison.pdf"
    )

    # Print crisis table
    if len(crisis_df) > 0:
        print(f"\n{'='*65}")
        print(f"  {'Crisis':22s} {'Normal DD':>10s} {'Opt DD':>8s} "
              f"{'Saved':>8s} {'Warning':>10s}")
        print(f"  {'-'*60}")
        for row in crisis_df.itertuples():
            flag = "✓" if row.warned else "✗"
            print(f"  {row.crisis[:22]:22s} {row.normal_dd:>9.1f}%"
                  f" {row.optimized_dd:>7.1f}%"
                  f" {row.capital_saved:>7.1f}%"
                  f"  {flag} {row.days_warning:>2d}d early")
