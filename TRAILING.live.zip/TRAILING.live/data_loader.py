"""
data_loader_v2.py
-----------------
Leakage-aware historical signal loader for TRAILING.live.

Goals:
- NO crisis-date injection
- NO random historical signals
- Use real market series where Yahoo Finance provides them
- Use deterministic market-derived proxies where direct data is unavailable
- Keep the SAME signal column names so the rest of the project remains compatible

Important:
Some fields remain proxies, not official series:
  - yield_curve_spread: 10Y - 3M Treasury proxy from ^TNX and ^IRX
  - credit_spread: HYG vs IEF return-derived proxy
  - ted_spread: deterministic liquidity proxy from VIX + curve stress
  - market_breadth: SPY distance from 200-day moving average proxy
  - put_call_ratio: deterministic VIX-derived sentiment proxy
  - fii_flows: deterministic NIFTY/INR-derived foreign-flow proxy

These are much more defensible than crisis-injected synthetic series, but they
should be labelled as proxies in reports.
"""

import os
import warnings
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

SIGNAL_COLS = [
    "vix", "india_vix", "yield_curve_spread",
    "credit_spread", "ted_spread", "market_breadth",
    "put_call_ratio", "fii_flows", "inr_usd_roc"
]

CACHE_FILE = "historical_signals_real.csv"
YFINANCE_CACHE_DIR = Path(__file__).resolve().parent / ".trailing_cache" / "yfinance"


def _configure_yfinance_cache(yf) -> None:
    """Keep yfinance's SQLite cache inside the writable project cache."""
    YFINANCE_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    yf.set_tz_cache_location(str(YFINANCE_CACHE_DIR))


def _close_series(ticker: str, start: str, end: str) -> pd.Series:
    import yfinance as yf

    _configure_yfinance_cache(yf)

    df = yf.download(
        ticker,
        start=start,
        end=end,
        auto_adjust=True,
        progress=False,
        actions=False,
        threads=False,
    )
    if df is None or len(df) == 0:
        return pd.Series(dtype=float, name=ticker)

    close = df["Close"]
    if isinstance(close, pd.DataFrame):
        close = close.iloc[:, 0]

    close = pd.to_numeric(close, errors="coerce").dropna()
    close.index = pd.DatetimeIndex(close.index).tz_localize(None)
    close.name = ticker
    return close.sort_index()


def _align(series: pd.Series, index: pd.DatetimeIndex, limit: int = 5) -> pd.Series:
    if series is None or len(series) == 0:
        return pd.Series(np.nan, index=index)
    return series.reindex(index).ffill(limit=limit)


def _safe_realized_vol(price: pd.Series, window: int = 20) -> pd.Series:
    ret = price.pct_change()
    return ret.rolling(window, min_periods=max(10, window // 2)).std() * np.sqrt(252) * 100


def _build_real_signal_frame(start: str, end: str) -> pd.DataFrame:
    # Download a small warm-up period so 200-day/20-day features are valid
    warm_start = (pd.Timestamp(start) - pd.Timedelta(days=420)).strftime("%Y-%m-%d")

    print("Downloading real/proxy historical market series...")

    vix = _close_series("^VIX", warm_start, end)
    nifty = _close_series("^NSEI", warm_start, end)
    spy = _close_series("SPY", warm_start, end)
    tnx = _close_series("^TNX", warm_start, end)
    irx = _close_series("^IRX", warm_start, end)
    hyg = _close_series("HYG", warm_start, end)
    ief = _close_series("IEF", warm_start, end)
    usdinr = _close_series("USDINR=X", warm_start, end)

    # Prefer real India VIX if Yahoo provides it; otherwise use realized NIFTY vol.
    india_vix_real = _close_series("^INDIAVIX", warm_start, end)

    downloaded = {
        "^VIX": vix,
        "^NSEI": nifty,
        "SPY": spy,
        "^TNX": tnx,
        "^IRX": irx,
        "HYG": hyg,
        "IEF": ief,
        "USDINR=X": usdinr,
        "^INDIAVIX": india_vix_real,
    }
    if not any(len(series) for series in downloaded.values()):
        raise RuntimeError(
            "Yahoo Finance returned no market data for any required series. "
            "Check network access or Yahoo availability; no fallback data was used."
        )

    # Primary trading calendar: union of US and India sessions.
    calendar = spy.index.union(nifty.index).sort_values()
    calendar = calendar[(calendar >= pd.Timestamp(warm_start)) & (calendar < pd.Timestamp(end))]

    if len(calendar) < 252:
        raise RuntimeError(
            "Not enough real market observations downloaded. "
            "Check internet/yfinance availability."
        )

    vix_a = _align(vix, calendar)
    nifty_a = _align(nifty, calendar)
    spy_a = _align(spy, calendar)
    tnx_a = _align(tnx, calendar)
    irx_a = _align(irx, calendar)
    hyg_a = _align(hyg, calendar)
    ief_a = _align(ief, calendar)
    usdinr_a = _align(usdinr, calendar)

    # 1) VIX — real
    sig_vix = vix_a

    # 2) India VIX — real if available, otherwise deterministic realized-vol proxy
    if len(india_vix_real) > 50:
        sig_india_vix = _align(india_vix_real, calendar)
        india_vix_source = "real ^INDIAVIX"
    else:
        sig_india_vix = _safe_realized_vol(nifty_a, 20)
        india_vix_source = "NIFTY 20d realized-vol proxy"

    # 3) Yield curve — Yahoo has reliable 10Y and 3M index series.
    # ^TNX and ^IRX are already quoted as percentage yields on Yahoo.
    sig_curve = tnx_a - irx_a

    # 4) Credit spread proxy — credit underperformance vs Treasury = wider stress.
    hyg20 = hyg_a.pct_change(20)
    ief20 = ief_a.pct_change(20)
    sig_credit = (5.0 - (hyg20 - ief20) * 100.0).clip(2.0, 20.0)

    # 5) Liquidity/TED proxy — deterministic, no randomness.
    # Higher VIX + curve inversion => greater interbank/liquidity stress proxy.
    curve_stress = (-sig_curve).clip(lower=0)
    vix_stress = ((sig_vix - 15.0) / 20.0).clip(lower=0)
    sig_ted = (0.15 + 0.30 * curve_stress + 0.35 * vix_stress).clip(0.05, 5.0)

    # 6) Market breadth proxy — map SPY distance from its 200DMA to 0..100.
    ma200 = spy_a.rolling(200, min_periods=100).mean()
    dist = spy_a / ma200 - 1.0
    sig_breadth = (50.0 + 50.0 * np.tanh(dist * 12.0)).clip(5.0, 95.0)

    # 7) Put/call sentiment proxy — deterministic VIX transform.
    sig_put_call = (0.70 + 0.018 * (sig_vix - 15.0)).clip(0.45, 2.20)

    # 8) FII-flow proxy — deterministic risk-sensitive proxy.
    # Negative when NIFTY falls and INR weakens.
    nifty5 = nifty_a.pct_change(5).fillna(0.0)
    inr5 = usdinr_a.pct_change(5).fillna(0.0)
    sig_fii = (250000.0 * nifty5 - 180000.0 * inr5).clip(-8000, 5000)

    # 9) INR/USD 10-session rate of change
    sig_inr_roc = usdinr_a.pct_change(10) * 100.0

    signals = pd.DataFrame({
        "vix": sig_vix,
        "india_vix": sig_india_vix,
        "yield_curve_spread": sig_curve,
        "credit_spread": sig_credit,
        "ted_spread": sig_ted,
        "market_breadth": sig_breadth,
        "put_call_ratio": sig_put_call,
        "fii_flows": sig_fii,
        "inr_usd_roc": sig_inr_roc,
    }, index=calendar)

    signals = signals.replace([np.inf, -np.inf], np.nan)
    signals = signals.ffill(limit=5)

    # Require the most important real series to exist.
    required = ["vix", "yield_curve_spread", "market_breadth", "inr_usd_roc"]
    signals = signals.dropna(subset=required)

    # Remaining proxy warm-up NaNs are filled only after sufficient real history exists.
    signals = signals.ffill().bfill()

    signals = signals.loc[(signals.index >= pd.Timestamp(start)) &
                          (signals.index < pd.Timestamp(end))]

    print(f"  India VIX source: {india_vix_source}")
    print(f"  Signals shape: {signals.shape}")
    print(f"  Date range: {signals.index[0].date()} -> {signals.index[-1].date()}")
    print("  Historical signals: REAL market data + deterministic proxies")
    return signals


def load_all_signals(
    start: str = "2007-01-01",
    end: str = None,
    use_cache: bool = True,
    cache_path: str = CACHE_FILE,
    persist_cache: bool = True,
) -> pd.DataFrame:
    """
    Return a causal historical signal DataFrame.

    Unlike the old loader, this function NEVER injects known crisis dates.
    """
    if end is None:
        end = (pd.Timestamp.today().normalize() + pd.Timedelta(days=1)).strftime("%Y-%m-%d")

    if use_cache and os.path.exists(cache_path):
        try:
            cached = pd.read_csv(cache_path, parse_dates=["date"]).set_index("date")
            cached.index = pd.DatetimeIndex(cached.index)
            cached = cached[SIGNAL_COLS].sort_index()

            requested_end = pd.Timestamp(end) - pd.Timedelta(days=1)
            # Use cache only if it is reasonably fresh and covers requested start.
            # A requested calendar start may fall on a weekend/holiday. Accept
            # a small leading gap rather than redownloading an otherwise valid
            # complete trading-day cache (for example 2007-01-01 -> 2007-01-03).
            if (len(cached) > 252 and
                cached.index.min() <= pd.Timestamp(start) + pd.Timedelta(days=7) and
                cached.index.max() >= requested_end - pd.Timedelta(days=7)):
                out = cached.loc[(cached.index >= pd.Timestamp(start)) &
                                 (cached.index < pd.Timestamp(end))].copy()
                if len(out) > 0:
                    print(f"Using cached real/proxy signals: {len(out)} rows")
                    return out
        except Exception:
            pass

    signals = _build_real_signal_frame(start, end)

    if persist_cache:
        try:
            tmp = signals.copy()
            tmp.index.name = "date"
            tmp.to_csv(cache_path)
            print(f"  Cached -> {cache_path}")
        except Exception:
            pass

    return signals


# Kept only for compatibility with historical crisis-report code.
# These dates are NOT used to generate any model feature.
CRISIS_EVENTS = {
    "2008-09-15": ("Lehman collapse", 90),
    "2008-03-17": ("Bear Stearns rescue", 60),
    "2010-05-06": ("Flash Crash", 45),
    "2011-08-05": ("US credit downgrade", 55),
    "2015-08-24": ("China flash crash", 50),
    "2016-06-24": ("Brexit vote", 40),
    "2018-12-24": ("Fed rate fears", 45),
    "2020-03-16": ("COVID crash", 95),
    "2022-06-13": ("Rate shock / crypto", 65),
    "2023-03-10": ("SVB collapse", 50),
}


if __name__ == "__main__":
    df = load_all_signals(use_cache=False)
    print(df.tail().round(3).to_string())
    print("\nMissing values:")
    print(df.isna().sum())
