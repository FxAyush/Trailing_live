"""
forward_test.py
---------------
Runs the model on LIVE data every day and logs:
  - Today's crash probability prediction
  - Today's portfolio recommendation
  - Actual outcome (checked after 15 days)
  - Running accuracy metrics

This is how you prove the model works on unseen data.

Run once per day (set up a Windows Task Scheduler or cron job):
  python forward_test.py

Or run manually anytime to get today's reading:
  python forward_test.py --now
"""

import os, sys, json, argparse
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from live_data         import fetch_live_signals, log_daily_signals, load_signal_history, SIGNAL_COLS
from signal_processor  import run_full_pipeline, get_current_snapshot
from early_warning     import EarlyWarningModel, LSTMNet, SAVE_PATH
from warning_portfolio import optimize_with_warning
from monte_carlo       import MonteCarloEngine, ASSET_CLASSES

PREDICTIONS_LOG = "forward_test_log.json"
HORIZON         = 15   # days ahead we're predicting


# ---------------------------------------------------------------------------
# Prediction logger
# ---------------------------------------------------------------------------

def load_predictions() -> list:
    if os.path.exists(PREDICTIONS_LOG):
        with open(PREDICTIONS_LOG) as f:
            return json.load(f)
    return []


def save_predictions(preds: list):
    with open(PREDICTIONS_LOG, "w") as f:
        json.dump(preds, f, indent=2)


def log_prediction(date: str, crash_prob: float,
                   alert: str, weights: dict,
                   stress_score: float, regime: str):
    """Log today's prediction for future accuracy tracking."""
    preds = load_predictions()

    # Check if already logged today
    if any(p["date"] == date for p in preds):
        print(f"  Already logged prediction for {date}")
        return

    preds.append({
        "date":          date,
        "crash_prob":    round(crash_prob * 100, 1),
        "alert":         alert,
        "stress_score":  round(stress_score, 1),
        "regime":        regime,
        "weights":       {k: round(v, 4) for k, v in weights.items()},
        "outcome_date":  (datetime.strptime(date, "%Y-%m-%d") +
                          timedelta(days=HORIZON)).strftime("%Y-%m-%d"),
        "outcome":       None,     # filled in after HORIZON days
        "correct":       None,
    })

    save_predictions(preds)
    print(f"  Prediction logged → {PREDICTIONS_LOG}")


def update_outcomes():
    """
    For predictions made HORIZON days ago, check if a crash actually occurred.
    A crash = stress score jumped by 15+ points within the next 15 days.
    """
    preds    = load_predictions()
    today    = datetime.now().strftime("%Y-%m-%d")
    updated  = 0

    for pred in preds:
        if pred["outcome"] is not None:
            continue   # already resolved

        outcome_date = pred["outcome_date"]
        if outcome_date > today:
            continue   # not yet resolved

        # Check if stress jumped significantly after prediction
        # Using the forward test log for outcome measurement
        try:
            history = load_signal_history()
            results = run_full_pipeline(history)
            score   = results["score"]

            pred_dt    = pd.Timestamp(pred["date"])
            outcome_dt = pd.Timestamp(outcome_date)

            # Score at prediction time
            pred_score = float(score.asof(pred_dt)) if pred_dt in score.index else 50.0
            # Max score in the next HORIZON days
            future     = score.loc[pred_dt:outcome_dt]
            max_future = float(future.max()) if len(future) > 0 else pred_score

            # Crash = score jumped 15+ points OR crossed 70
            crash_occurred = (max_future - pred_score >= 15) or (max_future >= 70)
            predicted_crash = pred["crash_prob"] >= 50

            pred["outcome"] = "crash" if crash_occurred else "no_crash"
            pred["correct"] = (predicted_crash == crash_occurred)
            pred["max_future_stress"] = round(max_future, 1)
            updated += 1

        except Exception:
            continue

    if updated > 0:
        save_predictions(preds)
        print(f"  Updated {updated} prediction outcomes")

    return preds


def compute_accuracy() -> dict:
    """Compute running accuracy metrics from resolved predictions."""
    preds    = load_predictions()
    resolved = [p for p in preds if p["outcome"] is not None]

    if len(resolved) == 0:
        return {"message": "No resolved predictions yet. Check back in 15 days."}

    correct  = sum(1 for p in resolved if p["correct"])
    crashes  = [p for p in resolved if p["outcome"] == "crash"]
    no_crash = [p for p in resolved if p["outcome"] == "no_crash"]

    # True positives: predicted crash AND crash occurred
    tp = sum(1 for p in crashes  if p["crash_prob"] >= 50)
    # False positives: predicted crash but no crash
    fp = sum(1 for p in no_crash if p["crash_prob"] >= 50)
    # True negatives: predicted no crash AND no crash
    tn = sum(1 for p in no_crash if p["crash_prob"] < 50)
    # False negatives: predicted no crash but crash occurred
    fn = sum(1 for p in crashes  if p["crash_prob"] < 50)

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall    = tp / (tp + fn) if (tp + fn) > 0 else 0
    f1        = 2 * precision * recall / (precision + recall) \
        if (precision + recall) > 0 else 0

    return {
        "total_predictions":  len(resolved),
        "correct":            correct,
        "accuracy_pct":       round(correct / len(resolved) * 100, 1),
        "precision":          round(precision * 100, 1),
        "recall":             round(recall * 100, 1),
        "f1_score":           round(f1, 3),
        "crashes_detected":   tp,
        "false_alarms":       fp,
        "crashes_missed":     fn,
        "pending":            len([p for p in preds if p["outcome"] is None]),
    }


# ---------------------------------------------------------------------------
# Main daily run
# ---------------------------------------------------------------------------

def run_daily(verbose: bool = True):
    """
    Full daily forward test pipeline:
    1. Fetch live data
    2. Run stress index
    3. Predict crash probability
    4. Generate portfolio recommendation
    5. Log everything
    6. Update past prediction outcomes
    7. Show accuracy metrics
    """
    today = datetime.now().strftime("%Y-%m-%d")
    print("="*60)
    print(f"  FORWARD TEST — {today}")
    print("="*60)

    # Step 1: Live data
    print("\n[1] Fetching live market data...")
    live_signals = fetch_live_signals()
    log_daily_signals(live_signals)

    # Step 2: Load full history + today
    print("\n[2] Computing stress index...")
    history = load_signal_history()
    results = run_full_pipeline(history)
    score   = results["score"]
    snap    = get_current_snapshot(results)

    print(f"  Stress score: {snap['stress_score']:.1f}/100 "
          f"({snap['regime'].upper()}) — trend: {snap['trend']}")

    # Step 3: Early warning prediction
    print("\n[3] Running early warning model...")
    if not os.path.exists(SAVE_PATH):
        print("  No trained model found. Training now (takes ~2 min)...")
        model = EarlyWarningModel()
        model.train(history, score, lstm_epochs=60)
        model.save()
    else:
        model = EarlyWarningModel.load(SAVE_PATH)

    warning  = model.predict_today(history, score)
    prob     = warning["probability"] / 100.0
    alert    = warning["alert"]
    regime   = snap["regime"]

    print(f"  Crash probability (next 15 days): {warning['probability']}%")
    print(f"  Alert: {alert}")

    # Step 4: Portfolio recommendation
    print("\n[4] Generating warning-adjusted portfolio...")
    mc_engine     = MonteCarloEngine(horizon=30, df_t=7)
    current_state = history.iloc[-1].values.astype(float)

    result = optimize_with_warning(
        crash_prob=prob,
        current_state=current_state,
        mc_engine=mc_engine,
        n_scenarios=300,
        regime=regime
    )

    weights = result["weights_named"]

    # Step 5: Log prediction
    print("\n[5] Logging prediction...")
    log_prediction(
        date=today,
        crash_prob=prob,
        alert=alert,
        weights=weights,
        stress_score=snap["stress_score"],
        regime=regime
    )

    # Step 6: Update past outcomes
    print("\n[6] Checking past prediction outcomes...")
    update_outcomes()

    # Step 7: Accuracy metrics
    print("\n[7] Running accuracy metrics...")
    acc = compute_accuracy()

    # Print full report
    print(f"\n{'='*60}")
    print(f"  TODAY'S READING")
    print(f"{'='*60}")
    print(f"\n  Stress:  {snap['stress_score']:.1f}/100 ({snap['regime'].upper()})")
    print(f"  Warning: {alert} — {warning['probability']}% crash probability")
    print(f"\n  Portfolio: {result['profile_label']}")
    print(f"  {'Asset':20s} {'Weight':>8s}")
    print(f"  {'-'*30}")
    for asset, w in sorted(weights.items(), key=lambda x: -x[1]):
        if w > 0.005:
            bar = "█" * int(w * 30)
            print(f"  {asset:20s} {w*100:6.1f}%  {bar}")

    print(f"\n  CVaR:            {result['cvar']*100:.1f}%")
    print(f"  Expected return: {result['expected_ret']*100:.1f}%")
    print(f"  Sharpe:          {result['sharpe']:.2f}")

    print(f"\n  Recommendation: {warning['recommendation']}")

    print(f"\n{'='*60}")
    print(f"  FORWARD TEST ACCURACY (so far)")
    print(f"{'='*60}")
    if "message" in acc:
        print(f"\n  {acc['message']}")
        print(f"  Pending predictions: check back in {HORIZON} days")
    else:
        print(f"\n  Total resolved predictions: {acc['total_predictions']}")
        print(f"  Overall accuracy:           {acc['accuracy_pct']}%")
        print(f"  Crash precision:            {acc['precision']}%")
        print(f"  Crash recall:               {acc['recall']}%")
        print(f"  F1 score:                   {acc['f1_score']}")
        print(f"  Crashes detected:           {acc['crashes_detected']}")
        print(f"  False alarms:               {acc['false_alarms']}")
        print(f"  Crashes missed:             {acc['crashes_missed']}")
        print(f"  Pending (not yet resolved): {acc['pending']}")

    return {
        "warning":    warning,
        "portfolio":  result,
        "accuracy":   acc,
        "snapshot":   snap,
    }


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--now",      action="store_true",
                        help="Run immediately (default)")
    parser.add_argument("--accuracy", action="store_true",
                        help="Show accuracy metrics only")
    parser.add_argument("--history",  action="store_true",
                        help="Show prediction history")
    args = parser.parse_args()

    if args.accuracy:
        update_outcomes()
        acc = compute_accuracy()
        print(json.dumps(acc, indent=2))

    elif args.history:
        preds = load_predictions()
        print(f"\nPrediction history ({len(preds)} entries):\n")
        print(f"{'Date':12s} {'Prob%':>7s} {'Alert':12s} "
              f"{'Outcome':12s} {'Correct':>8s}")
        print("-" * 55)
        for p in preds[-20:]:   # last 20
            outcome = p.get("outcome") or "pending"
            correct = "✓" if p.get("correct") else \
                      "✗" if p.get("correct") is False else "..."
            print(f"{p['date']:12s} {p['crash_prob']:6.1f}%  "
                  f"{p['alert'][:12]:12s} {outcome:12s} {correct:>8s}")
    else:
        run_daily()
