"""
warning_portfolio.py
--------------------
Adjusts portfolio allocation based on crash probability from early_warning.py.

The higher the crash probability → the more defensive the portfolio.

Run standalone:
  python warning_portfolio.py
"""

import numpy as np
import pandas as pd
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from monte_carlo          import MonteCarloEngine, mc_portfolio_returns, ASSET_CLASSES, N_ASSETS
from cvar_engine          import CVaREngine
from portfolio_optimizer  import CVaROptimizer, ReturnMaximiser, BOUNDS, BOUNDS_BY_REGIME, REGIME_SEEDS
from early_warning        import EarlyWarningModel, LSTMNet, SAVE_PATH


# ---------------------------------------------------------------------------
# Crash-probability driven allocation rules
# ---------------------------------------------------------------------------
#
# These define how CVaR limit and risk tolerance shift as crash prob rises.
# Low prob  → allow more risk, chase returns
# High prob → tighten CVaR, go defensive
#
PROB_PROFILES = {
    0.25: (-0.10, 0.70, "Opportunistic"),
    0.50: (-0.10, 0.50, "Balanced"),
    0.75: (-0.08, 0.25, "Defensive"),
    1.01: (-0.07, 0.10, "Maximum Defence"),
}

# Gold floor rises with crash probability (gold is safe haven)
GOLD_FLOOR = {
    0.25: 0.05,   # low prob  → 5% min gold
    0.50: 0.10,   # medium    → 10% min gold
    0.75: 0.18,   # high      → 18% min gold
    1.01: 0.22,   # critical  → 22% min gold
}


def get_profile(crash_prob: float) -> tuple:
    """Return (max_cvar, risk_tolerance, label, gold_floor) for a given prob."""
    for threshold, (mc, rt, label) in PROB_PROFILES.items():
        if crash_prob < threshold:
            gold_floor = next(v for t,v in GOLD_FLOOR.items()
                              if crash_prob < t)
            return mc, rt, label, gold_floor
    mc, rt, label = list(PROB_PROFILES.values())[-1]
    return mc, rt, label, list(GOLD_FLOOR.values())[-1]


def optimize_with_warning(crash_prob: float,
                           current_state: np.ndarray,
                           mc_engine: MonteCarloEngine,
                           n_scenarios: int = 500,
                           regime: str = "elevated") -> dict:
    """
    Generate a CVaR-optimized portfolio tuned to the current crash probability.

    Args:
        crash_prob:    0-1 probability from EarlyWarningModel
        current_state: today's signal Z-scores
        mc_engine:     MonteCarloEngine instance
        n_scenarios:   number of Monte Carlo scenarios
        regime:        stress regime (calm/elevated/crisis)

    Returns:
        dict with weights, metrics, and explanation
    """
    max_cvar, risk_tol, label, gold_floor = get_profile(crash_prob)

    # Tighten bounds based on crash probability
    dynamic_bounds = list(BOUNDS_BY_REGIME.get(regime, BOUNDS_BY_REGIME["elevated"]))
    asset_names    = ASSET_CLASSES

    # Apply gold floor
    gold_idx = asset_names.index("gold")
    old_gold = dynamic_bounds[gold_idx]
    dynamic_bounds[gold_idx] = (gold_floor, old_gold[1])

    # Cap crypto harder as crash prob rises
    crypto_idx = asset_names.index("crypto")
    crypto_max = max(0.0, 0.10 * (1 - crash_prob))
    dynamic_bounds[crypto_idx] = (0.0, crypto_max)

    # Cap equity as crash prob rises
    for eq_asset in ["indian_equity", "us_equity", "emerging_markets"]:
        idx = asset_names.index(eq_asset)
        orig_max = dynamic_bounds[idx][1]
        new_max  = orig_max * (1 - 0.6 * crash_prob)
        dynamic_bounds[idx] = (0.0, max(new_max, 0.01))

    # Generate scenarios
    scenarios = mc_engine.generate_scenarios(current_state, n_scenarios)

    # Use ReturnMaximiser for low crash prob (better returns)
    # Use CVaROptimizer for high crash prob (safety first)
    from scipy.optimize import minimize
    cvar_engine = CVaREngine(alpha=0.05)
    if crash_prob < 0.30 and regime == "calm":
        rm  = ReturnMaximiser(alpha=0.05, max_cvar=max_cvar)
        sc2 = mc_engine.generate_scenarios(current_state, n_scenarios)
        result = rm.optimize(sc2, regime=regime)
        result["profile_label"] = "Return-Maximised"
        return result

    def objective(w):
        w = np.clip(w, 0, 1); w /= w.sum()+1e-8
        rets = mc_portfolio_returns(w, scenarios)
        sr   = np.sort(rets)
        tn   = max(1, int(np.ceil(0.05*len(rets))))
        cvar = float(sr[:tn].mean())
        exp  = float(rets.mean())
        vol  = float(rets.std())+1e-8
        sharpe = exp/vol
        cvar_pen  = max(0, max_cvar - cvar) * 20
        conc_pen  = max(0, np.sum(w**2) - 0.25) * 3
        return -(risk_tol * sharpe - (1-risk_tol) * abs(cvar) - cvar_pen - conc_pen)

    # Use regime-appropriate seed
    seed = REGIME_SEEDS.get(regime, REGIME_SEEDS["elevated"]).copy()
    # Force gold floor in seed
    seed = seed[0].copy() if isinstance(seed, list) else seed.copy()
    seed[gold_idx] = max(seed[gold_idx], gold_floor)
    seed /= seed.sum()
    best_w, best_val = seed.copy(), np.inf
    for w0 in [seed,
               np.ones(N_ASSETS)/N_ASSETS,
               np.array([0,0,0,0.22,0.35,0.28,0,0.12,0.03])]:
        w0 = np.clip(w0, 0, 1); w0 /= w0.sum()
        try:
            res = minimize(objective, w0, method="SLSQP",
                           bounds=dynamic_bounds,
                           constraints=[{"type":"eq","fun":lambda w:w.sum()-1}],
                           options={"maxiter":1000,"ftol":1e-9})
            if res.success and res.fun < best_val:
                best_val = res.fun; best_w = res.x
        except Exception:
            continue

    weights = np.clip(best_w, 0, 1); weights /= weights.sum()

    # Compute final metrics
    port_rets = mc_portfolio_returns(weights, scenarios)
    n  = len(port_rets)
    tn = max(1, int(np.ceil(0.05*n)))
    cvar     = float(np.sort(port_rets)[:tn].mean())
    exp_ret  = float(port_rets.mean())
    vol      = float(port_rets.std())+1e-8
    sharpe   = exp_ret / vol * np.sqrt(12)
    pct = {f"p{p}": float(np.percentile(port_rets, p))
           for p in [5,10,25,50,75,90]}

    return {
        "weights":        weights,
        "weights_named":  dict(zip(ASSET_CLASSES, weights)),
        "cvar":           cvar,
        "expected_ret":   exp_ret,
        "sharpe":         sharpe,
        "percentiles":    pct,
        "is_safe":        cvar >= max_cvar,
        "max_cvar":       max_cvar,
        "profile_label":  label,
        "crash_prob":     crash_prob,
        "gold_floor":     gold_floor,
        "n_scenarios":    n,
    }


def print_warning_portfolio(result: dict, warning: dict):
    prob  = warning["probability"]
    alert = warning["alert"]
    w     = result["weights_named"]
    pct   = result["percentiles"]

    print(f"\n{'='*60}")
    print(f"  EARLY WARNING: {alert}  ({prob}% crash probability)")
    print(f"  Portfolio profile: {result['profile_label']}")
    print(f"{'='*60}")

    print(f"\n  Allocation (adjusted for {prob}% crash risk):")
    for asset, weight in sorted(w.items(), key=lambda x: -x[1]):
        if weight > 0.005:
            bar = "█" * int(weight * 40)
            print(f"    {asset:20s}  {weight*100:5.1f}%  {bar}")

    print(f"\n  Risk metrics (30-day, {result['n_scenarios']} scenarios):")
    print(f"    Expected return:          {result['expected_ret']*100:+.1f}%")
    print(f"    CVaR (worst 5%):          {result['cvar']*100:.1f}%")
    print(f"    Sharpe ratio:             {result['sharpe']:.2f}")
    print(f"    Worst case (bot 5%):      {pct['p5']*100:.1f}%")
    print(f"    Best  case (top 10%):     {pct['p90']*100:.1f}%")

    status = "✓ SAFE" if result["is_safe"] else "✗ UNSAFE"
    print(f"\n  Safety: {status}  "
          f"(CVaR {result['cvar']*100:.1f}% vs limit "
          f"{result['max_cvar']*100:.0f}%)")

    print(f"\n  Why this allocation:")
    print(f"    Crash prob {prob}% → gold floor {result['gold_floor']*100:.0f}%")
    if prob >= 75:
        print(f"    Critical alert → equity capped, bonds + gold maximised")
    elif prob >= 50:
        print(f"    High alert → equity reduced, defensive tilt added")
    elif prob >= 25:
        print(f"    Moderate alert → slight defensive bias maintained")
    else:
        print(f"    Low risk → growth-oriented allocation")

    print(f"\n  Action: {warning['recommendation']}")


# ---------------------------------------------------------------------------
# Standalone run
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    from data_loader      import load_all_signals
    from signal_processor import run_full_pipeline

    signals   = load_all_signals()
    results   = run_full_pipeline(signals)
    score     = results["score"]
    regime    = ("crisis" if score.iloc[-1] >= 65
                 else "elevated" if score.iloc[-1] >= 35
                 else "calm")

    mc_engine = MonteCarloEngine(horizon=30, df_t=7)

    # Load or train warning model
    if os.path.exists(SAVE_PATH):
        model = EarlyWarningModel.load()
    else:
        print("Training early warning model...")
        model = EarlyWarningModel()
        model.train(signals, score)
        model.save()

    # Get warning
    warning = model.predict_today(signals, score)
    prob    = warning["probability"] / 100.0

    # Get crash-adjusted portfolio
    current_state = signals.iloc[-1].values.astype(np.float32)
    result = optimize_with_warning(
        crash_prob=prob,
        current_state=current_state,
        mc_engine=mc_engine,
        n_scenarios=500,
        regime=regime
    )

    print_warning_portfolio(result, warning)
