"""
early_warning.py
----------------
Predicts probability of a market crash in the next 10-15 days.

Output example:
  Crisis probability: 78%
  Alert: HIGH — shift to defensive portfolio now
  Top drivers: yield_curve_spread, credit_spread, vix

Run standalone:
  python early_warning.py
"""

import numpy as np
import pandas as pd
import pickle, os, sys, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import TimeSeriesSplit

from data_loader      import load_all_signals, CRISIS_EVENTS
from signal_processor import run_full_pipeline

DEVICE         = torch.device("cuda" if torch.cuda.is_available() else "cpu")
HORIZON        = 15     # predict crash within next 15 days
CRASH_THRESH   = 70.0   # stress score above this = crash day
SAVE_PATH      = "early_warning_model.pkl"


# ---------------------------------------------------------------------------
# Feature engineering
# ---------------------------------------------------------------------------
def build_features(signals: pd.DataFrame, score: pd.Series) -> pd.DataFrame:
    f = pd.DataFrame(index=signals.index)

    # Raw signals
    for col in signals.columns:
        f[col] = signals[col]

    # Rolling mean / std / rate of change
    for col in signals.columns:
        for w in [5, 10, 20]:
            f[f"{col}_mean{w}"] = signals[col].rolling(w).mean()
            f[f"{col}_std{w}"]  = signals[col].rolling(w).std()
            f[f"{col}_roc{w}"]  = signals[col].diff(w)

    # Stress score features
    f["stress"]       = score
    f["stress_roc5"]  = score.diff(5)
    f["stress_roc10"] = score.diff(10)
    f["stress_accel"] = score.diff().diff()
    f["stress_ma10"]  = score.rolling(10).mean()
    f["stress_hi"]    = (score > CRASH_THRESH).astype(float)
    f["stress_rank"]  = score.rolling(252, min_periods=60).rank(pct=True)

    # Consecutive rising days
    rising = score.diff() > 0
    cnt, vals = 0, []
    for r in rising:
        cnt = cnt + 1 if r else 0
        vals.append(float(cnt))
    f["days_rising"] = vals

    # Key cross-signal interactions
    if "credit_spread" in signals and "yield_curve_spread" in signals:
        f["credit_x_yield"] = signals["credit_spread"] * signals["yield_curve_spread"].abs()
    if "vix" in signals and "fii_flows" in signals:
        f["vix_x_fii"] = signals["vix"] * (-signals["fii_flows"].clip(upper=0))
    if "ted_spread" in signals and "market_breadth" in signals:
        f["ted_x_breadth"] = signals["ted_spread"] * (100 - signals["market_breadth"].clip(0,100))

    return f.fillna(0)


def build_labels(score: pd.Series, horizon: int = HORIZON,
                 thresh: float = CRASH_THRESH) -> pd.Series:
    """1 if stress >= thresh for 3+ consecutive days within next horizon days."""
    labels = pd.Series(0, index=score.index)
    for i in range(len(score) - horizon):
        fw = score.iloc[i+1:i+1+horizon]
        if (fw >= thresh).rolling(3).sum().max() >= 3:
            labels.iloc[i] = 1
    return labels


# ---------------------------------------------------------------------------
# LSTM
# ---------------------------------------------------------------------------
class LSTMNet(nn.Module):
    def __init__(self, input_dim, hidden=64, layers=2):
        super().__init__()
        self.lstm = nn.LSTM(input_dim, hidden, layers,
                            batch_first=True, dropout=0.3)
        self.attn = nn.Linear(hidden, 1)
        self.head = nn.Sequential(
            nn.Linear(hidden, 32), nn.ReLU(),
            nn.Dropout(0.2), nn.Linear(32, 1), nn.Sigmoid()
        )

    def forward(self, x):
        out, _ = self.lstm(x)
        w = F.softmax(self.attn(out), dim=1)
        ctx = (w * out).sum(1)
        return self.head(ctx).squeeze(-1)


# ---------------------------------------------------------------------------
# Main predictor class
# ---------------------------------------------------------------------------
class EarlyWarningModel:

    def __init__(self):
        self.gbt          = None
        self.lstm_net     = None
        self.scaler       = StandardScaler()
        self.feat_cols    = None
        self.trained      = False
        self.seq_len      = 20
        self.input_dim    = None

    # ---- training ----
    def train(self, signals: pd.DataFrame, score: pd.Series,
              lstm_epochs: int = 80):

        print("Building features and labels...")
        feat   = build_features(signals, score)
        labels = build_labels(score, HORIZON, CRASH_THRESH)

        data   = pd.concat([feat, labels.rename("label")], axis=1).dropna()
        X      = data[feat.columns].values.astype(np.float32)
        y      = data["label"].values.astype(int)
        self.feat_cols = list(feat.columns)
        self.input_dim = X.shape[1]

        print(f"  Samples: {len(X)} | Crisis days: {y.sum()} "
              f"({y.mean()*100:.1f}%)")

        # Cross-validation AUC
        tscv  = TimeSeriesSplit(n_splits=4)
        aucs  = []
        for tr, va in tscv.split(X):
            sc = StandardScaler()
            Xtr = sc.fit_transform(X[tr])
            Xva = sc.transform(X[va])
            g   = GradientBoostingClassifier(
                n_estimators=200, max_depth=4,
                learning_rate=0.05, subsample=0.8,
                min_samples_leaf=20, random_state=42
            )
            g.fit(Xtr, y[tr])
            if y[va].sum() > 0:
                aucs.append(roc_auc_score(y[va], g.predict_proba(Xva)[:,1]))
        print(f"  CV AUC: {np.mean(aucs):.3f} (avg over {len(aucs)} folds)")

        # Final GBT
        print("Training GBT...")
        Xsc = self.scaler.fit_transform(X)
        base = GradientBoostingClassifier(
            n_estimators=300, max_depth=4,
            learning_rate=0.03, subsample=0.8,
            min_samples_leaf=15, random_state=42
        )
        self.gbt = CalibratedClassifierCV(base, cv=3, method="isotonic")
        self.gbt.fit(Xsc, y)
        print("  GBT done ✓")

        # LSTM
        print(f"Training LSTM on {DEVICE} ({lstm_epochs} epochs)...")
        self._train_lstm(X, y, lstm_epochs)
        print("  LSTM done ✓")

        self.trained = True
        train_auc = roc_auc_score(y, self._ensemble_proba(X))
        print(f"  Final ensemble train AUC: {train_auc:.3f}")
        return {"cv_auc": round(np.mean(aucs), 3),
                "train_auc": round(train_auc, 3)}

    def _train_lstm(self, X, y, epochs):
        scaler = StandardScaler()
        Xsc    = scaler.fit_transform(X)
        seqs, labs = [], []
        for i in range(self.seq_len, len(Xsc)):
            seqs.append(Xsc[i-self.seq_len:i])
            labs.append(y[i])
        Xt = torch.FloatTensor(np.array(seqs)).to(DEVICE)
        yt = torch.FloatTensor(np.array(labs)).to(DEVICE)

        self.lstm_net    = LSTMNet(self.input_dim).to(DEVICE)
        self.lstm_scaler = scaler
        opt = torch.optim.Adam(self.lstm_net.parameters(), lr=1e-3,
                               weight_decay=1e-4)
        sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
        pw  = torch.tensor([(yt==0).sum()/(yt==1).sum()+1e-8]).to(DEVICE)
        crit = nn.BCEWithLogitsLoss(pos_weight=pw)
        ds   = torch.utils.data.TensorDataset(Xt, yt)
        dl   = torch.utils.data.DataLoader(ds, batch_size=64, shuffle=True)

        self.lstm_net.train()
        for _ in range(epochs):
            for xb, yb in dl:
                p = self.lstm_net(xb)
                loss = crit(torch.logit(p.clamp(1e-6,1-1e-6)), yb)
                opt.zero_grad(); loss.backward()
                torch.nn.utils.clip_grad_norm_(self.lstm_net.parameters(),1.0)
                opt.step()
            sch.step()

    def _gbt_proba(self, X):
        return self.gbt.predict_proba(self.scaler.transform(X))[:,1]

    def _lstm_proba(self, X):
        Xsc  = self.lstm_scaler.transform(X)
        seqs = np.array([Xsc[max(0,i-self.seq_len):i]
                         for i in range(1, len(Xsc)+1)], dtype=object)
        probs = []
        self.lstm_net.eval()
        with torch.no_grad():
            for seq in seqs:
                if len(seq) < 2:
                    probs.append(0.5)
                    continue
                pad = np.zeros((self.seq_len, self.input_dim), dtype=np.float32)
                pad[-len(seq):] = seq[-self.seq_len:]
                t   = torch.FloatTensor(pad).unsqueeze(0).to(DEVICE)
                probs.append(float(self.lstm_net(t).cpu()))
        return np.array(probs)

    def _ensemble_proba(self, X):
        g = self._gbt_proba(X)
        l = self._lstm_proba(X)
        return np.clip(0.6*g + 0.4*l, 0, 1)

    # ---- inference ----
    def predict_today(self, signals: pd.DataFrame,
                      score: pd.Series) -> dict:
        """
        Given full signal history, predict today's crash probability.
        Returns probability + alert level + top drivers + recommendation.
        """
        if not self.trained:
            raise RuntimeError("Call train() first.")

        feat = build_features(signals, score)
        X    = feat[self.feat_cols].fillna(0).values.astype(np.float32)
        prob = float(self._ensemble_proba(X)[-1])

        if prob < 0.25:   level, color = "LOW",      "🟢"
        elif prob < 0.50: level, color = "MEDIUM",   "🟡"
        elif prob < 0.75: level, color = "HIGH",     "🟠"
        else:             level, color = "CRITICAL", "🔴"

        # Top signal drivers from GBT feature importance
        imp     = self.gbt.calibrated_classifiers_[0].estimator.feature_importances_
        top_idx = np.argsort(imp)[::-1][:5]
        drivers = [(self.feat_cols[i], round(float(imp[i])*100, 1))
                   for i in top_idx]

        recs = {
            "LOW":      "Markets stable. Maintain current allocation.",
            "MEDIUM":   f"Elevated risk. Consider trimming equity 10-15%.",
            "HIGH":     f"High crash probability. Shift to defensive now.",
            "CRITICAL": f"URGENT: Move to maximum defensive posture immediately.",
        }

        return {
            "probability":     round(prob * 100, 1),
            "alert":           f"{color} {level}",
            "horizon_days":    HORIZON,
            "top_drivers":     drivers,
            "recommendation":  recs[level],
            "stress_score":    float(score.iloc[-1]),
        }

    # ---- historical probability series ----
    def predict_series(self, signals: pd.DataFrame,
                       score: pd.Series) -> pd.Series:
        """Returns daily crash probability for entire history."""
        feat = build_features(signals, score)
        X    = feat[self.feat_cols].fillna(0).values.astype(np.float32)
        prob = self._ensemble_proba(X)
        return pd.Series(prob, index=feat.index, name="crash_prob")

    # ---- save / load ----
    def save(self, path=SAVE_PATH):
        with open(path, "wb") as f:
            pickle.dump(self.__dict__, f)
        print(f"Model saved → {path}")

    @classmethod
    def load(cls, path=SAVE_PATH):
        m = cls()
        with open(path, "rb") as f:
            m.__dict__.update(pickle.load(f))
        print(f"Model loaded from {path}")
        return m


# ---------------------------------------------------------------------------
# Standalone run
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    signals = load_all_signals()
    results = run_full_pipeline(signals)
    score   = results["score"]

    model = EarlyWarningModel()
    stats = model.train(signals, score, lstm_epochs=80)
    model.save()

    pred = model.predict_today(signals, score)
    print(f"\n{'='*50}")
    print(f"  EARLY WARNING SYSTEM — TODAY'S READING")
    print(f"{'='*50}")
    print(f"  Crash probability (next {pred['horizon_days']} days): "
          f"{pred['probability']}%")
    print(f"  Alert level:   {pred['alert']}")
    print(f"  Stress score:  {pred['stress_score']:.1f}/100")
    print(f"\n  Top signal drivers:")
    for name, imp in pred["top_drivers"]:
        print(f"    {name:30s} {imp:.1f}% importance")
    print(f"\n  Recommendation: {pred['recommendation']}")
