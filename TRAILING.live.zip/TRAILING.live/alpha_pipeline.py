"""
alpha_pipeline.py
-----------------
Master pipeline integrating all 4 layers:

  Layer 1: Macro signals      (data_loader + signal_processor)
  Layer 2: News + sentiment   (news_fetcher)
  Layer 3: LLM research agent (alpha_agent)
  Layer 4: Portfolio action   (warning_portfolio + monte_carlo)

Output:
  - Crash warning with probability
  - Buying opportunities with thesis
  - Optimised portfolio allocation
  - Plain-language explanation

Run:
  python alpha_pipeline.py                    daily full run
  python alpha_pipeline.py --quick            skip news fetch (faster)
  python alpha_pipeline.py --opportunity      focus on buy signals
  python alpha_pipeline.py --crash            focus on crash signals
"""

import os, sys, json, argparse
import numpy as np
import pandas as pd
from datetime import datetime
import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from data_loader       import load_all_signals
from signal_processor  import run_full_pipeline, get_current_snapshot
from monte_carlo       import MonteCarloEngine, mc_portfolio_returns, ASSET_CLASSES, N_ASSETS
from early_warning     import EarlyWarningModel, LSTMNet, SAVE_PATH as EW_SAVE_PATH
from warning_portfolio import optimize_with_warning, get_profile
from news_fetcher      import run_news_pipeline
from alpha_agent       import LLMAlphaAgent, RuleBasedAlphaEngine


ALPHA_LOG = "alpha_signals_log.json"


# ---------------------------------------------------------------------------
# Combined signal scorer
# Merges macro stress + news crash signal + geo risk into one number
# ---------------------------------------------------------------------------
def combine_signals(stress_score: float,
                    news_crash: float,
                    geo_risk: float,
                    ew_prob: float,
                    news_buy: float) -> dict:
    """
    Combine all signal sources into final crash and opportunity probabilities.

    Weights based on empirical reliability:
      Early warning model:  35% (trained on historical data)
      Macro stress index:   25% (real-time indicators)
      News crash signal:    20% (current events)
      Geo risk:             20% (geopolitical context)
    """
    crash_prob = (
        0.35 * ew_prob / 100 +
        0.25 * stress_score / 100 +
        0.20 * news_crash / 100 +
        0.20 * geo_risk / 100
    )
    crash_prob = float(np.clip(crash_prob, 0, 1))

    # Buy prob is suppressed by crash prob
    buy_prob = float(np.clip(news_buy / 100 * (1 - crash_prob * 0.6), 0, 1))

    # Combined regime
    if crash_prob > 0.65:
        regime  = "CRITICAL"
        color   = "🔴"
        action  = "Maximum defensive posture. Reduce equity, increase bonds + gold."
    elif crash_prob > 0.40:
        regime  = "ELEVATED"
        color   = "🟠"
        action  = "Defensive tilt. Trim high-beta, raise defensive allocation."
    elif buy_prob > 0.50:
        regime  = "OPPORTUNITY"
        color   = "🟢"
        action  = "Selective accumulation. Increase exposure to signalled assets."
    else:
        regime  = "NEUTRAL"
        color   = "🟡"
        action  = "Hold current allocation. Monitor for developments."

    return {
        "crash_prob":  round(crash_prob, 3),
        "buy_prob":    round(buy_prob,   3),
        "regime":      regime,
        "color":       color,
        "action":      action,
        "components": {
            "early_warning": round(ew_prob, 1),
            "macro_stress":  round(stress_score, 1),
            "news_crash":    round(news_crash, 1),
            "geo_risk":      round(geo_risk, 1),
            "news_buy":      round(news_buy, 1),
        }
    }


# ---------------------------------------------------------------------------
# Portfolio adjuster — applies alpha signals to allocation
# ---------------------------------------------------------------------------
def apply_alpha_to_portfolio(base_result: dict,
                              alpha_result: dict,
                              mc_engine: MonteCarloEngine,
                              current_state: np.ndarray,
                              n_scenarios: int = 300) -> dict:
    """
    Takes the base CVaR-optimized portfolio and adjusts it
    based on alpha agent signals (buy/sell hints).

    Respects CVaR constraints — no allocation change is made
    that violates the safety limit.
    """
    from scipy.optimize import minimize
    from monte_carlo import mc_portfolio_returns
    from portfolio_optimizer import BOUNDS
    from cvar_engine import CVaREngine

    hint     = alpha_result.get("allocation_hint", {})
    increase = hint.get("increase", {})
    decrease = hint.get("decrease", {})

    if not increase and not decrease:
        return base_result   # no adjustment needed

    base_weights = base_result["weights"].copy()
    max_cvar     = base_result.get("max_cvar", -0.15)
    scenarios    = mc_engine.generate_scenarios(current_state, n_scenarios)
    cvar_engine  = CVaREngine(alpha=0.05)

    # Apply hints as nudges (max 5% shift per asset)
    adjusted = base_weights.copy()
    asset_idx = {a: i for i, a in enumerate(ASSET_CLASSES)}

    for asset, strength in increase.items():
        if asset in asset_idx:
            shift = min(0.05 * strength, 0.08)
            adjusted[asset_idx[asset]] += shift

    for asset, strength in decrease.items():
        if asset in asset_idx:
            shift = min(0.05 * strength, 0.08)
            adjusted[asset_idx[asset]] -= shift

    # Clip and normalise
    adjusted = np.clip(adjusted, 0, 0.45)
    adjusted /= adjusted.sum()

    # Check if adjusted portfolio is still CVaR-safe
    port_rets = mc_portfolio_returns(adjusted, scenarios)
    n  = len(port_rets)
    tn = max(1, int(np.ceil(0.05 * n)))
    new_cvar = float(np.sort(port_rets)[:tn].mean())

    if new_cvar >= max_cvar:
        # Safe — use adjusted weights
        new_exp  = float(port_rets.mean())
        new_vol  = float(port_rets.std()) + 1e-8
        return {
            **base_result,
            "weights":       adjusted,
            "weights_named": dict(zip(ASSET_CLASSES, adjusted)),
            "cvar":          new_cvar,
            "expected_ret":  new_exp,
            "sharpe":        new_exp / new_vol * np.sqrt(12),
            "alpha_adjusted": True,
        }
    else:
        # Unsafe — return original
        base_result["alpha_adjusted"] = False
        return base_result


# ---------------------------------------------------------------------------
# Log signal
# ---------------------------------------------------------------------------
def log_alpha_signal(combined: dict, alpha: dict,
                     portfolio: dict, date: str):
    """Append today's alpha signal to the log."""
    record = {
        "date":       date,
        "crash_prob": combined["crash_prob"],
        "buy_prob":   combined["buy_prob"],
        "regime":     combined["regime"],
        "thesis":     alpha.get("thesis", "")[:200],
        "hotspots":   alpha.get("active_hotspots", []) if isinstance(alpha, dict) else [],
        "top_signal": (alpha.get("signals", [{}])[0].get("source", "")
                       if alpha.get("signals") else ""),
        "allocation": {k: round(v, 3) for k, v in
                      portfolio["weights_named"].items() if v > 0.01},
    }

    existing = []
    if os.path.exists(ALPHA_LOG):
        with open(ALPHA_LOG) as f:
            try:
                existing = json.load(f)
            except Exception:
                existing = []

    # Remove duplicate dates
    existing = [e for e in existing if e.get("date") != date]
    existing.append(record)

    with open(ALPHA_LOG, "w") as f:
        json.dump(existing[-90:], f, indent=2)   # keep last 90 days

    print(f"  Signal logged → {ALPHA_LOG}")


# ---------------------------------------------------------------------------
# Print functions
# ---------------------------------------------------------------------------
def print_full_report(combined: dict, alpha_result: dict,
                      portfolio: dict, snap: dict, date: str):

    print(f"\n{'='*65}")
    print(f"  ALPHA INTELLIGENCE REPORT — {date}")
    print(f"{'='*65}")

    # Signal summary
    print(f"\n  {combined['color']} OVERALL: {combined['regime']}")
    print(f"  Crash probability:   {combined['crash_prob']*100:.1f}%")
    print(f"  Opportunity score:   {combined['buy_prob']*100:.1f}%")
    print(f"\n  Signal components:")
    for k, v in combined["components"].items():
        bar = "█" * int(v / 10)
        print(f"    {k:20s}  {v:5.1f}  {bar}")

    # Active hotspots
    hotspots = alpha_result.get("active_hotspots", [])
    if not hotspots and isinstance(alpha_result, dict):
        hotspots = [s.get("source","").replace("Geopolitical: ","").lower()
                    for s in alpha_result.get("signals",[])
                    if "Geopolitical" in s.get("source","")]
    if hotspots:
        print(f"\n  ⚠  Active geopolitical hotspots: "
              f"{', '.join(h.title() for h in hotspots)}")

    # Investment thesis
    thesis = alpha_result.get("llm_thesis") or alpha_result.get("thesis", "")
    if thesis:
        print(f"\n  THESIS:")
        # Word-wrap at 60 chars
        words = thesis.split()
        line  = "  "
        for word in words:
            if len(line) + len(word) > 64:
                print(line)
                line = "    " + word + " "
            else:
                line += word + " "
        if line.strip():
            print(line)

    # Individual signals
    signals = alpha_result.get("signals", [])
    if signals:
        print(f"\n  SIGNALS ({len(signals)} detected):")
        for s in signals[:5]:
            icon = "🔴" if s["type"] == "CRASH_WARNING" else "🟢"
            print(f"    {icon} [{s['confidence']*100:.0f}%conf] "
                  f"{s['source']}")
            print(f"       Assets: {', '.join(s['assets'][:3])}")

    # Portfolio
    print(f"\n  PORTFOLIO [{portfolio['profile_label']}]"
          f"{'  [alpha-adjusted]' if portfolio.get('alpha_adjusted') else ''}:")
    for asset, w in sorted(portfolio["weights_named"].items(),
                           key=lambda x: -x[1]):
        if w > 0.005:
            bar = "█" * int(w * 35)
            print(f"    {asset:20s}  {w*100:5.1f}%  {bar}")

    print(f"\n  Risk metrics:")
    print(f"    Expected return:  {portfolio['expected_ret']*100:+.1f}%")
    print(f"    CVaR (worst 5%):  {portfolio['cvar']*100:.1f}%")
    print(f"    Sharpe ratio:     {portfolio['sharpe']:.2f}")
    safe = "✓ SAFE" if portfolio["is_safe"] else "✗ UNSAFE"
    print(f"    Safety:           {safe}")

    print(f"\n  ACTION: {combined['action']}")


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------
def run_alpha_pipeline(skip_news: bool = False,
                       n_scenarios: int = 400) -> dict:

    date = datetime.now().strftime("%Y-%m-%d")
    print("="*65)
    print("  ALPHA INTELLIGENCE PIPELINE")
    print(f"  {date}")
    print("="*65)

    # Layer 1: Macro signals
    print("\n[1/4] Loading macro signals...")
    signals = load_all_signals()
    results = run_full_pipeline(signals)
    score   = results["score"]
    snap    = get_current_snapshot(results)
    stress  = snap["stress_score"]
    regime  = snap["regime"]
    print(f"  Stress: {stress:.1f}/100 ({regime.upper()})")

    # Layer 2: News + sentiment
    if skip_news:
        print("\n[2/4] Skipping news fetch (--quick mode)")
        news_data = {
            "crash_signal": 0, "buy_signal": 0,
            "geo_risk_score": 0, "avg_sentiment": 0,
            "active_hotspots": [], "top_crash_stories": [],
            "top_buy_stories": [], "overall_signal": "NEUTRAL",
            "total_articles": 0,
        }
    else:
        print("\n[2/4] Fetching news and scoring sentiment...")
        news_data = run_news_pipeline()
        print(f"  Articles: {news_data['total_articles']} | "
              f"Crash signals: {news_data['crash_articles']} | "
              f"Buy signals: {news_data['buy_articles']}")
        if news_data["active_hotspots"]:
            print(f"  Hotspots: {', '.join(news_data['active_hotspots'])}")

    # Layer 3: Alpha research agent
    print("\n[3/4] Running alpha research agent...")
    agent  = LLMAlphaAgent()
    alpha  = agent.research(news_data, stress_score=stress)
    print(f"  Signals: {alpha['n_signals']} | "
          f"Crash: {alpha['crash_prob']*100:.0f}% | "
          f"Buy: {alpha['buy_prob']*100:.0f}% | "
          f"LLM: {alpha['enhanced']}")

    # Early warning model
    print("  Running early warning model...")
    if os.path.exists(EW_SAVE_PATH):
        ew_model = EarlyWarningModel.load(EW_SAVE_PATH)
    else:
        print("  Training early warning model...")
        ew_model = EarlyWarningModel()
        ew_model.train(signals, score, lstm_epochs=60)
        ew_model.save()
    ew_warning = ew_model.predict_today(signals, score)
    ew_prob    = ew_warning["probability"]
    print(f"  Early warning: {ew_prob:.1f}% "
          f"({ew_warning['alert']})")

    # Combine all signals
    combined = combine_signals(
        stress_score=stress,
        news_crash=news_data.get("crash_signal", 0),
        geo_risk=news_data.get("geo_risk_score", 0),
        ew_prob=ew_prob,
        news_buy=news_data.get("buy_signal", 0),
    )
    # Merge news hotspots into alpha result for reporting
    if news_data.get("active_hotspots"):
        alpha["active_hotspots"] = news_data["active_hotspots"]

    # Layer 4: Portfolio optimization
    print("\n[4/4] Generating alpha-adjusted portfolio...")
    mc_engine     = MonteCarloEngine(horizon=30, df_t=7)
    current_state = signals.iloc[-1].values.astype(np.float32)

    base_portfolio = optimize_with_warning(
        crash_prob=combined["crash_prob"],
        current_state=current_state,
        mc_engine=mc_engine,
        n_scenarios=n_scenarios,
        regime=regime,
    )

    # Apply alpha hints on top
    final_portfolio = apply_alpha_to_portfolio(
        base_portfolio, alpha, mc_engine, current_state,
        n_scenarios=min(n_scenarios, 200)
    )

    # Log
    log_alpha_signal(combined, alpha, final_portfolio, date)

    # Print report
    print_full_report(combined, alpha, final_portfolio, snap, date)

    return {
        "date":      date,
        "combined":  combined,
        "alpha":     alpha,
        "portfolio": final_portfolio,
        "snapshot":  snap,
        "news":      news_data,
        "ew_prob":   ew_prob,
    }


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick",       action="store_true",
                        help="Skip news fetch (faster)")
    parser.add_argument("--opportunity", action="store_true",
                        help="Focus on buy opportunities")
    parser.add_argument("--crash",       action="store_true",
                        help="Focus on crash signals")
    parser.add_argument("--scenarios",   type=int, default=400)
    args = parser.parse_args()

    result = run_alpha_pipeline(
        skip_news=args.quick,
        n_scenarios=args.scenarios,
    )
