"""
train_and_test_10yr.py — v2 (bug fixes)
Bug fixed: missing space in "avg equity exposure{x}%" → "avg equity exposure {x}%"
"""

import numpy as np
import pandas as pd
from datetime import datetime
from typing import Dict, Optional
import argparse
import sys, os
import warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from multi_agent_system import MultiAgentPortfolioSystem
from historical_data_fetcher import (
    prepare_training_data, validate_segmentation_logic,
)
from regime_agent import REGIMES


def train_test_split_episodes(episodes: Dict, test_fraction: float = 0.2) -> tuple:
    """Chronological 80/20 split — no data leakage."""
    train_episodes = {}
    test_episodes  = {}
    for regime, data in episodes.items():
        n         = len(data["returns"])
        split_idx = int(n * (1 - test_fraction))
        train_episodes[regime] = {
            "returns": data["returns"].iloc[:split_idx].reset_index(drop=True),
            "vol":     data["vol"].iloc[:split_idx].reset_index(drop=True),
            "dd":      data["dd"].iloc[:split_idx].reset_index(drop=True),
        }
        test_episodes[regime] = {
            "returns": data["returns"].iloc[split_idx:].reset_index(drop=True),
            "vol":     data["vol"].iloc[split_idx:].reset_index(drop=True),
            "dd":      data["dd"].iloc[split_idx:].reset_index(drop=True),
        }
    return train_episodes, test_episodes


def backtest_on_holdout(system, test_episodes, multi_asset, vix_history):
    print(f"\n  Backtesting on held-out (never-trained-on) data...")
    results = {}

    for regime, data in test_episodes.items():
        returns = data["returns"]
        if len(returns) < 25:
            print(f"    {regime}: insufficient holdout data, skipping")
            continue

        full_prices = (1 + returns).cumprod()
        n_windows   = min(5, len(returns) // 20)
        window_results = []

        for w in range(n_windows):
            start = w * (len(returns) // n_windows)
            end   = min(start + 60, len(returns))
            if end - start < 25:
                continue

            window_returns = returns.iloc[start:end]

            # True drawdown vs full holdout period peak — not reset per window
            window_prices = full_prices.iloc[:end]
            running_max   = window_prices.cummax()
            true_drawdown = float(
                ((window_prices.iloc[-1] - running_max.iloc[-1]) /
                 running_max.iloc[-1]) * 100
            )

            vix_estimate = float(20 + data["vol"].iloc[start:end].mean() * 50)

            output = system.run(
                recent_returns=window_returns,
                vix=vix_estimate,
                vix_history=vix_history,
                multi_asset_returns=(multi_asset.iloc[-200:]
                                     if len(multi_asset) > 200 else multi_asset),
            )

            equity_total = sum(
                v for k, v in output.final_allocation.items() if "equity" in k
            )
            window_results.append({
                "regime_detected":   output.regime_state.regime,
                "regime_actual":     regime,
                "matched":           output.regime_state.regime == regime,
                "equity_allocation": equity_total,
                "rules_fired":       len(output.preservation_verdict.rules_triggered),
                "ood_flagged":       output.finrl_decision.is_ood,
                "true_drawdown_pct": round(true_drawdown, 1),
            })

        if window_results:
            match_rate = sum(r["matched"] for r in window_results) / len(window_results)
            avg_equity = np.mean([r["equity_allocation"] for r in window_results])
            results[regime] = {
                "windows_tested":        len(window_results),
                "regime_match_rate":     round(match_rate * 100, 1),
                "avg_equity_allocation": round(avg_equity * 100, 1),
                "details":               window_results,
            }
            # ── Bug 2 fix: space before the equity % number ──
            print(f"    {regime:10s}: {len(window_results)} windows | "
                  f"regime-ID match: {match_rate*100:.0f}% | "
                  f"avg equity exposure: {avg_equity*100:.0f}%")   # ← space fixed

    return results


def _synthetic_multi_asset(episodes):
    rng = np.random.default_rng(99)
    all_ret = pd.concat([e["returns"] for e in episodes.values()]).reset_index(drop=True)
    n = len(all_ret)
    return pd.DataFrame({
        "equity_growth": all_ret.values,
        "equity_value":  all_ret.values * 0.7 + rng.normal(0, 0.005, n),
        "bonds":         rng.normal(0.0002, 0.003, n),
        "gold":          -all_ret.values * 0.2 + rng.normal(0.0003, 0.006, n),
    })


def run_full_pipeline(market: str, years: int = 10) -> Optional[Dict]:
    print("=" * 65)
    print(f"  10-YEAR TRAIN + LIVE TEST — {market.upper()}")
    print("=" * 65)

    # ── Step 1: Fetch + segment ──
    print(f"\n[1/5] Fetching {years}-year data & auto-segmenting regimes...")
    prep = prepare_training_data(market, years)

    used_synthetic = False
    if prep is None or len(prep.get("episodes", {})) == 0:
        print("\n  yfinance unavailable — using synthetic 10-year multi-cycle data")
        print("  (same code path as real data on your machine)")
        episodes    = validate_segmentation_logic()
        multi_asset = _synthetic_multi_asset(episodes)
        vix_history = list(np.random.default_rng(1).normal(18, 5, 252).clip(8, 60))
        vix_current = float(vix_history[-1])
        used_synthetic = True
    else:
        episodes    = prep["episodes"]
        multi_asset = prep["multi_asset"]
        vix_history = prep.get("vix_history") or list(np.random.default_rng(1).normal(18,5,252))
        vix_current = prep["vix_current"]

    if not episodes:
        print("  No regimes with sufficient data. Aborting.")
        return None

    # ── Step 2: Chronological train/test split ──
    print(f"\n[2/5] 80/20 chronological split (no leakage)...")
    train_episodes, test_episodes = train_test_split_episodes(episodes, 0.2)
    for regime in train_episodes:
        n_train = len(train_episodes[regime]["returns"])
        n_test  = len(test_episodes[regime]["returns"])
        print(f"    {regime:10s}: {n_train:4d} train | {n_test:4d} holdout days")

    # ── Step 3: Train FinRL ──
    print(f"\n[3/5] Training FinRL on real regime episodes (400 episodes each)...")
    system = MultiAgentPortfolioSystem()
    system.train(train_episodes, n_episodes_per_regime=400)

    # ── Step 4: Holdout backtest ──
    print(f"\n[4/5] Backtesting on held-out data...")
    backtest_results = backtest_on_holdout(
        system, test_episodes, multi_asset, vix_history
    )

    # ── Step 5: Live recommendation ──
    print(f"\n[5/5] Running on live/current market state...")
    if used_synthetic:
        last_regime  = list(episodes.keys())[-1]
        live_returns = episodes[last_regime]["returns"].iloc[-150:]
    else:
        all_returns  = pd.concat([e["returns"] for e in episodes.values()])
        live_returns = all_returns.iloc[-150:]

    live_output = system.run(
        recent_returns=live_returns,
        vix=vix_current,
        vix_history=vix_history,
        multi_asset_returns=(multi_asset.iloc[-200:]
                             if len(multi_asset) > 200 else multi_asset),
    )

    system.print_report(live_output)
    print(f"\n  Full explanation:")
    print(live_output.explanation.full_narrative)

    return {
        "market":            market,
        "used_synthetic":    used_synthetic,
        "train_episodes":    train_episodes,
        "test_episodes":     test_episodes,
        "backtest_results":  backtest_results,
        "live_output":       live_output,
        "system":            system,
    }


def print_final_summary(result: Optional[Dict]):
    if result is None:
        return
    print(f"\n\n{'#'*65}")
    print(f"  FINAL SUMMARY — {result['market'].upper()}")
    print(f"{'#'*65}")

    src = "Synthetic (yfinance unavailable)" if result["used_synthetic"] \
          else "Real yfinance historical market data"
    print(f"  {'⚠' if result['used_synthetic'] else '✓'} DATA SOURCE: {src}")

    print(f"\n  Holdout generalization test results:")
    for regime, r in result["backtest_results"].items():
        # ── Bug 2 fix: space before equity % ──
        print(f"    {regime:10s}: regime-ID accuracy {r['regime_match_rate']:.0f}% "
              f"| avg equity exposure {r['avg_equity_allocation']:.0f}%")

    out = result["live_output"]
    print(f"\n  Today's live recommendation:")
    print(f"    Regime:     {out.regime_state.regime} "
          f"({out.regime_state.confidence*100:.0f}% confidence)")
    print(f"    Risk level: {out.risk_state.risk_level} "
          f"({out.risk_state.risk_score:.0f}/100)")

    # Explicitly flag if override fired
    overrides = [a for a in out.risk_state.alerts if "overridden" in a]
    for ov in overrides:
        print(f"    ⚡ {ov[:80]}")

    print(f"    Alert:      {out.explanation.alert_level}")
    print(f"    {out.explanation.summary}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--market", choices=["india", "us", "both"],
                        default="india")
    parser.add_argument("--years", type=int, default=10)
    args = parser.parse_args()

    markets = ["india", "us"] if args.market == "both" else [args.market]
    all_results = {}

    for market in markets:
        result = run_full_pipeline(market, args.years)
        all_results[market] = result
        print_final_summary(result)

    if len(markets) > 1 and all(v is not None for v in all_results.values()):
        print(f"\n\n{'#'*65}")
        print(f"  CROSS-MARKET COMPARISON")
        print(f"{'#'*65}")
        for market, result in all_results.items():
            if result:
                out = result["live_output"]
                overridden = any("overridden" in a
                                for a in out.risk_state.alerts)
                print(f"  {market.upper():8s}: "
                      f"regime={out.regime_state.regime:9s} "
                      f"risk={out.risk_state.risk_level:8s} "
                      f"alert={out.explanation.alert_level}"
                      f"{'  ⚡ override' if overridden else ''}")
