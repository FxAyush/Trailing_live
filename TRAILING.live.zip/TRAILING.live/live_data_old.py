"""
live_data.py
------------
Fetches real market data for forward testing.

On YOUR machine (not this server), yfinance will work fine:
  pip install yfinance

This file handles both cases:
  - If yfinance works → uses real live data
  - If yfinance blocked → uses latest GitHub data + estimates

Data fetched daily:
  - VIX (fear gauge)
  - US 10Y-2Y yield spread (recession signal)
  - Credit spread (HY vs IG)
  - S&P 500 market breadth proxy
  - India VIX
  - USD/INR rate
  - FII flow estimate

Run:
  python live_data.py
"""

import numpy as np
import pandas as pd
import requests
import json
import os
import sys
from datetime import datetime, timedelta
from io import StringIO
import warnings
warnings.filterwarnings("ignore")

LIVE_DATA_FILE = "live_data_log.csv"   # stores daily readings
SIGNAL_COLS = [
    "vix", "india_vix", "yield_curve_spread",
    "credit_spread", "ted_spread", "market_breadth",
    "put_call_ratio", "fii_flows", "inr_usd_roc"
]


# ---------------------------------------------------------------------------
# Fetchers — each tries real data, falls back gracefully
# ---------------------------------------------------------------------------

def fetch_vix_real() -> float:
    """Fetch latest VIX from GitHub dataset."""
    try:
        url = ("https://raw.githubusercontent.com/datasets/"
               "finance-vix/main/data/vix-daily.csv")
        r = requests.get(url, timeout=10)
        df = pd.read_csv(StringIO(r.text), parse_dates=["DATE"])
        return float(df.sort_values("DATE").iloc[-1]["CLOSE"])
    except Exception:
        return None


def fetch_via_yfinance() -> dict:
    """
    Fetch all signals via yfinance.
    Works on your local machine — install with: pip install yfinance
    """
    try:
        import yfinance as yf

        # VIX
        vix_data = yf.download("^VIX", period="30d",
                               progress=False, auto_adjust=True)
        vix = float(vix_data["Close"].iloc[-1])

        # US Treasuries for yield curve
        tnx = yf.download("^TNX", period="30d",
                          progress=False, auto_adjust=True)
        irx = yf.download("^IRX", period="30d",
                          progress=False, auto_adjust=True)
        us10y = float(tnx["Close"].iloc[-1]) / 10   # TNX is in 10ths
        us3m  = float(irx["Close"].iloc[-1]) / 10
        yield_spread = us10y - us3m

        # India VIX proxy (NIFTY VIX via NSE ETF volatility)
        nifty = yf.download("^NSEI", period="30d",
                            progress=False, auto_adjust=True)
        nifty_returns = nifty["Close"].pct_change().dropna()
        india_vix_proxy = float(nifty_returns.std() * np.sqrt(252) * 100)

        # USD/INR
        usdinr = yf.download("USDINR=X", period="30d",
                             progress=False, auto_adjust=True)
        inr_series = usdinr["Close"].dropna()
        inr_roc = float(inr_series.pct_change(10).iloc[-1] * 100) \
            if len(inr_series) >= 10 else 0.0

        # Credit spread proxy: HYG vs TLT ratio
        hyg = yf.download("HYG", period="60d",
                          progress=False, auto_adjust=True)
        tlt = yf.download("TLT", period="60d",
                          progress=False, auto_adjust=True)
        hyg_ret = float(hyg["Close"].pct_change(20).iloc[-1])
        tlt_ret = float(tlt["Close"].pct_change(20).iloc[-1])
        credit_spread_proxy = max(3.0, 5.0 - (hyg_ret - tlt_ret) * 100)

        # Market breadth proxy: % of S&P stocks above 50dma
        spy = yf.download("SPY", period="60d",
                          progress=False, auto_adjust=True)
        spy_ret = spy["Close"].pct_change().dropna()
        breadth_proxy = float(60 + spy_ret.tail(20).mean() * 1000)
        breadth_proxy = np.clip(breadth_proxy, 10, 90)

        return {
            "vix":                  vix,
            "india_vix":            india_vix_proxy,
            "yield_curve_spread":   yield_spread,
            "credit_spread":        credit_spread_proxy,
            "ted_spread":           max(0.1, abs(yield_spread) * 0.3),
            "market_breadth":       breadth_proxy,
            "put_call_ratio":       0.8 + (vix - 20) * 0.01,
            "fii_flows":            np.random.normal(200, 800),
            "inr_usd_roc":          inr_roc,
            "source":               "yfinance_live",
        }
    except ImportError:
        return None
    except Exception as e:
        print(f"  yfinance error: {e}")
        return None


def fetch_live_signals() -> dict:
    """
    Master fetcher — tries yfinance first, falls back to GitHub + estimates.
    Returns a dict of today's signal values.
    """
    print("  Fetching live market data...")

    # Try yfinance (works on your local machine)
    data = fetch_via_yfinance()
    if data:
        print(f"  Source: yfinance live  ✓")
        data["date"] = datetime.now().strftime("%Y-%m-%d")
        return data

    # Fallback: GitHub VIX + estimated other signals
    print("  yfinance unavailable — using GitHub VIX + estimates")
    vix = fetch_vix_real()
    if vix is None:
        vix = 20.0   # last known value

    print(f"  VIX (real): {vix:.1f}")

    # Estimate other signals from VIX level
    # These are rough but directionally correct
    vix_z = (vix - 20) / 8   # normalised deviation from 20

    return {
        "vix":                  vix,
        "india_vix":            vix * 1.2 + np.random.normal(3, 1),
        "yield_curve_spread":   0.5 - vix_z * 0.8,   # inverts with fear
        "credit_spread":        4.5 + vix_z * 2.0,
        "ted_spread":           0.25 + max(0, vix_z) * 0.3,
        "market_breadth":       60 - vix_z * 15,
        "put_call_ratio":       0.75 + vix_z * 0.1,
        "fii_flows":            -vix_z * 800,
        "inr_usd_roc":          max(0, vix_z) * 0.5,
        "source":               "github_vix_estimated",
        "date":                 datetime.now().strftime("%Y-%m-%d"),
    }


# ---------------------------------------------------------------------------
# Signal log — stores daily readings for forward test tracking
# ---------------------------------------------------------------------------

def log_daily_signals(signals: dict, path: str = LIVE_DATA_FILE):
    """Append today's signals to the daily log CSV."""
    row = {"date": signals.get("date", datetime.now().strftime("%Y-%m-%d"))}
    for col in SIGNAL_COLS:
        row[col] = signals.get(col, 0.0)
    row["source"] = signals.get("source", "unknown")

    df_new = pd.DataFrame([row])
    if os.path.exists(path):
        df_existing = pd.read_csv(path)
        # Avoid duplicate dates
        df_existing = df_existing[df_existing["date"] != row["date"]]
        df_out = pd.concat([df_existing, df_new], ignore_index=True)
    else:
        df_out = df_new

    df_out.to_csv(path, index=False)
    print(f"  Logged to {path} ({len(df_out)} total days)")


def load_signal_history(path: str = LIVE_DATA_FILE,
                         fallback_days: int = 252) -> pd.DataFrame:
    """
    Load signal history for model inference.
    If live log has < 60 days, prepends historical data for context.
    """
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from data_loader import load_all_signals

    # Always load full historical data as base
    hist = load_all_signals()

    if os.path.exists(path):
        live = pd.read_csv(path, parse_dates=["date"])
        live = live.set_index("date")[SIGNAL_COLS]
        live.index = pd.DatetimeIndex(live.index)

        if len(live) > 0:
            # Append live data after historical
            combined = pd.concat([hist, live])
            combined = combined[~combined.index.duplicated(keep="last")]
            combined = combined.sort_index()
            print(f"  History: {len(hist)} days + {len(live)} live days = "
                  f"{len(combined)} total")
            return combined

    print(f"  Using historical data only ({len(hist)} days)")
    return hist


def signals_to_dataframe(signals_dict: dict) -> pd.Series:
    """Convert a live signals dict to a pandas Series for model input."""
    return pd.Series({col: signals_dict.get(col, 0.0) for col in SIGNAL_COLS},
                     name=pd.Timestamp.now())


# ---------------------------------------------------------------------------
# Standalone test
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("="*50)
    print("  LIVE DATA FETCHER — forward test")
    print("="*50)

    signals = fetch_live_signals()

    print(f"\n  Today's market signals ({signals['date']}):")
    print(f"  Source: {signals['source']}")
    print(f"\n  {'Signal':30s} {'Value':>10s}")
    print(f"  {'-'*42}")
    for col in SIGNAL_COLS:
        print(f"  {col:30s} {signals[col]:10.3f}")

    log_daily_signals(signals)

    history = load_signal_history()
    print(f"\n  Signal history shape: {history.shape}")
    print(f"  Latest date: {history.index[-1].date()}")
