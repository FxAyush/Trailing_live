"""
forward_test_v2.py
------------------
Leakage-aware live forward testing for TRAILING.live.

Improvements:
1. Uses real market price outcomes instead of future stress score.
2. Uses 15 trading sessions, not calendar days.
3. Freezes every prediction/recommendation at prediction time.
4. Evaluates crash prediction quality and realized portfolio performance.
5. Adds Brier score, specificity and balanced accuracy.
6. Fixes MonteCarloEngine input: uses VIX z-score, not raw VIX level.
7. Logs data source and model hash for auditability.

Usage:
    python forward_test_v2.py --market us
    python forward_test_v2.py --market india
    python forward_test_v2.py --market us --accuracy
    python forward_test_v2.py --market india --history
"""

import os, sys, json, argparse, hashlib
from datetime import datetime
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from live_data import fetch_live_signals, log_daily_signals, load_signal_history, SIGNAL_COLS
from signal_processor import run_full_pipeline, get_current_snapshot
from early_warning_v3 import EarlyWarningModel, MODEL_VERSION, get_save_path
from warning_portfolio import optimize_with_warning
from monte_carlo import MonteCarloEngine

HORIZON = 15
CRASH_RETURN_THRESHOLD = -0.05
CRASH_DRAWDOWN_THRESHOLD = -0.07
PREDICTION_THRESHOLD = 0.50

ASSET_TICKERS = {
    "indian_equity": "^NSEI",
    "us_equity": "SPY",
    "emerging_markets": "EEM",
    "gold": "GLD",
    "bonds_india": "GILT5YBEES.NS",
    "bonds_us": "IEF",
    "crypto": "BTC-USD",
    "cash": None,
    "commodities": "DBC",
}
BENCHMARK_TICKERS = {"us": "^GSPC", "india": "^NSEI"}
CASH_ANNUAL_RATE = {"us": 0.04, "india": 0.055}


def _log_path(market):
    return f"forward_test_log_{market}.json"


def _csv_path(market):
    return f"forward_test_daily_{market}.csv"


def _terminal_text(value):
    """Render model labels safely in legacy Windows terminals."""
    encoding = sys.stdout.encoding or "utf-8"
    return str(value).encode(encoding, errors="replace").decode(encoding)


def _model_hash(path):
    if not os.path.exists(path):
        return "missing"
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()[:12]


def _download_close(ticker, start, end):
    import yfinance as yf
    df = yf.download(ticker, start=start, end=end, progress=False,
                     auto_adjust=True, actions=False)
    if df is None or len(df) == 0:
        return pd.Series(dtype=float)
    close = df["Close"]
    if isinstance(close, pd.DataFrame):
        close = close.iloc[:, 0]
    close = pd.to_numeric(close, errors="coerce").dropna()
    close.index = pd.DatetimeIndex(close.index).tz_localize(None)
    return close


def _market_outcome(pred_date, market, horizon=HORIZON):
    ticker = BENCHMARK_TICKERS[market]
    pred_dt = pd.Timestamp(pred_date)
    start = pred_dt - pd.Timedelta(days=5)
    end = pred_dt + pd.Timedelta(days=45)
    px = _download_close(ticker, start.strftime("%Y-%m-%d"),
                         (end + pd.Timedelta(days=1)).strftime("%Y-%m-%d"))
    if len(px) == 0:
        return None
    path = px[px.index >= pred_dt]
    if len(path) < horizon + 1:
        return None
    path = path.iloc[:horizon + 1]
    p0, p1 = float(path.iloc[0]), float(path.iloc[-1])
    fwd = p1 / p0 - 1.0
    dd = path / path.cummax() - 1.0
    mdd = float(dd.min())
    crash = (fwd <= CRASH_RETURN_THRESHOLD) or (mdd <= CRASH_DRAWDOWN_THRESHOLD)
    return {
        "ticker": ticker,
        "entry_date": str(path.index[0].date()),
        "exit_date": str(path.index[-1].date()),
        "forward_return": float(fwd),
        "max_drawdown": mdd,
        "crash": bool(crash),
    }


def _asset_return(ticker, entry_date, exit_date):
    start = pd.Timestamp(entry_date) - pd.Timedelta(days=3)
    end = pd.Timestamp(exit_date) + pd.Timedelta(days=3)
    px = _download_close(ticker, start.strftime("%Y-%m-%d"),
                         (end + pd.Timedelta(days=1)).strftime("%Y-%m-%d"))
    if len(px) == 0:
        return np.nan
    a = px[px.index >= pd.Timestamp(entry_date)]
    b = px[px.index <= pd.Timestamp(exit_date)]
    if len(a) == 0 or len(b) == 0:
        return np.nan
    p0, p1 = float(a.iloc[0]), float(b.iloc[-1])
    return p1 / p0 - 1.0 if p0 > 0 else np.nan


def _cash_return(market):
    return (1 + CASH_ANNUAL_RATE[market]) ** (HORIZON / 252.0) - 1


def _portfolio_return(weights, market, entry_date, exit_date):
    total = 0.0
    missing = 0.0
    realized = {}
    for asset, weight in weights.items():
        w = float(weight)
        if w <= 0:
            continue
        if asset == "cash":
            r = _cash_return(market)
        else:
            ticker = ASSET_TICKERS.get(asset)
            r = np.nan if ticker is None else _asset_return(ticker, entry_date, exit_date)
        if not np.isfinite(r):
            missing += w
            continue
        realized[asset] = float(r)
        total += w * r
    if missing > 0:
        total += missing * _cash_return(market)
    return {"portfolio_return": float(total),
            "asset_returns": realized,
            "missing_weight_as_cash": float(missing)}


def load_predictions(market):
    path = _log_path(market)
    if os.path.exists(path):
        with open(path, "r") as f:
            return json.load(f)
    return []


def save_predictions(preds, market):
    with open(_log_path(market), "w") as f:
        json.dump(preds, f, indent=2)


def log_prediction(market, date, crash_prob, alert, weights,
                   stress_score, regime, live_source, model_hash,
                   model_path, model_version):
    preds = load_predictions(market)
    if any(p["date"] == date for p in preds):
        print(f"  Already logged prediction for {date} ({market.upper()})")
        return
    preds.append({
        "date": date,
        "market": market,
        "crash_prob": round(float(crash_prob) * 100, 2),
        "prediction_threshold_pct": PREDICTION_THRESHOLD * 100,
        "alert": alert,
        "stress_score": round(float(stress_score), 2),
        "regime": regime,
        "weights": {k: round(float(v), 6) for k, v in weights.items()},
        "live_data_source": live_source,
        "model_hash": model_hash,
        "model_path": os.path.basename(model_path),
        "model_version": model_version,
        "horizon_trading_days": HORIZON,
        "crash_return_threshold_pct": CRASH_RETURN_THRESHOLD * 100,
        "crash_drawdown_threshold_pct": CRASH_DRAWDOWN_THRESHOLD * 100,
        "resolved": False,
        "outcome": None,
        "correct": None,
        "entry_date": None,
        "exit_date": None,
        "market_forward_return_pct": None,
        "market_max_drawdown_pct": None,
        "portfolio_forward_return_pct": None,
        "portfolio_excess_return_pct": None,
        "asset_returns_pct": None,
        "missing_weight_as_cash_pct": None,
    })
    save_predictions(preds, market)
    print(f"  Prediction logged -> {_log_path(market)}")


def update_outcomes(market):
    preds = load_predictions(market)
    updated = 0
    for pred in preds:
        if pred.get("resolved"):
            continue
        try:
            outcome = _market_outcome(pred["date"], market,
                                      pred.get("horizon_trading_days", HORIZON))
            if outcome is None:
                continue
            occurred = outcome["crash"]
            predicted = pred["crash_prob"] >= PREDICTION_THRESHOLD * 100
            port = _portfolio_return(pred["weights"], market,
                                     outcome["entry_date"], outcome["exit_date"])
            pred["resolved"] = True
            pred["outcome"] = "crash" if occurred else "no_crash"
            pred["correct"] = bool(predicted == occurred)
            pred["entry_date"] = outcome["entry_date"]
            pred["exit_date"] = outcome["exit_date"]
            pred["market_forward_return_pct"] = round(outcome["forward_return"] * 100, 3)
            pred["market_max_drawdown_pct"] = round(outcome["max_drawdown"] * 100, 3)
            pred["portfolio_forward_return_pct"] = round(port["portfolio_return"] * 100, 3)
            pred["portfolio_excess_return_pct"] = round(
                (port["portfolio_return"] - outcome["forward_return"]) * 100, 3)
            pred["asset_returns_pct"] = {k: round(v * 100, 3)
                                         for k, v in port["asset_returns"].items()}
            pred["missing_weight_as_cash_pct"] = round(
                port["missing_weight_as_cash"] * 100, 2)
            updated += 1
        except Exception as e:
            print(f"  Could not resolve {pred['date']}: {e}")
    if updated:
        save_predictions(preds, market)
        print(f"  Updated {updated} prediction outcome(s)")
    return preds


def compute_accuracy(market):
    preds = load_predictions(market)
    resolved = [p for p in preds if p.get("resolved")]
    if not resolved:
        return {"message": f"No resolved predictions yet. Need {HORIZON} future trading sessions.",
                "pending": len(preds)}

    y_true = np.array([1 if p["outcome"] == "crash" else 0 for p in resolved])
    probs = np.array([p["crash_prob"] / 100 for p in resolved], dtype=float)
    y_pred = (probs >= PREDICTION_THRESHOLD).astype(int)

    tp = int(((y_true == 1) & (y_pred == 1)).sum())
    fp = int(((y_true == 0) & (y_pred == 1)).sum())
    tn = int(((y_true == 0) & (y_pred == 0)).sum())
    fn = int(((y_true == 1) & (y_pred == 0)).sum())

    accuracy = (tp + tn) / len(y_true)
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    specificity = tn / (tn + fp) if tn + fp else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    balanced = (recall + specificity) / 2
    brier = float(np.mean((probs - y_true) ** 2))

    port = np.array([p["portfolio_forward_return_pct"] for p in resolved], dtype=float)
    bench = np.array([p["market_forward_return_pct"] for p in resolved], dtype=float)
    excess = port - bench

    return {
        "total_predictions": len(resolved),
        "pending": len([p for p in preds if not p.get("resolved")]),
        "accuracy_pct": round(accuracy * 100, 1),
        "balanced_accuracy_pct": round(balanced * 100, 1),
        "precision_pct": round(precision * 100, 1),
        "recall_pct": round(recall * 100, 1),
        "specificity_pct": round(specificity * 100, 1),
        "f1_score": round(f1, 3),
        "brier_score": round(brier, 4),
        "true_positives": tp,
        "false_positives": fp,
        "true_negatives": tn,
        "false_negatives": fn,
        "avg_portfolio_15d_return_pct": round(float(port.mean()), 3),
        "avg_benchmark_15d_return_pct": round(float(bench.mean()), 3),
        "avg_excess_15d_return_pct": round(float(excess.mean()), 3),
        "portfolio_win_rate_vs_benchmark_pct": round(float((excess > 0).mean() * 100), 1),
    }


def export_csv(market):
    preds = load_predictions(market)
    if preds:
        pd.json_normalize(preds).to_csv(_csv_path(market), index=False)


def run_daily(market="us"):
    market = market.lower()
    model_path = get_save_path(market)
    today = datetime.now().strftime("%Y-%m-%d")
    print("=" * 70)
    print(f"  TRAILING.live FORWARD TEST v2 - {market.upper()} - {today}")
    print("=" * 70)

    print("\n[1] Fetching live market signals...")
    live_signals = fetch_live_signals()
    log_daily_signals(live_signals)
    source = live_signals.get("source", "unknown")
    if source != "yfinance_real_plus_deterministic_proxies":
        print("  WARNING: fallback/estimated inputs are being used; tag this prediction lower-confidence.")

    print("\n[2] Computing stress state...")
    history = load_signal_history()
    results = run_full_pipeline(history)
    score = results["score"]
    snap = get_current_snapshot(results)
    print(f"  Stress: {snap['stress_score']:.1f}/100 ({snap['regime'].upper()}) | trend={snap['trend']}")

    print("\n[3] Early-warning model...")
    if not os.path.exists(model_path):
        model = EarlyWarningModel(market=market)
        model.train(history, score, lstm_epochs=60)
        model.save(model_path)
    else:
        model = EarlyWarningModel.load(model_path, market=market)

    warning = model.predict_today(history, score)
    prob = warning["probability"] / 100.0
    alert = warning["alert"]
    regime = snap["regime"]
    print(f"  15-session crash probability: {warning['probability']}% | alert={_terminal_text(alert)}")

    print("\n[4] Portfolio recommendation...")
    mc_engine = MonteCarloEngine(horizon=30, df_t=8, seed=42)

    # Critical fix: MonteCarloEngine expects a normalized VIX-like state in index 0.
    # The old file passed raw VIX (~15-30), which gets interpreted as an enormous z-score.
    zrow = results["z_scores"].iloc[-1].reindex(SIGNAL_COLS).fillna(0.0)
    current_state = zrow.values.astype(float)

    result = optimize_with_warning(
        crash_prob=prob,
        current_state=current_state,
        mc_engine=mc_engine,
        n_scenarios=500,
        regime=regime,
    )
    weights = result["weights_named"]

    print("\n[5] Logging frozen prediction...")
    log_prediction(market, today, prob, alert, weights,
                   snap["stress_score"], regime, source, _model_hash(model_path),
                   model_path, MODEL_VERSION)

    print("\n[6] Resolving mature predictions with REAL market data...")
    update_outcomes(market)

    print("\n[7] Forward-test metrics...")
    acc = compute_accuracy(market)
    export_csv(market)

    print("\n" + "=" * 70)
    print("  TODAY'S READING")
    print("=" * 70)
    print(f"  Market:            {market.upper()}")
    print(f"  Benchmark:         {BENCHMARK_TICKERS[market]}")
    print(f"  Stress:            {snap['stress_score']:.1f}/100 ({regime.upper()})")
    print(f"  Crash probability: {warning['probability']:.1f}%")
    print(f"  Alert:             {_terminal_text(alert)}")
    print(f"  Data source:       {source}")
    print(f"  Model:             {os.path.basename(model_path)} (v{MODEL_VERSION})")
    print(f"  Model hash:        {_model_hash(model_path)}")

    print("\n  Frozen portfolio")
    for asset, w in sorted(weights.items(), key=lambda x: -x[1]):
        if w > 0.005:
            print(f"  {asset:20s} {w * 100:7.2f}%")

    print(f"\n  MC CVaR:          {result['cvar'] * 100:.2f}%")
    print(f"  MC expected ret:  {result['expected_ret'] * 100:.2f}%")
    print(f"  MC Sharpe:        {result['sharpe']:.2f}")

    print("\n" + "=" * 70)
    print("  FORWARD TEST QUALITY")
    print("=" * 70)
    if "message" in acc:
        print(f"  {acc['message']}")
        print(f"  Pending: {acc['pending']}")
    else:
        for k, v in acc.items():
            print(f"  {k:36s}: {v}")

    print(f"\n  Log: {_log_path(market)}")
    print(f"  CSV: {_csv_path(market)}")
    return {"warning": warning, "portfolio": result,
            "accuracy": acc, "snapshot": snap}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--market", choices=["us", "india"], default="us")
    parser.add_argument("--accuracy", action="store_true")
    parser.add_argument("--history", action="store_true")
    args = parser.parse_args()
    market = args.market.lower()

    if args.accuracy:
        update_outcomes(market)
        print(json.dumps(compute_accuracy(market), indent=2))
        export_csv(market)
    elif args.history:
        preds = load_predictions(market)
        print(f"\nPrediction history - {market.upper()} ({len(preds)} entries)\n")
        print(f"{'Date':12s} {'Prob%':>7s} {'Outcome':11s} {'Port%':>8s} {'Bench%':>8s} {'OK':>4s}")
        print("-" * 65)
        for p in preds[-30:]:
            outcome = p.get("outcome") or "pending"
            port = p.get("portfolio_forward_return_pct")
            bench = p.get("market_forward_return_pct")
            ok = "Y" if p.get("correct") is True else "N" if p.get("correct") is False else "..."
            ps = f"{port:+.2f}" if port is not None else "..."
            bs = f"{bench:+.2f}" if bench is not None else "..."
            print(f"{p['date']:12s} {p['crash_prob']:6.1f}% {outcome:11s} {ps:>8s} {bs:>8s} {ok:>4s}")
    else:
        run_daily(market)
