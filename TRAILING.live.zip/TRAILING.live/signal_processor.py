"""
signal_processor_v2.py
----------------------
Causal Financial Stress Index for TRAILING.live.

Fixes the old full-history percentile leakage.

Pipeline:
1. Rolling z-score normalization
2. Category aggregation
3. Weighted composite
4. EMA smoothing
5. CAUSAL trailing percentile -> 0..100
6. Regime classification

Every score at time t uses only information available at or before t.
"""

import numpy as np
import pandas as pd
from typing import Dict, Tuple


SIGNAL_DIRECTION = {
    "vix": +1,
    "india_vix": +1,
    "yield_curve_spread": -1,
    "credit_spread": +1,
    "ted_spread": +1,
    "market_breadth": -1,
    "put_call_ratio": +1,
    "fii_flows": -1,
    "inr_usd_roc": +1,
}


CATEGORIES = {
    "credit": {
        "signals": ["credit_spread", "ted_spread"],
        "weight": 0.30,
        "label": "Credit & interbank stress",
        "description": "Credit and liquidity stress proxies",
    },
    "yield_curve": {
        "signals": ["yield_curve_spread"],
        "weight": 0.20,
        "label": "Yield curve",
        "description": "Treasury term-spread stress",
    },
    "liquidity": {
        "signals": ["vix", "market_breadth", "put_call_ratio"],
        "weight": 0.25,
        "label": "Market liquidity & sentiment",
        "description": "Volatility, breadth and options-sentiment proxies",
    },
    "india": {
        "signals": ["india_vix", "fii_flows", "inr_usd_roc"],
        "weight": 0.25,
        "label": "India-specific stress",
        "description": "India volatility, foreign-flow proxy and rupee velocity",
    },
}


REGIMES = {
    "calm": (0, 35, "green", "Markets stable. Strategy: hold."),
    "elevated": (35, 65, "amber", "Stress building. Strategy: trim risk, raise bonds."),
    "critical": (65, 101, "red", "High risk regime. Strategy: defensive shift."),
}


def rolling_zscore(
    series: pd.Series,
    window: int = 60,
    min_periods: int = 20,
) -> pd.Series:
    """
    Causal rolling z-score.

    The current observation is allowed in today's normalization because it is
    known at time t. No future observation is used.
    """
    s = pd.to_numeric(series, errors="coerce")
    roll = s.rolling(window=window, min_periods=min_periods)
    mean = roll.mean()
    std = roll.std().replace(0, np.nan)

    z = (s - mean) / std
    z = z.replace([np.inf, -np.inf], np.nan)
    return z.clip(-4, 4)


def compute_signal_zscores(
    df: pd.DataFrame,
    window: int = 60,
) -> pd.DataFrame:
    z_df = pd.DataFrame(index=df.index)

    for col, direction in SIGNAL_DIRECTION.items():
        if col not in df.columns:
            continue
        z_df[col] = rolling_zscore(df[col], window=window) * direction

    return z_df


def compute_category_scores(z_df: pd.DataFrame) -> pd.DataFrame:
    cat_df = pd.DataFrame(index=z_df.index)

    for cat_name, info in CATEGORIES.items():
        cols = [c for c in info["signals"] if c in z_df.columns]
        if cols:
            cat_df[cat_name] = z_df[cols].mean(axis=1)

    return cat_df


def _rank_last(window_values: np.ndarray) -> float:
    """
    Percentile rank of the LAST observation inside a historical window.
    Uses only that window, so this is causal.
    """
    x = np.asarray(window_values, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return np.nan

    last = x[-1]
    # Mid-rank handling for ties.
    less = np.sum(x < last)
    equal = np.sum(x == last)
    return 100.0 * (less + 0.5 * equal) / len(x)


def causal_percentile(
    series: pd.Series,
    lookback: int = 756,      # ~3 trading years
    min_periods: int = 60,
) -> pd.Series:
    """
    Rolling historical percentile using ONLY trailing/current observations.
    """
    return series.rolling(
        window=lookback,
        min_periods=min_periods
    ).apply(_rank_last, raw=True)


def compute_composite_stress(
    cat_df: pd.DataFrame,
    smooth_span: int = 5,
    percentile_lookback: int = 756,
) -> pd.Series:
    composite = pd.Series(0.0, index=cat_df.index)

    weight_used = 0.0
    for cat_name, info in CATEGORIES.items():
        if cat_name in cat_df.columns:
            composite = composite.add(
                cat_df[cat_name].fillna(0.0) * info["weight"],
                fill_value=0.0,
            )
            weight_used += info["weight"]

    if weight_used > 0:
        composite = composite / weight_used

    smoothed = composite.ewm(span=smooth_span, adjust=False).mean()

    score = causal_percentile(
        smoothed,
        lookback=percentile_lookback,
        min_periods=60,
    )

    # Neutral score during the initial warm-up only.
    score = score.fillna(50.0).clip(0, 100)
    return score.rename("stress_score")


def classify_regime(score: float) -> Tuple[str, str, str]:
    for regime, (low, high, color, desc) in REGIMES.items():
        if low <= score < high:
            return regime, color, desc
    return "critical", "red", REGIMES["critical"][3]


def _latest_causal_percentile(
    series: pd.Series,
    position: int = -1,
    lookback: int = 756,
) -> float:
    s = series.iloc[:position + 1] if position != -1 else series
    s = s.dropna()
    if len(s) == 0:
        return 50.0
    tail = s.iloc[-lookback:]
    return float(_rank_last(tail.values))


def run_full_pipeline(
    df: pd.DataFrame,
    window: int = 60,
) -> Dict[str, pd.DataFrame]:
    print(f"Processing {len(df)} days of signals (causal FSI v2)...")

    df = df.sort_index().copy()
    z_df = compute_signal_zscores(df, window=window)
    cat_df = compute_category_scores(z_df)
    score = compute_composite_stress(cat_df)

    full_df = pd.concat(
        [df, z_df.add_suffix("_z"), cat_df, score],
        axis=1
    )

    valid = score.iloc[min(60, len(score)):]
    print(f"  Score range: {valid.min():.1f} - {valid.max():.1f}")
    print(f"  Days calm:     {(valid < 35).sum():4d} ({(valid < 35).mean()*100:.1f}%)")
    print(
        f"  Days elevated: {((valid >= 35) & (valid < 65)).sum():4d} "
        f"({((valid >= 35) & (valid < 65)).mean()*100:.1f}%)"
    )
    print(
        f"  Days critical: {(valid >= 65).sum():4d} "
        f"({(valid >= 65).mean()*100:.1f}%)"
    )

    return {
        "raw": df,
        "z_scores": z_df,
        "categories": cat_df,
        "score": score,
        "full": full_df,
    }


def get_current_snapshot(
    results: Dict,
    lookback_days: int = 1,
) -> Dict:
    score_series = results["score"]
    cat_df = results["categories"]
    z_df = results["z_scores"]

    pos = -lookback_days
    latest_score = float(score_series.iloc[pos])
    regime, color, action = classify_regime(latest_score)

    cat_snapshot = {}
    for cat_name, info in CATEGORIES.items():
        if cat_name not in cat_df.columns:
            continue

        cat_z = float(cat_df[cat_name].iloc[pos])
        upto = cat_df[cat_name].iloc[:pos + 1] if pos != -1 else cat_df[cat_name]
        cat_pct = _latest_causal_percentile(upto)

        cat_snapshot[cat_name] = {
            "label": info["label"],
            "z_score": round(cat_z, 2),
            "percentile": round(cat_pct, 1),
            "description": info["description"],
        }

    latest_z = z_df.iloc[pos].dropna()
    top_signals = latest_z.sort_values(ascending=False).head(3).to_dict()

    end_pos = len(score_series) + pos + 1 if pos < 0 else pos + 1
    recent = score_series.iloc[max(0, end_pos - 30):end_pos]
    trend = (
        "rising"
        if len(recent) > 1 and recent.iloc[-1] > recent.mean()
        else "falling"
    )

    return {
        "date": str(score_series.index[pos].date()),
        "stress_score": round(latest_score, 1),
        "regime": regime,
        "color": color,
        "action": action,
        "trend": trend,
        "categories": cat_snapshot,
        "top_signals": {k: round(float(v), 2) for k, v in top_signals.items()},
    }


if __name__ == "__main__":
    from data_loader import load_all_signals

    df = load_all_signals()
    results = run_full_pipeline(df)
    snap = get_current_snapshot(results)

    print("\n--- Current causal market snapshot ---")
    print(f"Date:         {snap['date']}")
    print(f"Stress score: {snap['stress_score']:.1f}/100")
    print(f"Regime:       {snap['regime'].upper()}")
    print(f"Trend:        {snap['trend']}")
