"""
diffusion_model.py
------------------
Denoising Diffusion Probabilistic Model (DDPM) for financial time series.

What this does:
  Given the CURRENT market state (today's Z-scores), generates N realistic
  30-day future market paths — including tail scenarios like crashes and
  stagflation that rule-based systems would never anticipate.

Architecture:
  - Forward process: gradually adds Gaussian noise to real historical windows
  - Reverse process: a UNet-style network learns to denoise step by step
  - Conditioning: current stress state is injected at every denoising step
    so generated scenarios are anchored to today's market reality

Why diffusion over GAN/VAE?
  - More stable training (no mode collapse like GANs)
  - Better tail coverage (VAEs tend to average out extremes)
  - State-of-the-art for financial time series (CSDI, TimeGrad papers)

Usage:
  model = FinancialDiffusionModel(signal_dim=9, horizon=30)
  model.train_model(historical_signals_df, epochs=200)
  scenarios = model.generate_scenarios(current_state, n_scenarios=1000)
  # scenarios shape: (1000, 30, 9) — 1000 paths, 30 days, 9 signals
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import pandas as pd
import math
import os
from torch.utils.data import DataLoader, TensorDataset


DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ---------------------------------------------------------------------------
# Sinusoidal time embedding (same trick as in image diffusion models)
# Tells the network which noise level it's operating at
# ---------------------------------------------------------------------------
class SinusoidalPosEmb(nn.Module):
    def __init__(self, dim: int):
        super().__init__()
        self.dim = dim

    def forward(self, t: torch.Tensor) -> torch.Tensor:
        device = t.device
        half = self.dim // 2
        freqs = torch.exp(
            -math.log(10000) * torch.arange(half, device=device) / (half - 1)
        )
        args = t[:, None].float() * freqs[None]
        return torch.cat([args.sin(), args.cos()], dim=-1)


# ---------------------------------------------------------------------------
# Residual block: the building block of the denoising network
# ---------------------------------------------------------------------------
class ResidualBlock(nn.Module):
    def __init__(self, channels: int, time_dim: int, cond_dim: int):
        super().__init__()
        self.norm1 = nn.LayerNorm(channels)
        self.norm2 = nn.LayerNorm(channels)
        self.ff1   = nn.Linear(channels, channels * 4)
        self.ff2   = nn.Linear(channels * 4, channels)
        self.time_proj = nn.Linear(time_dim, channels)
        self.cond_proj = nn.Linear(cond_dim, channels)
        self.act   = nn.SiLU()

    def forward(self, x: torch.Tensor,
                t_emb: torch.Tensor,
                cond: torch.Tensor) -> torch.Tensor:
        # x: (B, L, C), t_emb: (B, time_dim), cond: (B, cond_dim)
        h = self.norm1(x)
        h = h + self.time_proj(self.act(t_emb))[:, None, :]
        h = h + self.cond_proj(self.act(cond))[:, None, :]
        h = self.ff1(h)
        h = self.act(h)
        h = self.ff2(h)
        h = self.norm2(h)
        return x + h   # residual connection


# ---------------------------------------------------------------------------
# Self-attention block: lets the model relate signals across time steps
# ---------------------------------------------------------------------------
class AttentionBlock(nn.Module):
    def __init__(self, channels: int, heads: int = 4):
        super().__init__()
        self.attn = nn.MultiheadAttention(channels, heads,
                                          batch_first=True, dropout=0.1)
        self.norm = nn.LayerNorm(channels)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h, _ = self.attn(x, x, x)
        return self.norm(x + h)


# ---------------------------------------------------------------------------
# Denoising UNet — the core neural network
# ---------------------------------------------------------------------------
class DenoisingUNet(nn.Module):
    """
    Predicts the noise added to a sequence at diffusion step t,
    conditioned on the current market state.

    Input:  noisy sequence (B, horizon, signal_dim) + step t + condition
    Output: predicted noise (B, horizon, signal_dim)
    """
    def __init__(self, signal_dim: int, horizon: int,
                 model_dim: int = 128, cond_dim: int = 32,
                 depth: int = 4):
        super().__init__()
        self.signal_dim = signal_dim
        self.horizon    = horizon
        time_dim        = model_dim

        # Input projection
        self.input_proj = nn.Linear(signal_dim, model_dim)

        # Time embedding
        self.time_emb = nn.Sequential(
            SinusoidalPosEmb(model_dim),
            nn.Linear(model_dim, model_dim * 2),
            nn.SiLU(),
            nn.Linear(model_dim * 2, time_dim),
        )

        # Condition projection (current stress state → cond_dim)
        self.cond_proj = nn.Sequential(
            nn.Linear(signal_dim, cond_dim * 2),
            nn.SiLU(),
            nn.Linear(cond_dim * 2, cond_dim),
        )

        # Encoder (contracting path)
        self.encoder = nn.ModuleList([
            ResidualBlock(model_dim, time_dim, cond_dim)
            for _ in range(depth)
        ])
        self.enc_attn = nn.ModuleList([
            AttentionBlock(model_dim) for _ in range(depth)
        ])

        # Bottleneck
        self.bottleneck = ResidualBlock(model_dim, time_dim, cond_dim)
        self.bot_attn   = AttentionBlock(model_dim)

        # Decoder (expanding path)
        self.decoder = nn.ModuleList([
            ResidualBlock(model_dim * 2, time_dim, cond_dim)
            for _ in range(depth)
        ])
        self.dec_proj = nn.ModuleList([
            nn.Linear(model_dim * 2, model_dim) for _ in range(depth)
        ])
        self.dec_attn = nn.ModuleList([
            AttentionBlock(model_dim) for _ in range(depth)
        ])

        # Output
        self.output_norm = nn.LayerNorm(model_dim)
        self.output_proj = nn.Linear(model_dim, signal_dim)

    def forward(self, x: torch.Tensor,
                t: torch.Tensor,
                cond: torch.Tensor) -> torch.Tensor:
        # x: (B, L, signal_dim)
        t_emb  = self.time_emb(t)              # (B, time_dim)
        c_emb  = self.cond_proj(cond)           # (B, cond_dim)
        h      = self.input_proj(x)             # (B, L, model_dim)

        # Encoder
        skips = []
        for res, attn in zip(self.encoder, self.enc_attn):
            h = res(h, t_emb, c_emb)
            h = attn(h)
            skips.append(h)

        # Bottleneck
        h = self.bottleneck(h, t_emb, c_emb)
        h = self.bot_attn(h)

        # Decoder with skip connections
        for res, proj, attn, skip in zip(
            self.decoder, self.dec_proj, self.dec_attn, reversed(skips)
        ):
            h = torch.cat([h, skip], dim=-1)
            h = res(h, t_emb, c_emb)
            h = proj(h)
            h = attn(h)

        h = self.output_norm(h)
        return self.output_proj(h)              # (B, L, signal_dim)


# ---------------------------------------------------------------------------
# DDPM noise schedule
# ---------------------------------------------------------------------------
class NoiseSchedule:
    """
    Linear beta schedule: noise level increases from beta_start to beta_end
    over T diffusion steps.
    """
    def __init__(self, T: int = 200,
                 beta_start: float = 1e-4,
                 beta_end: float = 0.02):
        self.T    = T
        betas     = torch.linspace(beta_start, beta_end, T)
        alphas    = 1.0 - betas
        alpha_bar = torch.cumprod(alphas, dim=0)

        self.betas          = betas.to(DEVICE)
        self.alphas         = alphas.to(DEVICE)
        self.alpha_bar      = alpha_bar.to(DEVICE)
        self.sqrt_ab        = alpha_bar.sqrt().to(DEVICE)
        self.sqrt_one_m_ab  = (1 - alpha_bar).sqrt().to(DEVICE)

    def q_sample(self, x0: torch.Tensor,
                 t: torch.Tensor) -> tuple:
        """Forward process: add noise to x0 at step t."""
        noise  = torch.randn_like(x0)
        sqrt_ab        = self.sqrt_ab[t][:, None, None]
        sqrt_one_m_ab  = self.sqrt_one_m_ab[t][:, None, None]
        xt = sqrt_ab * x0 + sqrt_one_m_ab * noise
        return xt, noise


# ---------------------------------------------------------------------------
# Main diffusion model class
# ---------------------------------------------------------------------------
class FinancialDiffusionModel:
    def __init__(self, signal_dim: int = 9, horizon: int = 30,
                 T: int = 200, model_dim: int = 128):
        self.signal_dim = signal_dim
        self.horizon    = horizon
        self.T          = T

        self.schedule   = NoiseSchedule(T)
        self.network    = DenoisingUNet(signal_dim, horizon,
                                        model_dim=model_dim).to(DEVICE)
        self.optimizer  = torch.optim.Adam(self.network.parameters(), lr=1e-4)
        self.scheduler  = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer, T_max=200
        )

        # Data normalisation stats (set during training)
        self.mean = None
        self.std  = None

    def _normalise(self, x: np.ndarray) -> np.ndarray:
        return (x - self.mean) / (self.std + 1e-8)

    def _denormalise(self, x: np.ndarray) -> np.ndarray:
        return x * (self.std + 1e-8) + self.mean

    def _build_dataset(self, signals: pd.DataFrame,
                       lookback: int = 60) -> TensorDataset:
        """
        Sliding window dataset:
          - context window (lookback days) → condition
          - forecast window (horizon days) → target to generate
        """
        data = signals.values.astype(np.float32)

        self.mean = data.mean(axis=0)
        self.std  = data.std(axis=0)
        data = self._normalise(data)

        contexts, futures = [], []
        step = max(1, self.horizon // 2)

        for i in range(lookback, len(data) - self.horizon, step):
            ctx = data[i - lookback:i]          # (lookback, signal_dim)
            fut = data[i:i + self.horizon]       # (horizon, signal_dim)
            contexts.append(ctx[-1])             # use last day as condition
            futures.append(fut)

        ctx_t = torch.tensor(np.array(contexts), dtype=torch.float32)
        fut_t = torch.tensor(np.array(futures),  dtype=torch.float32)
        return TensorDataset(ctx_t, fut_t)

    def train_model(self, signals: pd.DataFrame,
                    epochs: int = 200,
                    batch_size: int = 64,
                    save_path: str = "diffusion_model.pt") -> list:
        """
        Train the diffusion model on historical signal data.

        Args:
            signals:    DataFrame of shape (n_days, signal_dim)
            epochs:     training epochs
            batch_size: mini-batch size
            save_path:  where to save model weights

        Returns:
            List of per-epoch losses
        """
        print(f"Building dataset...")
        dataset    = self._build_dataset(signals)
        loader     = DataLoader(dataset, batch_size=batch_size,
                                shuffle=True, drop_last=True)
        print(f"  {len(dataset)} training windows | "
              f"{len(loader)} batches/epoch")

        self.network.train()
        losses = []

        for epoch in range(1, epochs + 1):
            epoch_loss = 0.0

            for cond, x0 in loader:
                cond = cond.to(DEVICE)
                x0   = x0.to(DEVICE)
                B    = x0.shape[0]

                # Sample random diffusion step t for each example
                t = torch.randint(0, self.T, (B,), device=DEVICE)

                # Forward process: add noise
                xt, noise = self.schedule.q_sample(x0, t)

                # Predict noise
                pred_noise = self.network(xt, t, cond)

                # Loss: MSE between predicted and actual noise
                loss = F.mse_loss(pred_noise, noise)

                self.optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(
                    self.network.parameters(), max_norm=1.0
                )
                self.optimizer.step()
                epoch_loss += loss.item()

            self.scheduler.step()
            avg_loss = epoch_loss / len(loader)
            losses.append(avg_loss)

            if epoch % 20 == 0 or epoch == 1:
                lr = self.optimizer.param_groups[0]["lr"]
                print(f"  Epoch {epoch:3d}/{epochs} | "
                      f"loss={avg_loss:.5f} | lr={lr:.2e}")

        self._save(save_path)
        return losses

    @torch.no_grad()
    def generate_scenarios(self, current_state: np.ndarray,
                           n_scenarios: int = 1000) -> np.ndarray:
        """
        Generate N realistic 30-day future market paths conditioned on
        the current market state.

        Args:
            current_state: shape (signal_dim,) — today's signal values
            n_scenarios:   number of paths to generate

        Returns:
            scenarios: shape (n_scenarios, horizon, signal_dim)
                       in original (denormalised) signal space
        """
        self.network.eval()

        if self.mean is None:
            raise RuntimeError("Model not trained yet. Call train_model() first.")

        # Normalise the current state
        cond_norm = self._normalise(current_state.astype(np.float32))
        cond = torch.tensor(cond_norm, dtype=torch.float32)\
                    .unsqueeze(0)\
                    .repeat(n_scenarios, 1)\
                    .to(DEVICE)           # (n_scenarios, signal_dim)

        # Start from pure noise
        x = torch.randn(n_scenarios, self.horizon, self.signal_dim,
                        device=DEVICE)

        # Reverse diffusion: T → 0, denoising step by step
        for t_idx in reversed(range(self.T)):
            t_batch = torch.full((n_scenarios,), t_idx,
                                 dtype=torch.long, device=DEVICE)

            pred_noise = self.network(x, t_batch, cond)

            alpha     = self.schedule.alphas[t_idx]
            alpha_bar = self.schedule.alpha_bar[t_idx]
            beta      = self.schedule.betas[t_idx]

            # DDPM reverse step
            coef = (1 - alpha) / (1 - alpha_bar).sqrt()
            x = (1 / alpha.sqrt()) * (x - coef * pred_noise)

            if t_idx > 0:
                # Add controlled noise (not in final step)
                noise = torch.randn_like(x)
                x = x + beta.sqrt() * noise

        # Denormalise
        scenarios = x.cpu().numpy()
        scenarios = self._denormalise(scenarios)
        return scenarios

    def _save(self, path: str):
        torch.save({
            "network":    self.network.state_dict(),
            "mean":       self.mean,
            "std":        self.std,
            "signal_dim": self.signal_dim,
            "horizon":    self.horizon,
            "T":          self.T,
        }, path)
        print(f"  Model saved → {path}")

    @classmethod
    def load(cls, path: str) -> "FinancialDiffusionModel":
        ckpt  = torch.load(path, map_location=DEVICE, weights_only=False)
        model = cls(signal_dim=ckpt["signal_dim"],
                    horizon=ckpt["horizon"],
                    T=ckpt["T"])
        model.network.load_state_dict(ckpt["network"])
        model.mean = ckpt["mean"]
        model.std  = ckpt["std"]
        print(f"Model loaded from {path}")
        return model


# ---------------------------------------------------------------------------
# Quick standalone test
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys
    sys.path.insert(0, "/home/claude/crisis_detector")
    from data_loader import load_all_signals

    print("Loading signals...")
    signals = load_all_signals()

    model = FinancialDiffusionModel(
        signal_dim=signals.shape[1],
        horizon=30,
        T=100,          # reduced for quick test
        model_dim=64,   # reduced for quick test
    )

    print(f"\nTraining diffusion model on {DEVICE}...")
    losses = model.train_model(signals, epochs=40, batch_size=32,
                               save_path="diffusion_model.pt")
    print(f"Final loss: {losses[-1]:.5f}")

    # Generate scenarios from latest market state
    current_state = signals.iloc[-1].values
    print(f"\nGenerating 100 scenarios from current market state...")
    scenarios = model.generate_scenarios(current_state, n_scenarios=100)

    print(f"Scenarios shape: {scenarios.shape}")
    print(f"  Signal 0 (VIX) — mean across paths: "
          f"{scenarios[:, :, 0].mean():.2f} ± "
          f"{scenarios[:, :, 0].std():.2f}")
    print(f"  5th percentile path (tail scenario): "
          f"{np.percentile(scenarios[:, -1, 0], 5):.2f}")
    print(f"  95th percentile path: "
          f"{np.percentile(scenarios[:, -1, 0], 95):.2f}")
    print("\nDiffusion model test passed.")
