"""
explanation_agent.py
---------------------
AGENT 5: Explanation Agent

Converts the technical output of Agents 1-4 into the kind of plain-
language explanation a retail investor actually understands and trusts.

THE PRINCIPLE (exactly as specified):
  Instead of:  "AI recommends selling."
  You show:    "Portfolio equity exposure reduced from 80% to 55%
                because market turbulence exceeded historical
                thresholds and volatility increased by 40%."

This agent does NOT make decisions. It only explains decisions already
made by Agents 1-4. This separation matters: the explanation must be
a faithful, traceable description of what actually happened in the
rule engine and RL policy — never a post-hoc rationalization that
could diverge from the real reasoning (a known failure mode in LLM-
generated explanations of black-box systems).

Three output formats:
  1. One-line summary    — for push notifications
  2. Paragraph explanation — for the dashboard "why" card
  3. Full audit trail      — for the user who taps "show me everything"
"""

from typing import Dict, List
from dataclasses import dataclass
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from regime_agent import RegimeState, REGIME_COLORS
from risk_agent import RiskState
from finrl_agent import FinRLDecision
from capital_preservation_agent import PreservationVerdict


ASSET_DISPLAY_NAMES = {
    "equity_growth": "growth equity (high-beta)",
    "equity_value":  "value equity (defensive)",
    "bonds":         "bonds",
    "gold":          "gold",
    "cash":          "cash",
}


def _ordinal(n: float) -> str:
    """Convert 93 -> '93rd', 12 -> '12th', 1 -> '1st', etc."""
    i = int(round(n))
    if 10 <= i % 100 <= 20:
        suf = "th"
    else:
        suf = {1: "st", 2: "nd", 3: "rd"}.get(i % 10, "th")
    return f"{i}{suf}"


@dataclass
class Explanation:
    headline:           str   # one-line, for notifications
    summary:             str   # 2-3 sentence paragraph, for dashboard
    full_narrative:        str   # complete walkthrough of all 4 agents
    key_numbers:            Dict[str, str]
    alert_level:             str   # INFO / CAUTION / WARNING / CRITICAL


class ExplanationAgent:
    """
    Pure presentation layer. Takes the structured outputs of the
    other four agents and renders them as human-readable text.

    Every sentence here is generated from actual numeric values
    produced upstream — nothing is invented or "sounds plausible."
    This is deliberately template-based rather than LLM-generated
    for the core explanation, because a compliance-grade explanation
    of a financial decision must be exactly reproducible and
    traceable to the inputs, not subject to LLM sampling variance.

    (An optional LLM polish pass can be layered on top for tone,
    but the substantive content below is fully deterministic.)
    """

    def explain(self, regime_state: RegimeState,
               risk_state: RiskState,
               finrl_decision: FinRLDecision,
               preservation_verdict: PreservationVerdict) -> Explanation:

        # ── Determine overall alert level ──
        severity_map = {"NONE": "INFO", "MODERATE": "CAUTION",
                        "SEVERE": "WARNING", "CRITICAL": "CRITICAL"}
        alert_level = severity_map.get(preservation_verdict.severity, "INFO")

        equity_before = preservation_verdict.total_equity_before
        equity_after  = preservation_verdict.total_equity_after
        equity_changed = abs(equity_before - equity_after) > 0.02

        # ── Headline (one line, for push notification) ──
        headline = self._build_headline(
            regime_state, risk_state, preservation_verdict,
            equity_before, equity_after, equity_changed
        )

        # ── Summary (2-3 sentences, for dashboard card) ──
        summary = self._build_summary(
            regime_state, risk_state, finrl_decision,
            preservation_verdict, equity_before, equity_after
        )

        # ── Full narrative (complete agent-by-agent walkthrough) ──
        narrative = self._build_full_narrative(
            regime_state, risk_state, finrl_decision, preservation_verdict
        )

        # ── Key numbers for UI display ──
        key_numbers = {
            "regime":            f"{REGIME_COLORS[regime_state.regime]} {regime_state.regime}",
            "risk_score":        f"{risk_state.risk_score:.0f}/100 ({risk_state.risk_level})",
            "drawdown":          f"{risk_state.drawdown_pct:.1f}%",
            "volatility":        f"{risk_state.realized_vol_20d:.1f}% annualised",
            "equity_exposure":   f"{equity_before*100:.0f}% → {equity_after*100:.0f}%",
            "cash_allocation":   f"{preservation_verdict.cash_after*100:.0f}%",
            "rules_triggered":   str(len(preservation_verdict.rules_triggered)),
        }

        return Explanation(
            headline=headline,
            summary=summary,
            full_narrative=narrative,
            key_numbers=key_numbers,
            alert_level=alert_level,
        )

    def _build_headline(self, regime: RegimeState, risk: RiskState,
                        verdict: PreservationVerdict,
                        eq_before: float, eq_after: float,
                        changed: bool) -> str:
        if not changed:
            return (f"{REGIME_COLORS[regime.regime]} {regime.regime} market, "
                    f"risk {risk.risk_level.lower()} — no changes needed")

        direction = "reduced" if eq_after < eq_before else "increased"
        return (
            f"⚠️ Equity exposure {direction} {eq_before*100:.0f}% → "
            f"{eq_after*100:.0f}% — {verdict.severity.lower()} risk action"
        )

    def _build_summary(self, regime: RegimeState, risk: RiskState,
                       finrl: FinRLDecision, verdict: PreservationVerdict,
                       eq_before: float, eq_after: float) -> str:
        if not verdict.override_applied:
            return (
                f"Markets are in a {regime.regime.lower()} regime "
                f"({regime.confidence*100:.0f}% confidence) with "
                f"{risk.risk_level.lower()} risk levels. Your portfolio "
                f"allocation remains unchanged at {eq_before*100:.0f}% equity exposure."
            )

        # Build the EXACT sentence pattern you specified:
        # "Portfolio equity exposure reduced from 80% to 55% because
        #  market turbulence exceeded historical thresholds and
        #  volatility increased by 40%."
        reasons = []

        if risk.turbulence_percentile >= 90:
            reasons.append(
                f"market turbulence reached the {_ordinal(risk.turbulence_percentile)} "
                f"percentile of historical readings"
            )
        if risk.vol_regime in ("ELEVATED", "EXTREME"):
            reasons.append(
                f"volatility rose to {risk.realized_vol_20d:.0f}% annualised "
                f"({risk.vol_regime.lower()} levels)"
            )
        if risk.drawdown_pct <= -12:
            reasons.append(
                f"your portfolio drew down {abs(risk.drawdown_pct):.1f}% "
                f"from its recent high"
            )
        if risk.correlation_spike:
            reasons.append(
                "normally uncorrelated assets began moving together "
                "(a classic warning sign of systemic stress)"
            )
        if regime.regime == "CRISIS":
            reasons.append(
                "the market entered a crisis regime"
            )

        if not reasons:
            reasons.append("risk thresholds were exceeded")

        reason_text = self._join_reasons(reasons)

        direction = ("reduced" if eq_after < eq_before else "increased")

        return (
            f"Portfolio equity exposure {direction} from "
            f"{eq_before*100:.0f}% to {eq_after*100:.0f}% because "
            f"{reason_text}."
        )

    def _join_reasons(self, reasons: List[str]) -> str:
        if len(reasons) == 1:
            return reasons[0]
        if len(reasons) == 2:
            return f"{reasons[0]} and {reasons[1]}"
        return ", ".join(reasons[:-1]) + f", and {reasons[-1]}"

    def _build_full_narrative(self, regime: RegimeState, risk: RiskState,
                              finrl: FinRLDecision,
                              verdict: PreservationVerdict) -> str:
        lines = []

        lines.append("HOW THIS DECISION WAS MADE")
        lines.append("=" * 50)

        lines.append(f"\n1. REGIME DETECTION")
        lines.append(
            f"   Classified as {regime.regime} "
            f"({regime.confidence*100:.0f}% confidence), "
            f"in this regime for {regime.days_in_regime} days."
        )
        lines.append(f"   {regime.description}")
        if regime.transition_risk > 0.3:
            lines.append(
                f"   ⚠ Elevated transition risk "
                f"({regime.transition_risk*100:.0f}%) — regime could "
                f"shift soon."
            )

        lines.append(f"\n2. RISK ASSESSMENT")
        lines.append(
            f"   Composite risk score: {risk.risk_score:.0f}/100 "
            f"({risk.risk_level})"
        )
        lines.append(
            f"   20-day volatility: {risk.realized_vol_20d:.1f}% "
            f"annualised ({risk.vol_regime})"
        )
        lines.append(
            f"   Drawdown: {risk.drawdown_pct:.1f}% "
            f"({risk.drawdown_duration} days since last high)"
        )
        if risk.turbulence_percentile > 0:
            lines.append(
                f"   Turbulence index: {_ordinal(risk.turbulence_percentile)} "
                f"percentile of historical readings"
            )
        if risk.correlation_spike:
            lines.append(
                f"   ⚠ Correlation spike: assets moved together "
                f"(avg correlation {risk.avg_correlation:.2f})"
            )
        for alert in risk.alerts:
            lines.append(f"   ⚠ {alert}")

        lines.append(f"\n3. FinRL POLICY RECOMMENDATION")
        lines.append(f"   Regime-specific policy used: {finrl.regime_used}")
        lines.append(f"   Policy confidence: {finrl.confidence*100:.0f}%")
        if finrl.is_ood:
            lines.append(
                f"   ⚠ Out-of-distribution detected "
                f"(score {finrl.ood_score:.2f}) — today's conditions "
                f"don't resemble anything the policy was trained on."
            )
        lines.append(
            f"   Blended {finrl.blend_weight*100:.0f}% policy recommendation "
            f"/ {(1-finrl.blend_weight)*100:.0f}% conservative safe floor."
        )
        lines.append(f"   {finrl.reasoning}")

        lines.append(f"\n4. CAPITAL PRESERVATION CHECK")
        if verdict.override_applied:
            lines.append(
                f"   {len(verdict.rules_triggered)} protection rule(s) "
                f"triggered (severity: {verdict.severity}):"
            )
            for rule in verdict.rules_triggered:
                lines.append(f"   • {rule}")
        else:
            lines.append(
                "   No protection rules triggered — "
                "FinRL recommendation approved as-is."
            )

        lines.append(f"\n5. FINAL ALLOCATION")
        for asset, weight in sorted(
            verdict.final_allocation.items(), key=lambda x: -x[1]
        ):
            name = ASSET_DISPLAY_NAMES.get(asset, asset)
            lines.append(f"   {name}: {weight*100:.1f}%")

        return "\n".join(lines)


if __name__ == "__main__":
    print("=" * 60)
    print("  AGENT 5: EXPLANATION AGENT")
    print("=" * 60)

    # Build fake upstream states matching your specified example
    from regime_agent import RegimeState
    from risk_agent import RiskState
    from finrl_agent import FinRLDecision
    from capital_preservation_agent import PreservationVerdict

    regime_state = RegimeState(
        regime="BEAR", confidence=0.82,
        probabilities={"BULL":0.05,"BEAR":0.82,"SIDEWAYS":0.08,"CRISIS":0.05},
        days_in_regime=4, transition_risk=0.35,
        description="Sustained downtrend, elevated volatility, narrow breadth",
    )

    risk_state = RiskState(
        vix_level=28.4, vix_percentile=88.0,
        realized_vol_20d=29.0, realized_vol_60d=21.0,
        vol_regime="ELEVATED",
        drawdown_pct=-13.2, drawdown_duration=18,
        turbulence_index=8.4, turbulence_percentile=93.0,
        correlation_spike=True, avg_correlation=0.71,
        risk_score=68.0, risk_level="HIGH",
        alerts=["Volatility elevated: 29.0% annualised",
               "Drawdown -13.2% exceeds 12% threshold"],
    )

    finrl_decision = FinRLDecision(
        raw_allocation={"equity_growth":0.45,"equity_value":0.20,
                       "bonds":0.15,"gold":0.12,"cash":0.08},
        safe_floor={"equity_growth":0.05,"equity_value":0.20,
                   "bonds":0.40,"gold":0.20,"cash":0.15},
        final_allocation={"equity_growth":0.25,"equity_value":0.20,
                         "bonds":0.27,"gold":0.16,"cash":0.12},
        regime_used="BEAR", confidence=0.55,
        is_ood=False, ood_score=0.2, blend_weight=0.5,
        reasoning="Moderate confidence in BEAR regime — blended 50/50.",
    )

    preservation_verdict = PreservationVerdict(
        input_allocation=finrl_decision.final_allocation,
        final_allocation={"equity_growth":0.16,"equity_value":0.14,
                         "bonds":0.32,"gold":0.23,"cash":0.15},
        rules_triggered=[
            "Drawdown -13.2% exceeds -12% threshold → reduced equity exposure by 30%",
            "Volatility spike (29.0% annualised ≥ 32% threshold) → cash allocation increased to ≥20%",
        ],
        override_applied=True,
        total_equity_before=0.45, total_equity_after=0.30,
        cash_before=0.12, cash_after=0.15,
        severity="SEVERE",
    )

    agent = ExplanationAgent()
    exp = agent.explain(regime_state, risk_state, finrl_decision,
                        preservation_verdict)

    print(f"\nALERT LEVEL: {exp.alert_level}")
    print(f"\nHEADLINE (push notification):")
    print(f"  {exp.headline}")
    print(f"\nSUMMARY (dashboard card):")
    print(f"  {exp.summary}")
    print(f"\nKEY NUMBERS:")
    for k, v in exp.key_numbers.items():
        print(f"  {k:20s}: {v}")
    print(f"\nFULL NARRATIVE:")
    print(exp.full_narrative)
