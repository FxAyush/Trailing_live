"""
cvar_engine.py
--------------
Conditional Value at Risk (CVaR) computation engine.

CVaR = "In the worst α% of scenarios, what is the average loss?"

Why CVaR instead of VaR?
  VaR tells you the loss threshold (e.g. "you won't lose more than 15%
  with 95% probability"). But it says nothing about HOW BAD the losses
  are beyond that threshold.

  CVaR is the AVERAGE loss in those worst scenarios — it captures the
  full tail and is mathematically coherent (sub-additive, convex).
  Hedge funds, banks, and regulators use CVaR.

  Example:
    Scenario A: 95% VaR = 10%,  CVaR = 11%  ← nice thin tail
    Scenario B: 95% VaR = 10%,  CVaR = 35%  ← fat tail, dangerous
    Standard VaR says they're identical. CVaR reveals B is far riskier.

Usage:
  engine  = CVaREngine(alpha=0.05)  # worst 5% of scenarios
  metrics = engine.compute(portfolio_weights, scenarios)
  safe    = engine.check_constraint(metrics, max_cvar=0.15)
"""

import numpy as np
import pandas as pd
from typing import Dict, Tuple, List
from scipy.optimize import minimize


# ---------------------------------------------------------------------------
# Portfolio return simulation
# ---------------------------------------------------------------------------

ASSET_CLASSES = [
    "indian_equity",
    "us_equity",
    "emerging_markets",
    "gold",
    "bonds_india",
    "bonds_us",
    "crypto",
    "cash",
    "commodities",
]


def signals_to_returns(scenarios: np.ndarray) -> np.ndarray:
    """
    Convert raw signal scenarios (stress Z-scores) to approximate
    asset-class return scenarios.

    In production: replace with actual asset return data.
    Here: we use domain-knowledge mappings between signals and returns.

    Args:
        scenarios: (n_scenarios, horizon, signal_dim)
    Returns:
        returns: (n_scenarios, horizon, n_assets)
    """
    n_sc, horizon, _ = scenarios.shape
    n_assets = len(ASSET_CLASSES)
    returns  = np.zeros((n_sc, horizon, n_assets))

    # Unpack signal dimensions (must match data_loader column order)
    # [0]vix, [1]india_vix, [2]yield_curve, [3]credit_spread,
    # [4]ted_spread, [5]market_breadth, [6]put_call_ratio,
    # [7]fii_flows, [8]inr_usd_roc

    vix         = scenarios[:, :, 0]   # high = bad for equities
    india_vix   = scenarios[:, :, 1]
    yield_curve = scenarios[:, :, 2]   # negative = bad for bonds/equities
    credit_sp   = scenarios[:, :, 3]   # high = bad for equities
    ted         = scenarios[:, :, 4]   # high = bad for everything
    breadth     = scenarios[:, :, 5]   # low = bad for equities
    fii         = scenarios[:, :, 7]   # negative = bad for india
    inr_roc     = scenarios[:, :, 8]   # positive = bad for indian assets

    rng = np.random.default_rng(42)
    base_noise = rng.normal(0, 0.003, (n_sc, horizon, n_assets))

    # Indian equity: hurt by india_vix, fii outflows, INR depreciation
    returns[:, :, 0] = (
        - 0.008 * (india_vix / 25)
        - 0.004 * (credit_sp / 5)
        + 0.002 * (fii / 1000).clip(-3, 3)
        - 0.003 * inr_roc.clip(-2, 2)
        + 0.0003   # base drift
        + base_noise[:, :, 0]
    )

    # US equity: hurt by vix, credit spread, tight yield curve
    returns[:, :, 1] = (
        - 0.007 * (vix / 20)
        - 0.003 * (credit_sp / 5)
        - 0.002 * (1 / (yield_curve.clip(0.1, 5)))
        + 0.0004
        + base_noise[:, :, 1]
    )

    # Emerging markets: hurt by VIX + USD strength (INR proxy)
    returns[:, :, 2] = (
        - 0.009 * (vix / 20)
        - 0.004 * inr_roc.clip(-2, 2)
        + 0.0003
        + base_noise[:, :, 2]
    )

    # Gold: BENEFITS from fear (safe haven)
    returns[:, :, 3] = (
        + 0.004 * (vix / 20)
        + 0.002 * (ted / 0.5)
        - 0.001 * yield_curve.clip(0, 3)
        + 0.0002
        + base_noise[:, :, 3]
    )

    # Indian bonds: hurt by INR depreciation, benefits from fear
    returns[:, :, 4] = (
        + 0.002 * (vix / 20)
        - 0.003 * inr_roc.clip(-2, 2)
        + 0.0002
        + base_noise[:, :, 4]
    )

    # US Treasury bonds: flight-to-safety in crises
    returns[:, :, 5] = (
        + 0.003 * (vix / 20)
        + 0.004 * (ted / 0.5)
        - 0.001 * credit_sp.clip(0, 10)
        + 0.0002
        + base_noise[:, :, 5]
    )

    # Crypto: extremely sensitive to VIX, credit, and sentiment
    returns[:, :, 6] = (
        - 0.020 * (vix / 20)
        - 0.010 * (credit_sp / 5)
        - 0.008 * (ted / 0.5)
        + 0.0005
        + base_noise[:, :, 6] * 3  # higher volatility
    )

    # Cash: stable but loses to inflation
    returns[:, :, 7] = (
        np.full((n_sc, horizon), 0.0001)
        + base_noise[:, :, 7] * 0.1
    )

    # Commodities: mixed — some benefit from inflation scenarios
    returns[:, :, 8] = (
        - 0.003 * (vix / 20)
        + 0.002 * (credit_sp.clip(0, 5) / 5)
        + 0.0001
        + base_noise[:, :, 8]
    )

    return returns


# ---------------------------------------------------------------------------
# CVaR Engine
# ---------------------------------------------------------------------------
class CVaREngine:
    """
    Computes CVaR from Monte Carlo scenarios generated by the diffusion model.

    alpha = confidence level (e.g. 0.05 = worst 5% of scenarios)
    """

    def __init__(self, alpha: float = 0.05):
        self.alpha = alpha

    def portfolio_returns(self, weights: np.ndarray,
                          asset_returns: np.ndarray) -> np.ndarray:
        """
        Compute cumulative portfolio return for each scenario.

        Args:
            weights:       (n_assets,) portfolio allocation weights
            asset_returns: (n_scenarios, horizon, n_assets)
        Returns:
            cum_returns:   (n_scenarios,) — total return over horizon
        """
        weights = np.array(weights)
        weights = weights / weights.sum()  # normalise

        # Daily portfolio return = weighted sum of asset returns
        daily = (asset_returns * weights[None, None, :]).sum(axis=-1)

        # Cumulative return: compound daily returns
        cum = (1 + daily).prod(axis=1) - 1
        return cum

    def compute(self, weights: np.ndarray,
                scenarios: np.ndarray) -> Dict:
        """
        Full CVaR computation from diffusion-generated scenarios.

        Args:
            weights:   (n_assets,) portfolio weights
            scenarios: (n_scenarios, horizon, signal_dim) raw signal scenarios

        Returns dict with:
            cvar:          CVaR at alpha level (e.g. -0.12 = -12% average loss)
            var:           Value at Risk threshold
            expected_ret:  mean return across all scenarios
            worst_returns: returns in the tail
            all_returns:   full return distribution
            n_scenarios:   number of scenarios used
        """
        asset_rets  = signals_to_returns(scenarios)
        port_rets   = self.portfolio_returns(weights, asset_rets)

        # Sort returns ascending (worst first)
        sorted_rets = np.sort(port_rets)
        n = len(sorted_rets)

        # Tail cutoff index
        tail_idx    = max(1, int(np.ceil(self.alpha * n)))
        tail_rets   = sorted_rets[:tail_idx]

        cvar        = float(tail_rets.mean())
        var         = float(sorted_rets[tail_idx])
        expected    = float(port_rets.mean())
        vol         = float(port_rets.std())
        sharpe      = expected / vol * np.sqrt(252) if vol > 0 else 0.0

        # Percentile breakdown
        pct = {
            "p1":   float(np.percentile(port_rets, 1)),
            "p5":   float(np.percentile(port_rets, 5)),
            "p10":  float(np.percentile(port_rets, 10)),
            "p25":  float(np.percentile(port_rets, 25)),
            "p50":  float(np.percentile(port_rets, 50)),
            "p75":  float(np.percentile(port_rets, 75)),
            "p90":  float(np.percentile(port_rets, 90)),
        }

        return {
            "cvar":          cvar,
            "var":           var,
            "expected_ret":  expected,
            "volatility":    vol,
            "sharpe":        sharpe,
            "percentiles":   pct,
            "worst_returns": tail_rets,
            "all_returns":   port_rets,
            "n_scenarios":   n,
            "tail_size":     tail_idx,
            "alpha":         self.alpha,
        }

    def check_constraint(self, metrics: Dict,
                         max_cvar: float = -0.15) -> Tuple[bool, str]:
        """
        Check if CVaR satisfies the safety constraint.

        Args:
            metrics:  output from compute()
            max_cvar: maximum allowed CVaR (negative = loss)
                      e.g. -0.15 means "worst 5% scenarios must not
                      average worse than -15%"

        Returns:
            (is_safe, explanation)
        """
        cvar = metrics["cvar"]
        is_safe = cvar >= max_cvar

        if is_safe:
            explanation = (
                f"SAFE — CVaR({self.alpha*100:.0f}%) = "
                f"{cvar*100:.1f}% (limit: {max_cvar*100:.1f}%). "
                f"In the worst {self.alpha*100:.0f}% of scenarios, "
                f"average loss is {abs(cvar)*100:.1f}%."
            )
        else:
            explanation = (
                f"UNSAFE — CVaR({self.alpha*100:.0f}%) = "
                f"{cvar*100:.1f}% exceeds limit {max_cvar*100:.1f}%. "
                f"Action repair required."
            )

        return is_safe, explanation

    def minimum_cvar_weights(self, scenarios: np.ndarray,
                             max_cvar: float = -0.15,
                             allow_short: bool = False) -> np.ndarray:
        """
        Find portfolio weights that minimise CVaR subject to constraints.
        This is the CVaR-optimal portfolio — used as the safe fallback.

        Uses scipy optimisation (convex problem → global optimum guaranteed).
        """
        n_assets = len(ASSET_CLASSES)
        asset_rets = signals_to_returns(scenarios)

        def objective(w):
            m = self.compute(w, scenarios)
            # Minimise CVaR while penalising low expected return
            return m["cvar"] - 0.3 * m["expected_ret"]

        constraints = [{"type": "eq",  "fun": lambda w: w.sum() - 1}]
        bounds = [(-0.1, 0.5) if allow_short else (0.0, 0.5)
                  for _ in range(n_assets)]

        # Start from equal weights
        w0 = np.ones(n_assets) / n_assets
        result = minimize(objective, w0,
                          method="SLSQP",
                          bounds=bounds,
                          constraints=constraints,
                          options={"maxiter": 500, "ftol": 1e-8})

        if result.success:
            return result.x / result.x.sum()
        else:
            # Fallback: max cash + bonds
            w = np.zeros(n_assets)
            w[4] = 0.4   # Indian bonds
            w[5] = 0.4   # US bonds
            w[7] = 0.2   # Cash
            return w

    def explain_risk(self, weights: np.ndarray,
                     scenarios: np.ndarray,
                     metrics: Dict = None) -> str:
        """
        Generate a plain-language explanation of portfolio risk
        suitable for showing to a retail investor.
        """
        if metrics is None:
            metrics = self.compute(weights, scenarios)

        lines = []
        cvar  = metrics["cvar"]
        var   = metrics["var"]
        pct   = metrics["percentiles"]

        lines.append("PORTFOLIO RISK ANALYSIS")
        lines.append("=" * 40)

        lines.append(
            f"\nIn the next 30 days, across {metrics['n_scenarios']} "
            f"simulated market scenarios:"
        )

        lines.append(
            f"\n  Expected return:  {metrics['expected_ret']*100:+.1f}%"
        )
        lines.append(
            f"  Median return:    {pct['p50']*100:+.1f}%"
        )

        lines.append("\nDownside scenarios:")
        lines.append(
            f"  1-in-10 chance of loss worse than: {pct['p10']*100:.1f}%"
        )
        lines.append(
            f"  1-in-20 chance of loss worse than: {var*100:.1f}%"
        )
        lines.append(
            f"  Average loss in worst 5% of scenarios (CVaR): "
            f"{cvar*100:.1f}%"
        )

        lines.append("\nUpside scenarios:")
        lines.append(
            f"  1-in-4 chance of gain better than: {pct['p75']*100:.1f}%"
        )

        # Risk level
        if cvar > -0.05:
            risk_level = "LOW RISK"
        elif cvar > -0.15:
            risk_level = "MODERATE RISK"
        elif cvar > -0.25:
            risk_level = "HIGH RISK"
        else:
            risk_level = "VERY HIGH RISK"

        lines.append(f"\nOverall risk level: {risk_level}")
        lines.append(
            f"Sharpe ratio: {metrics['sharpe']:.2f} "
            f"({'good' if metrics['sharpe'] > 0.5 else 'needs improvement'})"
        )

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Standalone test
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print("CVaR Engine — standalone test")
    print("=" * 40)

    # Simulate 200 scenarios of shape (200, 30, 9)
    rng = np.random.default_rng(0)
    dummy_scenarios = rng.normal(0, 1, (200, 30, 9))
    # Inject a stress event in first signal (VIX)
    dummy_scenarios[:50, :, 0] += 3  # tail scenarios have high VIX

    engine = CVaREngine(alpha=0.05)

    # Test aggressive portfolio (crypto-heavy)
    aggressive = np.array([0.30, 0.20, 0.10, 0.05,
                            0.05, 0.05, 0.20, 0.02, 0.03])
    m_agg = engine.compute(aggressive, dummy_scenarios)

    # Test defensive portfolio (bonds-heavy)
    defensive = np.array([0.10, 0.10, 0.05, 0.10,
                           0.25, 0.25, 0.02, 0.10, 0.03])
    m_def = engine.compute(defensive, dummy_scenarios)

    print("\nAggressive (30% Indian equity, 20% crypto):")
    print(f"  CVaR(5%):    {m_agg['cvar']*100:.1f}%")
    print(f"  Expected:    {m_agg['expected_ret']*100:.1f}%")
    print(f"  Sharpe:      {m_agg['sharpe']:.2f}")

    ok, msg = engine.check_constraint(m_agg, max_cvar=-0.15)
    print(f"  Constraint:  {'✓' if ok else '✗'} {msg}")

    print("\nDefensive (25% Indian bonds, 25% US bonds):")
    print(f"  CVaR(5%):    {m_def['cvar']*100:.1f}%")
    print(f"  Expected:    {m_def['expected_ret']*100:.1f}%")
    print(f"  Sharpe:      {m_def['sharpe']:.2f}")

    ok, msg = engine.check_constraint(m_def, max_cvar=-0.15)
    print(f"  Constraint:  {'✓' if ok else '✗'} {msg}")

    print("\n" + engine.explain_risk(defensive, dummy_scenarios, m_def))

    print("\nFinding CVaR-optimal weights...")
    optimal = engine.minimum_cvar_weights(dummy_scenarios)
    print("Optimal weights:")
    for asset, w in zip(ASSET_CLASSES, optimal):
        print(f"  {asset:20s}: {w*100:.1f}%")
