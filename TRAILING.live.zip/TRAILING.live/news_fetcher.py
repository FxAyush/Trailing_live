"""
news_fetcher.py
---------------
Layer 2 — fetches and scores news from RSS feeds, Reddit, and financial sites.

For every news item it computes:
  - Sentiment score (-1 to +1)
  - Market impact score (0-100)
  - Affected assets (which stocks/sectors/countries)
  - Signal type: CRASH_WARNING or BUY_OPPORTUNITY

Free sources used (no API key needed):
  - RSS feeds: Reuters, Bloomberg, Economic Times, Moneycontrol
  - Reddit: r/wallstreetbets, r/IndiaInvestments, r/stocks (via RSS)
  - Google News RSS (no key needed)
"""

import feedparser
import requests
from bs4 import BeautifulSoup
from textblob import TextBlob
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict
import re, json, time, os, sys
import warnings
warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# News sources — all free RSS feeds
# ---------------------------------------------------------------------------
RSS_FEEDS = {
    # Global macro
    "reuters_markets":   "https://feeds.reuters.com/reuters/businessNews",
    "reuters_world":     "https://feeds.reuters.com/Reuters/worldNews",

    # India specific
    "economic_times":    "https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms",
    "moneycontrol":      "https://www.moneycontrol.com/rss/business.xml",
    "livemint":          "https://www.livemint.com/rss/markets",
    "hindu_business":    "https://www.thehindubusinessline.com/feeder/default.rss",

    # Global tech/AI
    "techcrunch":        "https://techcrunch.com/feed/",
    "hnews":             "https://news.ycombinator.com/rss",

    # Geopolitics
    "aljazeera":         "https://www.aljazeera.com/xml/rss/all.xml",
    "bbc_world":         "https://feeds.bbci.co.uk/news/world/rss.xml",

    # Reddit (public JSON)
    "wsb":               "https://www.reddit.com/r/wallstreetbets/new.json?limit=25",
    "india_invest":      "https://www.reddit.com/r/IndiaInvestments/new.json?limit=25",
    "stocks":            "https://www.reddit.com/r/stocks/new.json?limit=25",
}

# ---------------------------------------------------------------------------
# Keyword maps — which words indicate what kind of signal
# ---------------------------------------------------------------------------

CRASH_KEYWORDS = {
    # Geopolitical
    "war": 8, "attack": 7, "missile": 7, "sanction": 7,
    "conflict": 6, "escalat": 8, "nuclear": 9, "invasion": 8,
    "coup": 7, "crisis": 6, "collapse": 8, "default": 8,
    # Economic
    "recession": 8, "inflation surge": 8, "rate hike": 6,
    "bank run": 9, "credit crisis": 8, "debt crisis": 7,
    "bankruptcy": 7, "bubble burst": 9, "market crash": 9,
    "selloff": 6, "panic": 7, "circuit breaker": 8,
    # India specific
    "fii outflow": 7, "rupee fall": 6, "nifty fall": 6,
    "rbi emergency": 9, "sebi ban": 7,
}

BUY_KEYWORDS = {
    # AI/Tech opportunity
    "ai breakthrough": 9, "artificial intelligence": 5,
    "semiconductor": 6, "data center": 6, "cloud": 4,
    "earnings beat": 8, "revenue surge": 8, "profit jump": 7,
    "new product": 5, "partnership": 5, "acquisition": 6,
    "patent": 4, "launch": 5, "expansion": 5,
    # India opportunity
    "india gdp growth": 8, "fdi inflow": 7, "capex": 6,
    "infrastructure": 5, "pli scheme": 7, "export growth": 6,
    "startup funding": 5, "ipo": 6, "green energy": 6,
    # Macro opportunity
    "rate cut": 8, "stimulus": 7, "fed pivot": 8,
    "soft landing": 7, "recovery": 6, "bull market": 6,
    "undervalued": 5, "oversold": 6,
}

# Asset impact mapping — which keywords affect which assets
ASSET_IMPACT = {
    "oil": ["commodities", "indian_equity", "emerging_markets"],
    "gold": ["gold"],
    "rupee": ["indian_equity", "bonds_india", "inr_usd_roc"],
    "nifty": ["indian_equity"],
    "fed": ["us_equity", "bonds_us", "emerging_markets"],
    "china": ["emerging_markets", "commodities"],
    "tech": ["us_equity", "indian_equity"],
    "crypto": ["crypto"],
    "israel": ["commodities", "gold", "emerging_markets"],
    "iran": ["commodities", "gold", "emerging_markets"],
    "india": ["indian_equity", "bonds_india"],
    "us equity": ["us_equity"],
    "bond": ["bonds_us", "bonds_india"],
    "inflation": ["gold", "commodities", "bonds_us"],
    "recession": ["bonds_us", "gold", "cash"],
    "ai": ["us_equity", "indian_equity"],
    "semiconductor": ["us_equity"],
    "bank": ["indian_equity", "us_equity"],
}

# Geopolitical hotspot tracker
GEOPOLITICAL_HOTSPOTS = {
    "israel": {"region": "Middle East", "impact": "oil_spike", "severity": 8},
    "iran":   {"region": "Middle East", "impact": "oil_spike", "severity": 8},
    "russia": {"region": "Europe",      "impact": "energy_crisis", "severity": 7},
    "ukraine":{"region": "Europe",      "impact": "energy_crisis", "severity": 7},
    "china":  {"region": "Asia",        "impact": "trade_war", "severity": 7},
    "taiwan": {"region": "Asia",        "impact": "semiconductor", "severity": 9},
    "north korea": {"region": "Asia",   "impact": "geopolitical", "severity": 6},
    "pakistan": {"region": "South Asia","impact": "india_border", "severity": 7},
}


# ---------------------------------------------------------------------------
# News item class
# ---------------------------------------------------------------------------
class NewsItem:
    def __init__(self, title: str, summary: str, source: str,
                 url: str = "", published: str = ""):
        self.title     = title
        self.summary   = summary
        self.source    = source
        self.url       = url
        self.published = published
        self.full_text = f"{title}. {summary}"

        # Computed fields
        self.sentiment       = 0.0
        self.crash_score     = 0.0
        self.buy_score       = 0.0
        self.signal_type     = "NEUTRAL"
        self.affected_assets = []
        self.geopolitical    = False
        self.hotspot         = None
        self.confidence      = 0.0
        self.thesis          = ""

    def to_dict(self) -> dict:
        return {
            "title":          self.title[:100],
            "source":         self.source,
            "sentiment":      round(self.sentiment, 3),
            "crash_score":    round(self.crash_score, 1),
            "buy_score":      round(self.buy_score, 1),
            "signal_type":    self.signal_type,
            "affected_assets":self.affected_assets,
            "geopolitical":   self.geopolitical,
            "hotspot":        self.hotspot,
            "confidence":     round(self.confidence, 2),
            "thesis":         self.thesis,
            "published":      self.published,
        }


# ---------------------------------------------------------------------------
# Fetcher
# ---------------------------------------------------------------------------
class NewsFetcher:

    def __init__(self, max_age_hours: int = 24):
        self.max_age_hours = max_age_hours
        self.headers = {
            "User-Agent": "Mozilla/5.0 (FinTech Research Bot/1.0)"
        }

    def _fetch_rss(self, url: str, source: str) -> List[NewsItem]:
        items = []
        try:
            feed = feedparser.parse(url)
            for entry in feed.entries[:15]:
                title   = entry.get("title", "")
                summary = entry.get("summary", "")
                link    = entry.get("link", "")
                pub     = entry.get("published", "")

                # Clean HTML from summary
                if summary:
                    summary = BeautifulSoup(summary, "html.parser").get_text()
                    summary = summary[:500]

                if title:
                    items.append(NewsItem(title, summary, source, link, pub))
        except Exception as e:
            pass
        return items

    def _fetch_reddit(self, url: str, source: str) -> List[NewsItem]:
        items = []
        try:
            r = requests.get(url, headers=self.headers, timeout=8)
            if r.status_code != 200:
                return items
            data = r.json()
            posts = data.get("data", {}).get("children", [])
            for post in posts[:10]:
                d       = post.get("data", {})
                title   = d.get("title", "")
                summary = d.get("selftext", "")[:300]
                url_p   = d.get("url", "")
                score   = d.get("score", 0)
                if title and score > 10:
                    items.append(NewsItem(title, summary, source, url_p))
        except Exception:
            pass
        return items

    def fetch_all(self) -> List[NewsItem]:
        """Fetch from all sources. Falls back to simulation if blocked."""
        all_items = []
        print("  Fetching news sources...")
        success_count = 0

        for name, url in RSS_FEEDS.items():
            if "reddit" in url:
                items = self._fetch_reddit(url, name)
            else:
                items = self._fetch_rss(url, name)

            if items:
                print(f"    {name:25s}: {len(items)} items")
                all_items.extend(items)
                success_count += 1
            time.sleep(0.2)

        if success_count == 0:
            print("  Live feeds blocked - using simulated news for demo")
            print("  NOTE: On your Windows machine, all feeds will work")
            all_items = self._simulate_news()

        print(f"  Total raw items: {len(all_items)}")
        return all_items

    def _simulate_news(self) -> List[NewsItem]:
        """Simulated news for demo when RSS blocked. Real feeds replace this on your machine."""
        return [
            NewsItem("Israel strikes Iranian nuclear facility, oil markets rattled",
                "Oil prices surge 4% as Israel conducts strikes. Gold at 3-month high.",
                "simulated", "", datetime.now().isoformat()),
            NewsItem("Iran threatens Strait of Hormuz closure after Israeli attack",
                "20% of global oil supply at risk. India faces inflation risk.",
                "simulated", "", datetime.now().isoformat()),
            NewsItem("India market falls on Israel-Iran war escalation fears",
                "Nifty drops as FIIs sell. Rupee weakens. Oil-sensitive sectors hit.",
                "simulated", "", datetime.now().isoformat()),
            NewsItem("NVIDIA reports record AI chip revenue, beats estimates by 40%",
                "Data center revenue grows 150% YoY. Indian IT stocks rally on AI spend.",
                "simulated", "", datetime.now().isoformat()),
            NewsItem("India GDP growth hits 7.8%, fastest growing major economy",
                "FDI inflows surge. Manufacturing PMI at 5-year high.",
                "simulated", "", datetime.now().isoformat()),
            NewsItem("US yield curve inversion deepens, recession fears grow",
                "10Y-2Y spread at -0.45%. Credit spreads widening.",
                "simulated", "", datetime.now().isoformat()),
            NewsItem("RBI holds rates, signals possible cut next quarter",
                "Bond markets rally. Rate cut expected if inflation stays below 4%.",
                "simulated", "", datetime.now().isoformat()),
            NewsItem("Bitcoin ETF sees record inflow, institutional adoption surges",
                "BlackRock Bitcoin ETF crosses $30B AUM. Crypto market at $3T.",
                "simulated", "", datetime.now().isoformat()),
            NewsItem("Global oil supply disruption could push crude to $120",
                "Analysts warn conflict could cut supply 3Mbpd. India CAD risk elevated.",
                "simulated", "", datetime.now().isoformat()),
            NewsItem("Anthropic raises $3B, semiconductor demand surges with AI boom",
                "India PLI scheme attracts Apple supplier investment in semiconductors.",
                "simulated", "", datetime.now().isoformat()),
        ]


# ---------------------------------------------------------------------------
# Scorer — analyses each news item
# ---------------------------------------------------------------------------
class NewsScorer:

    def score(self, item: NewsItem) -> NewsItem:
        text_lower = item.full_text.lower()

        # 1. Sentiment via TextBlob
        blob = TextBlob(item.full_text)
        item.sentiment = blob.sentiment.polarity

        # 2. Crash score — keyword matching
        crash_score = 0.0
        for kw, weight in CRASH_KEYWORDS.items():
            if kw in text_lower:
                crash_score += weight
        item.crash_score = min(crash_score, 100)

        # 3. Buy score — keyword matching
        buy_score = 0.0
        for kw, weight in BUY_KEYWORDS.items():
            if kw in text_lower:
                buy_score += weight
        item.buy_score = min(buy_score, 100)

        # 4. Geopolitical detection
        for hotspot, info in GEOPOLITICAL_HOTSPOTS.items():
            if hotspot in text_lower:
                item.geopolitical = True
                item.hotspot      = hotspot
                # Geopolitical news amplifies crash score
                item.crash_score  = min(item.crash_score +
                                        info["severity"] * 3, 100)
                break

        # 5. Affected assets
        affected = set()
        for keyword, assets in ASSET_IMPACT.items():
            if keyword in text_lower:
                affected.update(assets)
        item.affected_assets = list(affected)

        # 6. Signal type
        if item.crash_score > item.buy_score and item.crash_score > 15:
            item.signal_type = "CRASH_WARNING"
        elif item.buy_score > item.crash_score and item.buy_score > 15:
            item.signal_type = "BUY_OPPORTUNITY"
        else:
            item.signal_type = "NEUTRAL"

        # 7. Confidence (based on score magnitude and sentiment alignment)
        if item.signal_type == "CRASH_WARNING":
            sent_align = 1 + (-item.sentiment)  # negative sentiment aligns
            item.confidence = min(item.crash_score / 100 * sent_align, 1.0)
        elif item.signal_type == "BUY_OPPORTUNITY":
            sent_align = 1 + item.sentiment
            item.confidence = min(item.buy_score / 100 * sent_align, 1.0)

        # 8. Generate thesis
        item.thesis = self._generate_thesis(item)

        return item

    def _generate_thesis(self, item: NewsItem) -> str:
        """Generate a plain-language investment thesis from the news item."""
        if item.signal_type == "CRASH_WARNING":
            if item.geopolitical and item.hotspot:
                return (f"Geopolitical escalation ({item.hotspot}) detected. "
                        f"Historical pattern: {item.hotspot} tensions → "
                        f"oil spike → EM selloff → FII outflows from India. "
                        f"Suggest reducing equity exposure in "
                        f"{', '.join(item.affected_assets[:3])}.")
            else:
                return (f"Negative market signal detected. "
                        f"Crash score: {item.crash_score:.0f}/100. "
                        f"Affected: {', '.join(item.affected_assets[:3])}. "
                        f"Consider defensive rebalancing.")

        elif item.signal_type == "BUY_OPPORTUNITY":
            return (f"Positive alpha signal detected. "
                    f"Opportunity score: {item.buy_score:.0f}/100. "
                    f"Affected: {', '.join(item.affected_assets[:3])}. "
                    f"Consider increasing allocation.")

        return "Neutral signal — monitor for developments."

    def score_all(self, items: List[NewsItem]) -> List[NewsItem]:
        return [self.score(item) for item in items]


# ---------------------------------------------------------------------------
# Aggregator — combines all news into summary signals
# ---------------------------------------------------------------------------
class NewsAggregator:

    def aggregate(self, scored_items: List[NewsItem]) -> Dict:
        """
        Aggregate all scored news into summary signals for the alpha agent.
        """
        if not scored_items:
            return self._empty_aggregate()

        crash_items = [i for i in scored_items
                       if i.signal_type == "CRASH_WARNING"]
        buy_items   = [i for i in scored_items
                       if i.signal_type == "BUY_OPPORTUNITY"]
        geo_items   = [i for i in scored_items if i.geopolitical]

        # Overall crash signal (0-100)
        if crash_items:
            crash_signal = np.percentile(
                [i.crash_score * i.confidence for i in crash_items], 75
            )
        else:
            crash_signal = 0.0

        # Overall buy signal (0-100)
        if buy_items:
            buy_signal = np.percentile(
                [i.buy_score * i.confidence for i in buy_items], 75
            )
        else:
            buy_signal = 0.0

        # Geopolitical risk score
        geo_score = 0.0
        active_hotspots = []
        for item in geo_items:
            if item.hotspot:
                info = GEOPOLITICAL_HOTSPOTS.get(item.hotspot, {})
                geo_score = max(geo_score,
                               info.get("severity", 5) * item.confidence * 10)
                if item.hotspot not in active_hotspots:
                    active_hotspots.append(item.hotspot)

        # Most affected assets
        all_affected = []
        for item in crash_items + buy_items:
            all_affected.extend(item.affected_assets)
        asset_counts = {}
        for a in all_affected:
            asset_counts[a] = asset_counts.get(a, 0) + 1
        top_assets = sorted(asset_counts.items(),
                           key=lambda x: -x[1])[:5]

        # Top stories
        top_crash = sorted(crash_items,
                          key=lambda x: -x.crash_score * x.confidence)[:3]
        top_buy   = sorted(buy_items,
                          key=lambda x: -x.buy_score * x.confidence)[:3]

        # Sentiment trend
        sentiments = [i.sentiment for i in scored_items]
        avg_sentiment = float(np.mean(sentiments)) if sentiments else 0.0

        return {
            "timestamp":       datetime.now().isoformat(),
            "total_articles":  len(scored_items),
            "crash_articles":  len(crash_items),
            "buy_articles":    len(buy_items),
            "geo_articles":    len(geo_items),

            "crash_signal":    round(float(crash_signal), 1),
            "buy_signal":      round(float(buy_signal), 1),
            "geo_risk_score":  round(float(geo_score), 1),
            "avg_sentiment":   round(avg_sentiment, 3),
            "active_hotspots": active_hotspots,
            "top_affected_assets": [a for a, _ in top_assets],

            "top_crash_stories": [i.to_dict() for i in top_crash],
            "top_buy_stories":   [i.to_dict() for i in top_buy],

            "overall_signal": (
                "CRASH_WARNING"   if crash_signal > 50 and crash_signal > buy_signal
                else "BUY_OPPORTUNITY" if buy_signal > 50 and buy_signal > crash_signal
                else "ELEVATED_RISK"   if crash_signal > 25
                else "NEUTRAL"
            ),
        }

    def _empty_aggregate(self) -> Dict:
        return {
            "timestamp": datetime.now().isoformat(),
            "total_articles": 0, "crash_articles": 0,
            "buy_articles": 0, "geo_articles": 0,
            "crash_signal": 0.0, "buy_signal": 0.0,
            "geo_risk_score": 0.0, "avg_sentiment": 0.0,
            "active_hotspots": [], "top_affected_assets": [],
            "top_crash_stories": [], "top_buy_stories": [],
            "overall_signal": "NEUTRAL",
        }


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------
def run_news_pipeline() -> Dict:
    """Run the complete news fetch → score → aggregate pipeline."""
    fetcher    = NewsFetcher()
    scorer     = NewsScorer()
    aggregator = NewsAggregator()

    items  = fetcher.fetch_all()
    scored = scorer.score_all(items)
    result = aggregator.aggregate(scored)
    return result


if __name__ == "__main__":
    print("="*55)
    print("  NEWS + SENTIMENT LAYER")
    print("="*55)

    result = run_news_pipeline()

    print(f"\n  Articles fetched:    {result['total_articles']}")
    print(f"  Crash warnings:      {result['crash_articles']}")
    print(f"  Buy opportunities:   {result['buy_articles']}")
    print(f"  Geopolitical items:  {result['geo_articles']}")
    print(f"\n  Overall signal:      {result['overall_signal']}")
    print(f"  Crash signal score:  {result['crash_signal']}/100")
    print(f"  Buy signal score:    {result['buy_signal']}/100")
    print(f"  Geo risk score:      {result['geo_risk_score']}/100")
    print(f"  Avg sentiment:       {result['avg_sentiment']:+.3f}")

    if result["active_hotspots"]:
        print(f"\n  Active hotspots: {', '.join(result['active_hotspots'])}")

    if result["top_crash_stories"]:
        print(f"\n  Top crash signals:")
        for s in result["top_crash_stories"][:2]:
            print(f"    [{s['crash_score']:.0f}] {s['title'][:65]}")
            print(f"         → {s['thesis'][:80]}")

    if result["top_buy_stories"]:
        print(f"\n  Top buy signals:")
        for s in result["top_buy_stories"][:2]:
            print(f"    [{s['buy_score']:.0f}] {s['title'][:65]}")
            print(f"         → {s['thesis'][:80]}")
