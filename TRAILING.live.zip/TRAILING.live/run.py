"""
run.py  — single entry point for everything
--------------------------------------------
Commands:
  python run.py                  → instant recommendation (no training needed)
  python run.py --train          → train RL policy (~15 min on GPU)
  python run.py --risk low       → conservative allocation
  python run.py --risk medium    → balanced allocation
  python run.py --risk high      → growth allocation
  python run.py --backtest       → walk-forward backtest
"""

import argparse, sys, os
import numpy as np
import pandas as pd
import torch
import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from data_loader          import load_all_signals
from signal_processor     import run_full_pipeline, get_current_snapshot
from monte_carlo          import MonteCarloEngine, mc_portfolio_returns, ASSET_CLASSES, N_ASSETS
from cvar_engine          import CVaREngine
from portfolio_optimizer  import CVaROptimizer, ReturnMaximiser, StableRLTrainer, BOUNDS, BOUNDS_BY_REGIME

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

RISK_PROFILES = {
    "low":    {"risk_tolerance": 0.2, "max_cvar": -0.07, "label": "Conservative"},
    "medium": {"risk_tolerance": 0.5, "max_cvar": -0.10, "label": "Balanced"},
    "high":   {"risk_tolerance": 0.8, "max_cvar": -0.13, "label": "Growth"},
}


def print_header():
    print("=" * 60)
    print("  FINTECH PLATFORM — PORTFOLIO RECOMMENDATION ENGINE")
    print(f"  Device: {DEVICE}")
    print("=" * 60)


def print_result(result: dict, metrics: dict, snap: dict,
                 used_rl: bool = False, risk_label: str = "Balanced"):
    w   = result["weights_named"]
    pct = metrics["percentiles"]

    print(f"\n{'='*60}")
    print(f"  STRESS INDEX")
    print(f"{'='*60}")
    score  = snap['stress_score']
    regime = snap['regime'].upper()
    trend  = snap['trend']
    bar    = "█" * int(score / 5)
    print(f"  Score:  {score:.1f}/100  {bar}")
    print(f"  Regime: {regime}  |  Trend: {trend}")
    print(f"\n  Category breakdown:")
    for cat, info in snap["categories"].items():
        filled = "█" * int(info["percentile"] / 10)
        empty  = "░" * (10 - int(info["percentile"] / 10))
        print(f"    {info['label'][:28]:28s} {filled}{empty}  "
              f"{info['percentile']:.0f}th pct")

    print(f"\n{'='*60}")
    print(f"  PORTFOLIO RECOMMENDATION  [{risk_label}]"
          f"{'  [RL-enhanced]' if used_rl else '  [CVaR-optimized]'}")
    print(f"{'='*60}")

    print(f"\n  Allocation:")
    for asset, weight in sorted(w.items(), key=lambda x: -x[1]):
        if weight > 0.001:
            filled = "█" * int(weight * 40)
            print(f"    {asset:20s}  {weight*100:5.1f}%  {filled}")

    print(f"\n  Risk metrics (30-day outlook, {metrics['n_scenarios']} scenarios):")
    print(f"    Expected return:           {metrics['expected_ret']*100:+.1f}%")
    print(f"    Median return:             {pct['p50']*100:+.1f}%")
    print(f"    CVaR — worst 5% avg loss:  {metrics['cvar']*100:.1f}%")
    print(f"    Sharpe ratio:              {metrics['sharpe']:.2f}")

    print(f"\n  Scenario distribution:")
    print(f"    Best  (top 10%):  {pct['p90']*100:+.1f}%")
    print(f"    Good  (top 25%):  {pct['p75']*100:+.1f}%")
    print(f"    Base  (median):   {pct['p50']*100:+.1f}%")
    print(f"    Bad   (bot 10%):  {pct['p10']*100:+.1f}%")
    print(f"    Worst (bot  5%):  {pct['p5']*100:+.1f}%")

    status = "✓ SAFE" if result["is_safe"] else "✗ UNSAFE"
    print(f"\n  Safety check: {status}  "
          f"(CVaR {metrics['cvar']*100:.1f}% vs limit "
          f"{result.get('max_cvar', -0.15)*100:.0f}%)")

    # Plain-language summary
    print(f"\n  Summary:")
    if regime == "CRITICAL":
        print(f"    Markets are under significant stress. The portfolio")
        print(f"    is positioned defensively — heavy bonds and gold to")
        print(f"    protect capital. Equity exposure is minimised.")
    elif regime == "ELEVATED":
        print(f"    Markets show elevated stress. A balanced defensive")
        print(f"    posture with moderate equity and strong bond cushion.")
    else:
        print(f"    Markets are calm. A diversified growth allocation")
        print(f"    across equities, bonds, and commodities.")


def run_recommendation(signals, mc_engine, risk="medium",
                       n_scenarios=500, rl_path=None):
    profile  = RISK_PROFILES[risk]
    max_cvar = profile["max_cvar"]
    rt       = profile["risk_tolerance"]

    # Stress index
    results = run_full_pipeline(signals)
    snap    = get_current_snapshot(results)
    regime  = snap["regime"]

    # Generate scenarios
    current_state = signals.iloc[-1].values.astype(np.float32)
    print(f"\nGenerating {n_scenarios} Monte Carlo scenarios...")
    scenarios = mc_engine.generate_scenarios(current_state, n_scenarios)

    used_rl = False
    result  = None

    # Try RL policy first if available
    if rl_path and os.path.exists(rl_path):
        try:
            trainer, state_dim = StableRLTrainer.load_policy(rl_path)
            current_weights = np.ones(N_ASSETS) / N_ASSETS
            state = np.concatenate([current_state, current_weights]).astype(np.float32)
            state_t = torch.FloatTensor(state).unsqueeze(0).to(DEVICE)
            weights = trainer.policy.get_weights(state_t)

            # Compute metrics
            cvar_eng = CVaREngine(alpha=0.05)
            port_rets = mc_portfolio_returns(weights, scenarios)
            n  = len(port_rets)
            tn = max(1, int(np.ceil(0.05 * n)))
            cvar = float(np.sort(port_rets)[:tn].mean())

            if cvar >= max_cvar:
                used_rl = True
                result  = {
                    "weights":       weights,
                    "weights_named": dict(zip(ASSET_CLASSES, weights)),
                    "cvar":          cvar,
                    "expected_ret":  float(port_rets.mean()),
                    "sharpe":        float(port_rets.mean() /
                                          (port_rets.std() + 1e-8) * np.sqrt(12)),
                    "is_safe":       True,
                    "regime":        regime,
                    "max_cvar":      max_cvar,
                }
        except Exception as e:
            print(f"  RL policy load failed ({e}), using CVaR optimizer")

    # Fallback: CVaR optimizer (always gives good results)
    if result is None:
        print(f"Optimizing portfolio (CVaR limit: {max_cvar*100:.0f}%)...")
        optimizer = CVaROptimizer(alpha=0.05, max_cvar=max_cvar)
        result    = optimizer.optimize(scenarios, regime=regime,
                                       risk_tolerance=rt)
        result["max_cvar"] = max_cvar

    # Compute full metrics
    port_rets = mc_portfolio_returns(result["weights"], scenarios)
    n  = len(port_rets)
    tn = max(1, int(np.ceil(0.05 * n)))
    metrics = {
        "cvar":         float(np.sort(port_rets)[:tn].mean()),
        "expected_ret": float(port_rets.mean()),
        "volatility":   float(port_rets.std()),
        "sharpe":       float(port_rets.mean() /
                              (port_rets.std() + 1e-8) * np.sqrt(12)),
        "n_scenarios":  n,
        "percentiles":  {f"p{p}": float(np.percentile(port_rets, p))
                         for p in [1,5,10,25,50,75,90]},
    }

    return result, metrics, snap, used_rl


def run_backtest(signals, mc_engine, risk="medium",
                 n_scenarios=200, step_days=21):
    profile  = RISK_PROFILES[risk]
    max_cvar = profile["max_cvar"]
    rt       = profile["risk_tolerance"]
    optimizer = CVaROptimizer(alpha=0.05, max_cvar=max_cvar)

    # Benchmark: 50% Indian equity, 30% bonds, 10% gold, 10% cash
    bench_w = np.zeros(N_ASSETS)
    idx_map = {a: i for i, a in enumerate(ASSET_CLASSES)}
    bench_w[idx_map["indian_equity"]] = 0.50
    bench_w[idx_map["bonds_india"]]   = 0.30
    bench_w[idx_map["gold"]]          = 0.10
    bench_w[idx_map["cash"]]          = 0.10

    indices = range(60, len(signals) - step_days - 5, step_days)
    print(f"\nBacktest: {len(indices)} rebalance points, "
          f"step={step_days} days, risk={risk}")

    records = []
    for i, idx in enumerate(indices):
        state     = signals.iloc[idx].values.astype(np.float32)
        scenarios = mc_engine.generate_scenarios(state, n_scenarios)

        # Get stress regime
        stress_result = run_full_pipeline(signals.iloc[max(0,idx-60):idx+1])
        regime = stress_result["score"].apply(
            lambda s: "calm" if s < 35 else ("elevated" if s < 65 else "crisis")
        ).iloc[-1]

        # Optimize
        result   = optimizer.optimize(scenarios, regime=regime,
                                      risk_tolerance=rt)
        strategy_w = result["weights"]

        # Forward returns (next step_days)
        fwd_sc     = mc_engine.generate_scenarios(state, n_scenarios)[:, :step_days, :]
        strat_ret  = float(mc_portfolio_returns(strategy_w, fwd_sc).mean())
        bench_ret  = float(mc_portfolio_returns(bench_w,    fwd_sc).mean())

        records.append({
            "date":         str(signals.index[idx].date()),
            "regime":       regime,
            "cvar":         result["cvar"],
            "strategy_ret": strat_ret,
            "benchmark_ret":bench_ret,
            "top_asset":    max(result["weights_named"].items(),
                               key=lambda x: x[1])[0],
        })

        if (i+1) % 20 == 0:
            print(f"  {i+1}/{len(indices)} | "
                  f"strat={strat_ret*100:.1f}% "
                  f"bench={bench_ret*100:.1f}%")

    df = pd.DataFrame(records)
    df["strategy_cum"]  = (1 + df["strategy_ret"]).cumprod()
    df["benchmark_cum"] = (1 + df["benchmark_ret"]).cumprod()
    n  = len(df)
    ann = lambda x: ((x.iloc[-1]) ** (252/n/step_days) - 1) * 100

    print(f"\n{'='*60}")
    print(f"  BACKTEST RESULTS  [{profile['label']}]")
    print(f"{'='*60}")
    print(f"  Strategy  annualised return:  {ann(df['strategy_cum']):+.1f}%")
    print(f"  Benchmark annualised return:  {ann(df['benchmark_cum']):+.1f}%")
    print(f"  Outperformance:               "
          f"{ann(df['strategy_cum'])-ann(df['benchmark_cum']):+.1f}%")
    print(f"  Average CVaR:                 {df['cvar'].mean()*100:.1f}%")
    print(f"  Regime breakdown:")
    for r in ["calm","elevated","crisis"]:
        pct = (df["regime"] == r).mean() * 100
        print(f"    {r:10s}: {pct:.0f}% of days")
    print(f"\n  Most common top asset by regime:")
    for r in ["calm","elevated","crisis"]:
        sub = df[df["regime"] == r]
        if len(sub):
            top = sub["top_asset"].mode()[0]
            print(f"    {r:10s}: {top}")

    df.to_csv("backtest_results.csv", index=False)
    print(f"\n  Full results saved → backtest_results.csv")
    return df


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train",    action="store_true",
                        help="Train RL policy")
    parser.add_argument("--backtest", action="store_true",
                        help="Run walk-forward backtest")
    parser.add_argument("--risk",     choices=["low","medium","high"],
                        default="medium")
    parser.add_argument("--episodes", type=int, default=300)
    parser.add_argument("--scenarios",type=int, default=500)
    parser.add_argument("--rl_path",  default="rl_policy.pt")
    args = parser.parse_args()

    print_header()
    print("\nLoading market data...")
    signals   = load_all_signals()
    mc_engine = MonteCarloEngine(horizon=30, df_t=7)

    if args.train:
        signal_dim = signals.shape[1]
        state_dim  = signal_dim + N_ASSETS
        trainer    = StableRLTrainer(state_dim=state_dim, max_cvar=-0.10)
        trainer.train(signals, mc_engine,
                      n_episodes=args.episodes,
                      n_scenarios=min(args.scenarios, 200),
                      save_path=args.rl_path)
        print("\nTraining complete. Run without --train for recommendations.")
        return

    if args.backtest:
        run_backtest(signals, mc_engine, risk=args.risk,
                     n_scenarios=200)
        return

    # Default: recommendation
    print(f"\nGenerating {RISK_PROFILES[args.risk]['label']} recommendation...")
    result, metrics, snap, used_rl = run_recommendation(
        signals, mc_engine,
        risk=args.risk,
        n_scenarios=args.scenarios,
        rl_path=args.rl_path if os.path.exists(args.rl_path) else None,
    )
    print_result(result, metrics, snap, used_rl,
                 RISK_PROFILES[args.risk]["label"])


if __name__ == "__main__":
    main()
