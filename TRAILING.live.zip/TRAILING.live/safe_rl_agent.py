"""
safe_rl_agent.py
----------------
CVaR-Constrained Safe Reinforcement Learning agent with Action Repair
for portfolio optimization.

Architecture:
  - Actor network: proposes portfolio weights (the action)
  - Critic network: estimates expected return (value function)
  - Safety critic: estimates CVaR violation probability
  - Action Repair: projects unsafe actions to nearest safe action

Algorithm: Constrained Policy Optimization (CPO) variant
  - Maximize:   E[cumulative risk-adjusted return]
  - Subject to: CVaR(α, portfolio) >= max_cvar_loss

Why Safe RL?
  Standard RL discovers strategies that maximize reward — but can learn
  dangerously risky allocations if they occasionally yield high return.
  Safe RL adds a hard constraint: the agent is NEVER allowed to propose
  an allocation whose CVaR exceeds the limit, even during exploration.

Action Repair:
  When the RL agent proposes an unsafe action w_proposed, instead of
  rejecting it (which would stall learning), Action Repair finds
  w_safe = argmin ||w - w_proposed||² such that CVaR(w_safe) >= limit.
  The agent still learns from the repaired action via the gradient.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import gymnasium as gym
from gymnasium import spaces
from typing import Dict, Tuple, List
from collections import deque
import random

from cvar_engine import CVaREngine, ASSET_CLASSES, signals_to_returns


DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
N_ASSETS = len(ASSET_CLASSES)


# ---------------------------------------------------------------------------
# Portfolio environment (Gymnasium)
# ---------------------------------------------------------------------------
class PortfolioEnv(gym.Env):
    """
    Reinforcement learning environment for portfolio optimization.

    State:  current portfolio weights + stress Z-scores (signal state)
    Action: target portfolio weights (continuous, [0,1]^n_assets)
    Reward: risk-adjusted return (Sharpe-like) over the episode step
    Done:   after horizon days
    """

    metadata = {"render_modes": []}

    def __init__(self, signals_df, scenarios_fn,
                 horizon: int = 30,
                 max_cvar: float = -0.15,
                 alpha: float = 0.05,
                 n_scenarios: int = 200):
        super().__init__()

        self.signals_df   = signals_df
        self.scenarios_fn = scenarios_fn   # callable: state → scenarios
        self.horizon      = horizon
        self.max_cvar     = max_cvar
        self.n_scenarios  = n_scenarios
        self.cvar_engine  = CVaREngine(alpha=alpha)

        signal_dim = signals_df.shape[1]
        state_dim  = signal_dim + N_ASSETS  # signals + current weights

        self.observation_space = spaces.Box(
            low=-10, high=10,
            shape=(state_dim,), dtype=np.float32
        )
        self.action_space = spaces.Box(
            low=0.0, high=1.0,
            shape=(N_ASSETS,), dtype=np.float32
        )

        # Episode state
        self._current_weights = np.ones(N_ASSETS) / N_ASSETS
        self._step_idx        = 0
        self._signal_idx      = 0
        self._episode_returns = []

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        # Start from a random point in the signal history
        max_start = len(self.signals_df) - self.horizon - 1
        self._signal_idx     = np.random.randint(60, max(61, max_start))
        self._step_idx       = 0
        self._current_weights = np.ones(N_ASSETS) / N_ASSETS
        self._episode_returns = []
        return self._get_obs(), {}

    def _get_obs(self) -> np.ndarray:
        signal_row = self.signals_df.iloc[self._signal_idx].values
        return np.concatenate([signal_row, self._current_weights]).astype(np.float32)

    def step(self, action: np.ndarray) -> Tuple:
        # Normalise action to valid weights
        action = np.clip(action, 0, 1)
        if action.sum() < 1e-6:
            action = np.ones(N_ASSETS) / N_ASSETS
        else:
            action = action / action.sum()

        # Get current signal state
        current_state = self.signals_df.iloc[self._signal_idx].values

        # Generate scenarios from diffusion model (or mock during env test)
        scenarios = self.scenarios_fn(current_state, self.n_scenarios)

        # Compute asset returns for this step
        asset_rets = signals_to_returns(scenarios)
        daily_rets = (asset_rets[:, 0, :] * action).sum(axis=1)

        # Step reward: mean return adjusted by CVaR penalty
        mean_ret = float(daily_rets.mean())
        cvar_metrics = self.cvar_engine.compute(action, scenarios)
        cvar_val = cvar_metrics["cvar"]

        # Reward = return - penalty for CVaR violation
        cvar_penalty = max(0, self.max_cvar - cvar_val) * 5.0
        reward = mean_ret * 252 - cvar_penalty   # annualised

        self._current_weights = action
        self._signal_idx     += 1
        self._step_idx       += 1
        self._episode_returns.append(mean_ret)

        done = self._step_idx >= self.horizon
        truncated = False

        info = {
            "cvar":     cvar_val,
            "is_safe":  cvar_val >= self.max_cvar,
            "mean_ret": mean_ret,
            "weights":  action,
        }

        return self._get_obs(), reward, done, truncated, info


# ---------------------------------------------------------------------------
# Neural network components
# ---------------------------------------------------------------------------
class ActorNetwork(nn.Module):
    """
    Proposes portfolio weights given the current market state.
    Output: softmax over N_ASSETS → valid probability distribution (weights sum to 1)
    """
    def __init__(self, state_dim: int, hidden: int = 256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden),
            nn.LayerNorm(hidden),
            nn.SiLU(),
            nn.Linear(hidden, hidden),
            nn.LayerNorm(hidden),
            nn.SiLU(),
            nn.Linear(hidden, hidden // 2),
            nn.SiLU(),
            nn.Linear(hidden // 2, N_ASSETS),
        )
        # Log std for stochastic policy (exploration)
        self.log_std = nn.Parameter(torch.zeros(N_ASSETS) - 2)

    def forward(self, state: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        logits = self.net(state)
        mean   = F.softmax(logits, dim=-1)
        std    = self.log_std.exp().clamp(1e-4, 0.1)
        return mean, std

    def sample(self, state: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        mean, std = self.forward(state)
        dist = torch.distributions.Dirichlet(mean / std.mean() * 10 + 1e-3)
        action = dist.sample()
        log_prob = dist.log_prob(action)
        return action, log_prob


class CriticNetwork(nn.Module):
    """Value function: estimates expected cumulative return."""
    def __init__(self, state_dim: int, hidden: int = 256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden),
            nn.LayerNorm(hidden),
            nn.SiLU(),
            nn.Linear(hidden, hidden),
            nn.SiLU(),
            nn.Linear(hidden, 1),
        )

    def forward(self, state: torch.Tensor) -> torch.Tensor:
        return self.net(state).squeeze(-1)


class SafetyCriticNetwork(nn.Module):
    """
    Safety value function: estimates expected CVaR constraint violation.
    Trained to predict cumulative safety cost (how much CVaR is violated).
    """
    def __init__(self, state_dim: int, hidden: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden),
            nn.SiLU(),
            nn.Linear(hidden, hidden),
            nn.SiLU(),
            nn.Linear(hidden, 1),
        )

    def forward(self, state: torch.Tensor) -> torch.Tensor:
        return self.net(state).squeeze(-1)


# ---------------------------------------------------------------------------
# Action Repair
# ---------------------------------------------------------------------------
class ActionRepair:
    """
    Projects unsafe portfolio weights to the nearest safe weights.

    "Nearest" = minimum L2 distance while satisfying:
      1. weights sum to 1
      2. all weights >= 0
      3. CVaR(weights) >= max_cvar

    Uses projected gradient descent for efficiency.
    """

    def __init__(self, cvar_engine: CVaREngine,
                 max_cvar: float = -0.15,
                 lr: float = 0.05,
                 max_steps: int = 50):
        self.engine   = cvar_engine
        self.max_cvar = max_cvar
        self.lr       = lr
        self.max_steps = max_steps

    def repair(self, proposed_weights: np.ndarray,
               scenarios: np.ndarray) -> Tuple[np.ndarray, bool, int]:
        """
        Find nearest safe weights to proposed_weights.

        Args:
            proposed_weights: (n_assets,) — RL agent's raw output
            scenarios:        (n_scenarios, horizon, signal_dim)

        Returns:
            (safe_weights, was_repair_needed, n_steps_taken)
        """
        # Check if already safe
        metrics   = self.engine.compute(proposed_weights, scenarios)
        is_safe, _ = self.engine.check_constraint(metrics, self.max_cvar)
        if is_safe:
            return proposed_weights.copy(), False, 0

        # Projected gradient descent toward safe region
        w = proposed_weights.copy()

        for step in range(self.max_steps):
            # Compute CVaR gradient numerically
            grad = self._cvar_gradient(w, scenarios)

            # Step in direction that improves CVaR (makes it less negative)
            w = w + self.lr * grad

            # Project onto simplex (weights sum=1, all >= 0)
            w = self._project_simplex(w)

            # Check constraint
            m = self.engine.compute(w, scenarios)
            ok, _ = self.engine.check_constraint(m, self.max_cvar)
            if ok:
                return w, True, step + 1

        # Fallback: conservative defensive allocation
        w_safe = np.zeros(N_ASSETS)
        w_safe[4] = 0.35   # Indian bonds
        w_safe[5] = 0.35   # US bonds
        w_safe[7] = 0.20   # Cash
        w_safe[3] = 0.10   # Gold
        return w_safe, True, self.max_steps

    def _cvar_gradient(self, w: np.ndarray,
                       scenarios: np.ndarray,
                       eps: float = 0.005) -> np.ndarray:
        """Numerical gradient of CVaR with respect to weights."""
        grad = np.zeros_like(w)
        base_cvar = self.engine.compute(w, scenarios)["cvar"]

        for i in range(len(w)):
            w_plus = w.copy()
            w_plus[i] += eps
            # Renormalise
            if w_plus.sum() > 0:
                w_plus /= w_plus.sum()
            cvar_plus = self.engine.compute(w_plus, scenarios)["cvar"]
            grad[i] = (cvar_plus - base_cvar) / eps

        return grad

    @staticmethod
    def _project_simplex(w: np.ndarray) -> np.ndarray:
        """
        Project w onto the probability simplex:
        min ||w - v||² s.t. sum(v)=1, v>=0
        (Duchi et al., 2008 — O(n log n) algorithm)
        """
        n = len(w)
        u = np.sort(w)[::-1]
        cssv = np.cumsum(u)
        rho  = np.where(u > (cssv - 1) / (np.arange(n) + 1))[0][-1]
        lam  = (cssv[rho] - 1) / (rho + 1)
        return np.maximum(w - lam, 0)


# ---------------------------------------------------------------------------
# Replay buffer
# ---------------------------------------------------------------------------
class ReplayBuffer:
    def __init__(self, capacity: int = 50_000):
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state,
             done, safety_cost):
        self.buffer.append((state, action, reward,
                            next_state, done, safety_cost))

    def sample(self, batch_size: int) -> Dict:
        batch = random.sample(self.buffer, batch_size)
        s, a, r, ns, d, sc = zip(*batch)
        return {
            "states":       torch.FloatTensor(np.array(s)).to(DEVICE),
            "actions":      torch.FloatTensor(np.array(a)).to(DEVICE),
            "rewards":      torch.FloatTensor(np.array(r)).to(DEVICE),
            "next_states":  torch.FloatTensor(np.array(ns)).to(DEVICE),
            "dones":        torch.FloatTensor(np.array(d)).to(DEVICE),
            "safety_costs": torch.FloatTensor(np.array(sc)).to(DEVICE),
        }

    def __len__(self):
        return len(self.buffer)


# ---------------------------------------------------------------------------
# Safe RL Agent (CVaR-Constrained PPO variant)
# ---------------------------------------------------------------------------
class SafeRLAgent:
    """
    CVaR-Constrained Safe RL agent with Action Repair.

    Training loop:
      1. Actor proposes action (portfolio weights)
      2. Action Repair makes it CVaR-safe
      3. Environment returns reward + safety cost
      4. Critic updates value estimate
      5. Safety critic updates constraint estimate
      6. Actor updates policy via PPO with safety penalty

    The safety constraint is enforced at both inference time (Action Repair)
    and training time (safety penalty in the actor loss).
    """

    def __init__(self, state_dim: int,
                 max_cvar: float = -0.15,
                 alpha: float = 0.05,
                 lr_actor: float = 3e-4,
                 lr_critic: float = 1e-3,
                 gamma: float = 0.99,
                 safety_penalty: float = 10.0,
                 clip_eps: float = 0.2):

        self.max_cvar      = max_cvar
        self.gamma         = gamma
        self.safety_penalty = safety_penalty
        self.clip_eps      = clip_eps
        self.cvar_engine   = CVaREngine(alpha=alpha)
        self.action_repair = ActionRepair(self.cvar_engine, max_cvar)

        # Networks
        self.actor         = ActorNetwork(state_dim).to(DEVICE)
        self.critic        = CriticNetwork(state_dim).to(DEVICE)
        self.safety_critic = SafetyCriticNetwork(state_dim).to(DEVICE)

        # Old actor for PPO ratio
        self.actor_old     = ActorNetwork(state_dim).to(DEVICE)
        self.actor_old.load_state_dict(self.actor.state_dict())

        # Optimizers
        self.opt_actor    = torch.optim.Adam(self.actor.parameters(), lr=lr_actor)
        self.opt_critic   = torch.optim.Adam(self.critic.parameters(), lr=lr_critic)
        self.opt_safety   = torch.optim.Adam(
            self.safety_critic.parameters(), lr=lr_critic
        )

        self.buffer = ReplayBuffer()
        self.training_stats = []

    @torch.no_grad()
    def select_action(self, state: np.ndarray,
                      scenarios: np.ndarray,
                      deterministic: bool = False) -> Tuple[np.ndarray, Dict]:
        """
        Select a CVaR-safe portfolio allocation.

        Args:
            state:         current market state (signal_dim + n_assets,)
            scenarios:     (n_sc, horizon, signal_dim) diffusion scenarios
            deterministic: if True, use mean action (no exploration)

        Returns:
            (safe_weights, info_dict)
        """
        s_t = torch.FloatTensor(state).unsqueeze(0).to(DEVICE)

        if deterministic:
            mean, _ = self.actor(s_t)
            raw_action = mean.squeeze(0).cpu().numpy()
        else:
            raw_action, _ = self.actor.sample(s_t)
            raw_action = raw_action.squeeze(0).cpu().numpy()

        # Normalise
        raw_action = np.clip(raw_action, 0, 1)
        raw_action = raw_action / (raw_action.sum() + 1e-8)

        # CVaR check + repair
        safe_action, repaired, n_steps = self.action_repair.repair(
            raw_action, scenarios
        )

        # Compute final metrics
        metrics = self.cvar_engine.compute(safe_action, scenarios)
        is_safe, safety_msg = self.cvar_engine.check_constraint(
            metrics, self.max_cvar
        )

        info = {
            "raw_weights":    raw_action,
            "safe_weights":   safe_action,
            "repaired":       repaired,
            "repair_steps":   n_steps,
            "cvar":           metrics["cvar"],
            "expected_ret":   metrics["expected_ret"],
            "sharpe":         metrics["sharpe"],
            "is_safe":        is_safe,
            "safety_message": safety_msg,
            "weights_named":  dict(zip(ASSET_CLASSES, safe_action)),
        }

        return safe_action, info

    def store_transition(self, state, action, reward,
                         next_state, done, safety_cost):
        self.buffer.push(state, action, reward,
                         next_state, done, safety_cost)

    def update(self, batch_size: int = 64) -> Dict:
        """Update all networks using sampled batch."""
        if len(self.buffer) < batch_size:
            return {}

        batch = self.buffer.sample(batch_size)
        s  = batch["states"]
        a  = batch["actions"]
        r  = batch["rewards"]
        ns = batch["next_states"]
        d  = batch["dones"]
        sc = batch["safety_costs"]

        # --- Critic update (TD learning) ---
        with torch.no_grad():
            next_v  = self.critic(ns)
            target_v = r + self.gamma * next_v * (1 - d)
        v = self.critic(s)
        critic_loss = F.mse_loss(v, target_v)

        self.opt_critic.zero_grad()
        critic_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 0.5)
        self.opt_critic.step()

        # --- Safety critic update ---
        with torch.no_grad():
            next_sv  = self.safety_critic(ns)
            target_sv = sc + self.gamma * next_sv * (1 - d)
        sv = self.safety_critic(s)
        safety_critic_loss = F.mse_loss(sv, target_sv)

        self.opt_safety.zero_grad()
        safety_critic_loss.backward()
        self.opt_safety.step()

        # --- Actor update (PPO with safety penalty) ---
        with torch.no_grad():
            advantages     = (r + self.gamma * self.critic(ns) * (1 - d) - v).detach()
            safety_values  = self.safety_critic(s).detach()
            advantages     = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        # PPO clipped ratio
        mean_new, std_new = self.actor(s)
        mean_old, std_old = self.actor_old(s)

        # Approximate log prob ratio via mean distance
        ratio = torch.exp(
            -0.5 * ((a - mean_new) / (std_new + 1e-8)).pow(2).sum(-1)
            + 0.5 * ((a - mean_old) / (std_old + 1e-8)).pow(2).sum(-1)
        ).clamp(0.01, 3.0)

        surr1 = ratio * advantages
        surr2 = torch.clamp(ratio, 1 - self.clip_eps,
                            1 + self.clip_eps) * advantages
        policy_loss = -torch.min(surr1, surr2).mean()

        # Safety penalty: penalize actions that lead to CVaR violations
        safety_loss = self.safety_penalty * F.relu(safety_values).mean()

        # Entropy bonus (encourage exploration)
        entropy = -(mean_new * (mean_new + 1e-8).log()).sum(-1).mean()
        entropy_bonus = -0.01 * entropy

        actor_loss = policy_loss + safety_loss + entropy_bonus

        self.opt_actor.zero_grad()
        actor_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 0.5)
        self.opt_actor.step()

        # Sync old actor
        self.actor_old.load_state_dict(self.actor.state_dict())

        stats = {
            "actor_loss":        float(actor_loss),
            "critic_loss":       float(critic_loss),
            "safety_critic_loss": float(safety_critic_loss),
            "policy_loss":       float(policy_loss),
            "safety_loss":       float(safety_loss),
        }
        self.training_stats.append(stats)
        return stats

    def explain_action(self, info: Dict) -> str:
        """Generate plain-language explanation for the user."""
        lines = []
        w = info["weights_named"]

        # Top 3 holdings
        top3 = sorted(w.items(), key=lambda x: -x[1])[:3]

        lines.append("PORTFOLIO RECOMMENDATION")
        lines.append("=" * 40)
        lines.append("\nTop allocations:")
        for asset, weight in top3:
            lines.append(f"  {asset:20s}: {weight*100:.1f}%")

        lines.append(f"\nRisk metrics (30-day outlook):")
        lines.append(f"  CVaR (worst 5% avg loss):  {info['cvar']*100:.1f}%")
        lines.append(f"  Expected return:            {info['expected_ret']*100:.1f}%")
        lines.append(f"  Sharpe ratio:               {info['sharpe']:.2f}")

        if info["repaired"]:
            lines.append(
                f"\n⚡ Action repair applied ({info['repair_steps']} steps) — "
                f"original allocation exceeded CVaR limit. "
                f"Nearest safe allocation used instead."
            )
        lines.append(f"\nSafety: {info['safety_message']}")

        return "\n".join(lines)

    def save(self, path: str = "safe_rl_agent.pt"):
        torch.save({
            "actor":          self.actor.state_dict(),
            "critic":         self.critic.state_dict(),
            "safety_critic":  self.safety_critic.state_dict(),
            "training_stats": self.training_stats,
        }, path)
        print(f"Agent saved → {path}")

    @classmethod
    def load(cls, path: str, state_dim: int,
             max_cvar: float = -0.15) -> "SafeRLAgent":
        agent = cls(state_dim=state_dim, max_cvar=max_cvar)
        ckpt  = torch.load(path, map_location=DEVICE, weights_only=False)
        agent.actor.load_state_dict(ckpt["actor"])
        agent.critic.load_state_dict(ckpt["critic"])
        agent.safety_critic.load_state_dict(ckpt["safety_critic"])
        agent.training_stats = ckpt.get("training_stats", [])
        print(f"Agent loaded from {path}")
        return agent


# ---------------------------------------------------------------------------
# Training loop
# ---------------------------------------------------------------------------
def train_agent(signals_df, diffusion_model,
                n_episodes: int = 100,
                max_cvar: float = -0.15,
                n_scenarios: int = 200,
                save_path: str = "safe_rl_agent.pt") -> SafeRLAgent:
    """
    Full training loop for the safe RL agent.

    Args:
        signals_df:      historical signal DataFrame
        diffusion_model: trained FinancialDiffusionModel
        n_episodes:      training episodes
        max_cvar:        CVaR safety constraint
        n_scenarios:     scenarios per step (higher = more accurate)
        save_path:       where to save the trained agent
    """

    def scenarios_fn(state, n):
        return diffusion_model.generate_scenarios(state, n)

    signal_dim = signals_df.shape[1]
    state_dim  = signal_dim + N_ASSETS

    env   = PortfolioEnv(signals_df, scenarios_fn,
                         max_cvar=max_cvar, n_scenarios=n_scenarios)
    agent = SafeRLAgent(state_dim=state_dim, max_cvar=max_cvar)

    print(f"\nTraining Safe RL Agent on {DEVICE}")
    print(f"  Episodes:     {n_episodes}")
    print(f"  CVaR limit:   {max_cvar*100:.0f}%")
    print(f"  Scenarios/step: {n_scenarios}")

    episode_rewards = []
    safety_violations = []

    for ep in range(1, n_episodes + 1):
        state, _ = env.reset()
        ep_reward = 0
        ep_violations = 0

        for step in range(env.horizon):
            current_state = signals_df.iloc[env._signal_idx].values
            scenarios = diffusion_model.generate_scenarios(
                current_state, n_scenarios
            )

            action, info = agent.select_action(state, scenarios)

            next_state, reward, done, _, step_info = env.step(action)

            # Safety cost: how much CVaR constraint is violated
            safety_cost = max(0, max_cvar - step_info["cvar"])

            agent.store_transition(
                state, action, reward, next_state, done, safety_cost
            )

            if len(agent.buffer) >= 128:
                agent.update(batch_size=64)

            state = next_state
            ep_reward += reward
            if not step_info["is_safe"]:
                ep_violations += 1

            if done:
                break

        episode_rewards.append(ep_reward)
        safety_violations.append(ep_violations)

        if ep % 10 == 0:
            avg_r  = np.mean(episode_rewards[-10:])
            avg_sv = np.mean(safety_violations[-10:])
            print(f"  Episode {ep:3d}/{n_episodes} | "
                  f"avg reward: {avg_r:.3f} | "
                  f"safety violations/ep: {avg_sv:.1f}")

    agent.save(save_path)
    return agent


# ---------------------------------------------------------------------------
# Standalone test (without diffusion model — uses mock scenarios)
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys
    sys.path.insert(0, "/home/claude/crisis_detector")
    from data_loader import load_all_signals

    print("Safe RL Agent — standalone test (mock scenarios)")
    print("=" * 50)

    signals = load_all_signals()
    signal_dim = signals.shape[1]
    state_dim  = signal_dim + N_ASSETS

    rng = np.random.default_rng(0)

    def mock_scenarios(state, n):
        """Mock diffusion model for testing purposes."""
        base = rng.normal(0, 1, (n, 30, signal_dim)).astype(np.float32)
        # Anchor to current state
        base[:, 0, :] = state
        return base

    agent = SafeRLAgent(state_dim=state_dim, max_cvar=-0.15)

    # Test action selection
    dummy_state = np.concatenate([
        signals.iloc[-1].values,
        np.ones(N_ASSETS) / N_ASSETS
    ]).astype(np.float32)

    dummy_scenarios = mock_scenarios(signals.iloc[-1].values, 200)

    print("\nTesting action selection...")
    action, info = agent.select_action(dummy_state, dummy_scenarios,
                                       deterministic=True)
    print(agent.explain_action(info))

    # Test CVaR engine
    print("\n" + "=" * 50)
    engine = CVaREngine(alpha=0.05)
    metrics = engine.compute(action, dummy_scenarios)
    print(engine.explain_risk(action, dummy_scenarios, metrics))

    # Quick training test
    print("\n" + "=" * 50)
    print("Testing 5-episode training loop...")

    def scenarios_fn(state, n):
        return mock_scenarios(state, n)

    env = PortfolioEnv(signals, scenarios_fn,
                       max_cvar=-0.15, n_scenarios=50)

    for ep in range(5):
        state, _ = env.reset()
        ep_reward = 0
        for step in range(10):
            current_state = signals.iloc[env._signal_idx].values
            scenarios = mock_scenarios(current_state, 50)
            action, info = agent.select_action(state, scenarios)
            next_state, reward, done, _, _ = env.step(action)
            agent.store_transition(state, action, reward, next_state, done, 0)
            if len(agent.buffer) >= 64:
                agent.update(32)
            state = next_state
            ep_reward += reward
            if done:
                break
        print(f"  Episode {ep+1}: reward={ep_reward:.4f}")

    print("\nSafe RL agent test passed.")
