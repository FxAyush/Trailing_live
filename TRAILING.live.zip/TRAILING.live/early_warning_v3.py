"""
early_warning_v3.py
-------------------
TRAILING.live early-warning model trained on REAL future market outcomes.

Main changes from v1:
- Target is no longer "future stress score >= 70".
- US target uses S&P 500 (^GSPC).
- India target uses NIFTY 50 (^NSEI).
- A crash label is 1 when, over the next 15 trading sessions:
    * close-to-close forward return <= -5%, OR
    * forward maximum drawdown <= -7%.
- Last HORIZON observations have unknown labels and are excluded from training.
- LSTM outputs logits directly and uses BCEWithLogitsLoss correctly.
- LSTM sequences include today's feature row.
- Time-series CV checks both classes before fitting/scoring.
- Model persistence stores PyTorch state_dict rather than pickling the whole
  torch module, avoiding the old __main__.LSTMNet pickle problem.
- Separate model files are supported for US and India.

Important:
This is a research/forward-testing model, not a guarantee of future performance.
"""

import os
import sys
import pickle
import warnings
from typing import Dict, Tuple, Optional

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import torch
import torch.nn as nn
import torch.nn.functional as F

from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    brier_score_loss,
)
from sklearn.model_selection import TimeSeriesSplit

from data_loader import load_all_signals
from signal_processor import run_full_pipeline
from geopolitical_risk import (
    augment_signals_with_geopolitical,
    get_geopolitical_snapshot,
)


DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

HORIZON = 15
RETURN_CRASH_THRESHOLD = -0.05
DRAWDOWN_CRASH_THRESHOLD = -0.07

MARKET_TICKERS = {
    "us": "^GSPC",
    "india": "^NSEI",
}

SAVE_PATH_US = "early_warning_model_us_v3.pkl"
SAVE_PATH_INDIA = "early_warning_model_india_v3.pkl"

# Kept only for backward import compatibility.
# Do not use this shared file for both markets.
SAVE_PATH = SAVE_PATH_US

MODEL_VERSION = 3


def get_save_path(market: str) -> str:
    market = market.lower()
    if market == "us":
        return SAVE_PATH_US
    if market == "india":
        return SAVE_PATH_INDIA
    raise ValueError("market must be 'us' or 'india'")


# ---------------------------------------------------------------------------
# Price data / REAL outcome labels
# ---------------------------------------------------------------------------

def fetch_benchmark_close(
    market: str,
    start: str,
    end: Optional[str] = None,
) -> pd.Series:
    """Download benchmark close prices used ONLY to construct training labels."""
    market = market.lower()
    if market not in MARKET_TICKERS:
        raise ValueError("market must be 'us' or 'india'")

    import yfinance as yf

    ticker = MARKET_TICKERS[market]
    df = yf.download(
        ticker,
        start=start,
        end=end,
        auto_adjust=True,
        progress=False,
        actions=False,
        threads=False,
    )

    if df is None or len(df) == 0:
        raise RuntimeError(f"Could not download benchmark data for {ticker}")

    close = df["Close"]
    if isinstance(close, pd.DataFrame):
        close = close.iloc[:, 0]

    close = pd.to_numeric(close, errors="coerce").dropna()
    close.index = pd.DatetimeIndex(close.index).tz_localize(None)
    close.name = "benchmark_close"
    return close.sort_index()


def build_market_crash_labels(
    feature_index: pd.DatetimeIndex,
    benchmark_close: pd.Series,
    horizon: int = HORIZON,
    return_threshold: float = RETURN_CRASH_THRESHOLD,
    drawdown_threshold: float = DRAWDOWN_CRASH_THRESHOLD,
) -> pd.DataFrame:
    """
    Build REAL forward market-outcome labels.

    At date t:
      label = 1 if over the next `horizon` benchmark trading sessions:
        (future close / today's close - 1) <= return_threshold
        OR
        minimum future close / running peak - 1 <= drawdown_threshold

    The final horizon observations remain NaN because the outcome is not known.
    """
    idx = pd.DatetimeIndex(feature_index)

    # Reindex benchmark to feature dates using only prior/known closes.
    close_on_features = benchmark_close.reindex(idx, method="ffill")

    label = pd.Series(np.nan, index=idx, name="label", dtype=float)
    fwd_return = pd.Series(np.nan, index=idx, name="forward_return", dtype=float)
    fwd_mdd = pd.Series(np.nan, index=idx, name="forward_max_drawdown", dtype=float)

    bench = benchmark_close.dropna()

    for i, dt in enumerate(idx):
        if pd.isna(close_on_features.iloc[i]):
            continue

        # Sessions strictly AFTER the prediction date.
        future = bench.loc[bench.index > dt].iloc[:horizon]
        if len(future) < horizon:
            continue

        start_price = float(close_on_features.iloc[i])
        final_ret = float(future.iloc[-1] / start_price - 1.0)

        # Drawdown path includes today's starting price as the initial peak/reference.
        path = pd.concat([
            pd.Series([start_price], index=[dt]),
            future.astype(float),
        ])
        running_peak = path.cummax()
        dd = path / running_peak - 1.0
        max_dd = float(dd.min())

        crash = (final_ret <= return_threshold) or (max_dd <= drawdown_threshold)

        label.iloc[i] = int(crash)
        fwd_return.iloc[i] = final_ret
        fwd_mdd.iloc[i] = max_dd

    return pd.concat([label, fwd_return, fwd_mdd], axis=1)


# ---------------------------------------------------------------------------
# Causal feature engineering
# ---------------------------------------------------------------------------

def _rolling_last_percentile(
    s: pd.Series,
    window: int = 252,
    min_periods: int = 60,
) -> pd.Series:
    def rank_last(x):
        x = np.asarray(x, dtype=float)
        x = x[np.isfinite(x)]
        if len(x) == 0:
            return np.nan
        last = x[-1]
        less = np.sum(x < last)
        equal = np.sum(x == last)
        return (less + 0.5 * equal) / len(x)

    return s.rolling(window, min_periods=min_periods).apply(rank_last, raw=True)


def build_features(signals: pd.DataFrame, score: pd.Series) -> pd.DataFrame:
    """
    Build causal market + geopolitical features using information available at or before each timestamp.
    No forward shifts and no future benchmark prices are used here.
    """
    signals = signals.sort_index().copy()
    score = score.reindex(signals.index)

    f = pd.DataFrame(index=signals.index)

    # Raw signals
    for col in signals.columns:
        f[col] = pd.to_numeric(signals[col], errors="coerce")

    # Rolling transformations
    for col in signals.columns:
        s = pd.to_numeric(signals[col], errors="coerce")
        for w in (5, 10, 20):
            f[f"{col}_mean{w}"] = s.rolling(w, min_periods=w).mean()
            f[f"{col}_std{w}"] = s.rolling(w, min_periods=w).std()
            f[f"{col}_roc{w}"] = s.diff(w)

    # Causal stress features
    f["stress"] = score
    f["stress_roc5"] = score.diff(5)
    f["stress_roc10"] = score.diff(10)
    f["stress_accel"] = score.diff().diff()
    f["stress_ma10"] = score.rolling(10, min_periods=10).mean()
    f["stress_rank"] = _rolling_last_percentile(score, 252, 60)

    rising = score.diff() > 0
    count = 0
    vals = []
    for is_rising in rising.fillna(False):
        count = count + 1 if bool(is_rising) else 0
        vals.append(float(count))
    f["days_rising"] = vals

    # Interactions
    if {"credit_spread", "yield_curve_spread"}.issubset(signals.columns):
        f["credit_x_yield"] = (
            signals["credit_spread"] *
            signals["yield_curve_spread"].abs()
        )

    if {"vix", "fii_flows"}.issubset(signals.columns):
        f["vix_x_fii"] = (
            signals["vix"] *
            (-signals["fii_flows"].clip(upper=0))
        )

    if {"ted_spread", "market_breadth"}.issubset(signals.columns):
        f["ted_x_breadth"] = (
            signals["ted_spread"] *
            (100 - signals["market_breadth"].clip(0, 100))
        )

    return f.replace([np.inf, -np.inf], np.nan)


# ---------------------------------------------------------------------------
# LSTM
# ---------------------------------------------------------------------------

class LSTMNet(nn.Module):
    """
    Compact LSTM to reduce memorization risk.
    """
    def __init__(self, input_dim: int, hidden: int = 32, layers: int = 1):
        super().__init__()

        self.lstm = nn.LSTM(
            input_dim,
            hidden,
            layers,
            batch_first=True,
            dropout=0.0,
        )
        self.attn = nn.Linear(hidden, 1)
        self.head = nn.Sequential(
            nn.Linear(hidden, 16),
            nn.ReLU(),
            nn.Dropout(0.15),
            nn.Linear(16, 1),
        )

    def forward(self, x):
        out, _ = self.lstm(x)
        weights = F.softmax(self.attn(out), dim=1)
        context = (weights * out).sum(dim=1)
        return self.head(context).squeeze(-1)  # LOGITS


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------

class EarlyWarningModel:

    def __init__(self, market: str = "us"):
        market = market.lower()
        if market not in MARKET_TICKERS:
            raise ValueError("market must be 'us' or 'india'")

        self.market = market
        self.ticker = MARKET_TICKERS[market]

        self.gbt = None
        self.lstm_net = None
        self.scaler = StandardScaler()
        self.lstm_scaler = StandardScaler()

        self.feat_cols = None
        self.trained = False
        self.seq_len = 20
        self.input_dim = None

        self.return_threshold = RETURN_CRASH_THRESHOLD
        self.drawdown_threshold = DRAWDOWN_CRASH_THRESHOLD
        self.horizon = HORIZON
        self.geo_metadata = {}
        self.lstm_training_stats = {}

    def _prepare_training_data(
        self,
        signals: pd.DataFrame,
        score: pd.Series,
        benchmark_close: Optional[pd.Series] = None,
    ):
        signals_aug, geo_meta = augment_signals_with_geopolitical(
            signals,
            use_cache=True,
        )
        feat = build_features(signals_aug, score)
        self.geo_metadata = geo_meta

        if benchmark_close is None:
            start = (feat.index.min() - pd.Timedelta(days=10)).strftime("%Y-%m-%d")
            end = (feat.index.max() + pd.Timedelta(days=60)).strftime("%Y-%m-%d")
            benchmark_close = fetch_benchmark_close(self.market, start, end)

        outcomes = build_market_crash_labels(
            feat.index,
            benchmark_close,
            horizon=self.horizon,
            return_threshold=self.return_threshold,
            drawdown_threshold=self.drawdown_threshold,
        )

        data = pd.concat([feat, outcomes], axis=1)

        # Do NOT fill warm-up NaNs with zero for training.
        # Drop rows whose features or future outcomes are not genuinely available.
        data = data.dropna(subset=list(feat.columns) + ["label"])

        X = data[feat.columns].values.astype(np.float32)
        y = data["label"].astype(int).values

        return feat, outcomes, data, X, y

    def train(
        self,
        signals: pd.DataFrame,
        score: pd.Series,
        lstm_epochs: int = 60,
        benchmark_close: Optional[pd.Series] = None,
    ) -> Dict:
        print(f"Building REAL {self.market.upper()} market-crash labels...")

        feat, outcomes, data, X, y = self._prepare_training_data(
            signals, score, benchmark_close
        )

        if len(X) < 500:
            raise RuntimeError(f"Too few valid training rows: {len(X)}")

        if len(np.unique(y)) < 2:
            raise RuntimeError("Training labels contain only one class.")

        self.feat_cols = list(feat.columns)
        self.input_dim = X.shape[1]

        positive = int(y.sum())
        print(
            f"  Samples: {len(X)} | Real crash labels: {positive} "
            f"({y.mean()*100:.2f}%)"
        )
        print(
            f"  Definition: next {self.horizon} sessions return <= "
            f"{self.return_threshold*100:.1f}% OR max drawdown <= "
            f"{self.drawdown_threshold*100:.1f}%"
        )

        # ---------------------------------------------------------------
        # Time-series CV for GBT
        # ---------------------------------------------------------------
        tscv = TimeSeriesSplit(n_splits=5)
        aucs, aps, briers = [], [], []

        print("Time-series CV...")
        for fold, (tr, va) in enumerate(tscv.split(X), start=1):
            ytr, yva = y[tr], y[va]

            if len(np.unique(ytr)) < 2 or len(np.unique(yva)) < 2:
                print(f"  Fold {fold}: skipped (single-class train/validation)")
                continue

            sc = StandardScaler()
            Xtr = sc.fit_transform(X[tr])
            Xva = sc.transform(X[va])

            g = GradientBoostingClassifier(
                n_estimators=200,
                max_depth=3,
                learning_rate=0.04,
                subsample=0.8,
                min_samples_leaf=20,
                random_state=42,
            )
            g.fit(Xtr, ytr)
            p = g.predict_proba(Xva)[:, 1]

            auc = roc_auc_score(yva, p)
            ap = average_precision_score(yva, p)
            br = brier_score_loss(yva, p)

            aucs.append(auc)
            aps.append(ap)
            briers.append(br)

            print(
                f"  Fold {fold}: AUC={auc:.3f} | AP={ap:.3f} | "
                f"Brier={br:.3f} | positives={int(yva.sum())}/{len(yva)}"
            )

        if not aucs:
            raise RuntimeError("No valid time-series CV folds contained both classes.")

        print(
            f"  CV mean: AUC={np.mean(aucs):.3f} | "
            f"AP={np.mean(aps):.3f} | Brier={np.mean(briers):.3f}"
        )

        # ---------------------------------------------------------------
        # Final GBT
        # ---------------------------------------------------------------
        print("Training final GBT...")
        Xsc = self.scaler.fit_transform(X)

        self.gbt = GradientBoostingClassifier(
            n_estimators=300,
            max_depth=3,
            learning_rate=0.03,
            subsample=0.8,
            min_samples_leaf=20,
            random_state=42,
        )
        self.gbt.fit(Xsc, y)
        print("  GBT done ✓")

        # ---------------------------------------------------------------
        # LSTM
        # ---------------------------------------------------------------
        print(f"Training LSTM on {DEVICE} ({lstm_epochs} epochs)...")
        self._train_lstm(X, y, lstm_epochs)
        print("  LSTM done ✓")

        self.trained = True

        train_prob = self._ensemble_proba(X)
        train_auc = roc_auc_score(y, train_prob)
        train_brier = brier_score_loss(y, train_prob)

        print(
            f"  Ensemble train AUC: {train_auc:.3f} "
            f"(diagnostic only; CV/forward results matter more)"
        )

        return {
            "market": self.market,
            "ticker": self.ticker,
            "samples": int(len(X)),
            "positive_labels": positive,
            "positive_rate": round(float(y.mean()), 4),
            "cv_auc": round(float(np.mean(aucs)), 3),
            "cv_average_precision": round(float(np.mean(aps)), 3),
            "cv_brier": round(float(np.mean(briers)), 3),
            "train_auc": round(float(train_auc), 3),
            "train_brier": round(float(train_brier), 3),
            "lstm_selected_epoch": self.lstm_training_stats.get("selected_epoch"),
            "lstm_validation_auc": self.lstm_training_stats.get("validation_auc"),
            "lstm_validation_ap": self.lstm_training_stats.get("validation_ap"),
            "lstm_validation_brier": self.lstm_training_stats.get("validation_brier"),
        }

    def _train_lstm(
        self,
        X,
        y,
        epochs: int,
        validation_fraction: float = 0.15,
        patience: int = 8,
        min_delta: float = 1e-4,
    ):
        """
        Chronological early stopping.

        First, select the epoch count using the newest 15% of observations as
        validation. Then refit a fresh compact LSTM on all training rows for
        exactly that many epochs. No crash thresholds or ensemble weights are
        tuned here.
        """
        n = len(X)
        split = int(n * (1.0 - validation_fraction))
        split = max(self.seq_len + 50, min(split, n - 50))

        if split <= self.seq_len or n - split < 20:
            raise RuntimeError("Not enough rows for chronological LSTM validation.")

        select_scaler = StandardScaler()
        select_scaler.fit(X[:split])
        Xsc_all = select_scaler.transform(X)

        train_seqs, train_labs = [], []
        val_seqs, val_labs = [], []

        for i in range(self.seq_len - 1, n):
            seq = Xsc_all[i - self.seq_len + 1:i + 1]
            if i < split:
                train_seqs.append(seq)
                train_labs.append(y[i])
            else:
                val_seqs.append(seq)
                val_labs.append(y[i])

        Xtr = torch.tensor(np.asarray(train_seqs), dtype=torch.float32)
        ytr = torch.tensor(np.asarray(train_labs), dtype=torch.float32)
        Xva = torch.tensor(np.asarray(val_seqs), dtype=torch.float32)
        yva = torch.tensor(np.asarray(val_labs), dtype=torch.float32)

        positives = float((ytr == 1).sum())
        negatives = float((ytr == 0).sum())
        if positives == 0:
            raise RuntimeError("No positive LSTM labels in fit portion.")

        pos_weight = torch.tensor(
            [negatives / positives],
            dtype=torch.float32,
            device=DEVICE,
        )

        candidate = LSTMNet(self.input_dim).to(DEVICE)
        optimizer = torch.optim.Adam(
            candidate.parameters(),
            lr=7e-4,
            weight_decay=5e-4,
        )
        criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)

        loader = torch.utils.data.DataLoader(
            torch.utils.data.TensorDataset(Xtr, ytr),
            batch_size=64,
            shuffle=True,
        )

        best_state = None
        best_epoch = 1
        best_val_loss = float("inf")
        stale = 0

        print(
            f"    chronological split: fit={len(train_labs)} seqs | "
            f"validation={len(val_labs)} seqs"
        )

        for epoch in range(1, epochs + 1):
            candidate.train()
            train_loss = 0.0

            for xb, yb in loader:
                xb = xb.to(DEVICE)
                yb = yb.to(DEVICE)

                logits = candidate(xb)
                loss = criterion(logits, yb)

                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(candidate.parameters(), 1.0)
                optimizer.step()

                train_loss += float(loss.detach().cpu())

            candidate.eval()
            with torch.no_grad():
                val_logits = candidate(Xva.to(DEVICE))
                val_loss = float(
                    criterion(val_logits, yva.to(DEVICE)).detach().cpu()
                )

            avg_train = train_loss / max(1, len(loader))

            if epoch == 1 or epoch % 5 == 0:
                print(
                    f"    epoch {epoch:3d}/{epochs} "
                    f"train={avg_train:.4f} val={val_loss:.4f}"
                )

            if val_loss < best_val_loss - min_delta:
                best_val_loss = val_loss
                best_epoch = epoch
                best_state = {
                    k: v.detach().cpu().clone()
                    for k, v in candidate.state_dict().items()
                }
                stale = 0
            else:
                stale += 1

            if stale >= patience:
                print(
                    f"    early stopping at epoch {epoch}; "
                    f"best epoch={best_epoch}, val_loss={best_val_loss:.4f}"
                )
                break

        if best_state is None:
            best_state = {
                k: v.detach().cpu().clone()
                for k, v in candidate.state_dict().items()
            }

        candidate.load_state_dict(best_state)
        candidate.eval()
        with torch.no_grad():
            va_prob = torch.sigmoid(candidate(Xva.to(DEVICE))).cpu().numpy()

        yva_np = np.asarray(val_labs, dtype=int)
        val_auc = (
            roc_auc_score(yva_np, va_prob)
            if len(np.unique(yva_np)) == 2
            else np.nan
        )
        val_ap = (
            average_precision_score(yva_np, va_prob)
            if yva_np.sum() > 0
            else np.nan
        )
        val_brier = brier_score_loss(yva_np, va_prob)

        print(
            f"    selected epoch={best_epoch} | "
            f"chronological val AUC={val_auc:.3f} | "
            f"AP={val_ap:.3f} | Brier={val_brier:.3f}"
        )

        # Final refit on every training row, using the selected epoch count.
        self.lstm_scaler = StandardScaler()
        Xsc = self.lstm_scaler.fit_transform(X)

        seqs, labs = [], []
        for i in range(self.seq_len - 1, n):
            seqs.append(Xsc[i - self.seq_len + 1:i + 1])
            labs.append(y[i])

        Xt = torch.tensor(np.asarray(seqs), dtype=torch.float32)
        yt = torch.tensor(np.asarray(labs), dtype=torch.float32)

        positives = float((yt == 1).sum())
        negatives = float((yt == 0).sum())

        pos_weight_all = torch.tensor(
            [negatives / positives],
            dtype=torch.float32,
            device=DEVICE,
        )

        self.lstm_net = LSTMNet(self.input_dim).to(DEVICE)
        optimizer = torch.optim.Adam(
            self.lstm_net.parameters(),
            lr=7e-4,
            weight_decay=5e-4,
        )
        criterion_all = nn.BCEWithLogitsLoss(pos_weight=pos_weight_all)

        loader_all = torch.utils.data.DataLoader(
            torch.utils.data.TensorDataset(Xt, yt),
            batch_size=64,
            shuffle=True,
        )

        for epoch in range(1, best_epoch + 1):
            self.lstm_net.train()
            epoch_loss = 0.0

            for xb, yb in loader_all:
                xb = xb.to(DEVICE)
                yb = yb.to(DEVICE)

                logits = self.lstm_net(xb)
                loss = criterion_all(logits, yb)

                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.lstm_net.parameters(), 1.0)
                optimizer.step()

                epoch_loss += float(loss.detach().cpu())

            if epoch == 1 or epoch == best_epoch or epoch % 5 == 0:
                print(
                    f"    refit epoch {epoch:3d}/{best_epoch} "
                    f"loss={epoch_loss/max(1, len(loader_all)):.4f}"
                )

        self.lstm_training_stats = {
            "selected_epoch": int(best_epoch),
            "validation_auc": (
                None if not np.isfinite(val_auc) else float(val_auc)
            ),
            "validation_ap": (
                None if not np.isfinite(val_ap) else float(val_ap)
            ),
            "validation_brier": float(val_brier),
            "validation_fraction": float(validation_fraction),
            "patience": int(patience),
        }


    # -----------------------------------------------------------------------
    # Probability helpers
    # -----------------------------------------------------------------------

    def _gbt_proba(self, X: np.ndarray) -> np.ndarray:
        Xsc = self.scaler.transform(X)
        return self.gbt.predict_proba(Xsc)[:, 1]

    def _lstm_proba(self, X: np.ndarray) -> np.ndarray:
        Xsc = self.lstm_scaler.transform(X)
        probs = np.full(len(Xsc), 0.5, dtype=float)

        self.lstm_net.eval()

        with torch.no_grad():
            for i in range(len(Xsc)):
                start = max(0, i - self.seq_len + 1)
                seq = Xsc[start:i + 1]

                if len(seq) < 2:
                    probs[i] = 0.5
                    continue

                pad = np.zeros(
                    (self.seq_len, self.input_dim),
                    dtype=np.float32,
                )
                pad[-len(seq):] = seq[-self.seq_len:]

                t = torch.tensor(
                    pad,
                    dtype=torch.float32,
                    device=DEVICE,
                ).unsqueeze(0)

                logits = self.lstm_net(t)
                probs[i] = float(torch.sigmoid(logits).cpu().item())

        return probs

    def _ensemble_proba(self, X: np.ndarray) -> np.ndarray:
        g = self._gbt_proba(X)
        l = self._lstm_proba(X)
        return np.clip(0.65 * g + 0.35 * l, 0.0, 1.0)

    # -----------------------------------------------------------------------
    # Inference
    # -----------------------------------------------------------------------

    def _feature_matrix_for_inference(
        self,
        signals: pd.DataFrame,
        score: pd.Series,
    ) -> Tuple[pd.DataFrame, np.ndarray]:
        signals_aug, geo_meta = augment_signals_with_geopolitical(
            signals,
            use_cache=True,
        )
        self.geo_metadata = geo_meta
        feat = build_features(signals_aug, score)

        missing = [c for c in self.feat_cols if c not in feat.columns]
        if missing:
            raise RuntimeError(
                "Inference features do not match training features. "
                f"Missing: {missing[:10]}"
            )

        feat = feat[self.feat_cols]

        # For inference only, use causal forward-fill, then 0 for any remaining
        # initial warm-up values. Today's row should normally be fully populated.
        feat = feat.ffill().fillna(0.0)

        X = feat.values.astype(np.float32)
        return feat, X

    def predict_today(
        self,
        signals: pd.DataFrame,
        score: pd.Series,
    ) -> Dict:
        if not self.trained:
            raise RuntimeError("Call train() first.")

        feat, X = self._feature_matrix_for_inference(signals, score)
        prob = float(self._ensemble_proba(X)[-1])

        if prob < 0.25:
            level, color = "LOW", "🟢"
        elif prob < 0.50:
            level, color = "MEDIUM", "🟡"
        elif prob < 0.75:
            level, color = "HIGH", "🟠"
        else:
            level, color = "CRITICAL", "🔴"

        # GBT feature importances
        imp = self.gbt.feature_importances_
        top_idx = np.argsort(imp)[::-1][:5]

        drivers = [
            (self.feat_cols[i], round(float(imp[i]) * 100, 1))
            for i in top_idx
        ]

        recommendations = {
            "LOW": "Low modeled crash risk. Maintain risk controls and current allocation.",
            "MEDIUM": "Moderate modeled crash risk. Review exposure and hedges.",
            "HIGH": "High modeled crash risk. Consider a more defensive allocation.",
            "CRITICAL": "Very high modeled crash risk. Apply maximum predefined risk controls.",
        }

        # Live geopolitical snapshot is included for explanation. GDELT live-news
        # values are deliberately NOT mixed into the learned crash probability
        # until an equivalent historical series has been backfilled.
        try:
            geo_snapshot = get_geopolitical_snapshot(
                signals=signals,
                use_cache=True,
                include_live_news=True,
            )
        except Exception as exc:
            geo_snapshot = {"error": str(exc)}

        return {
            "probability": round(prob * 100, 1),
            "alert": f"{color} {level}",
            "horizon_days": self.horizon,
            "market": self.market,
            "benchmark": self.ticker,
            "target_definition": (
                f"{self.horizon}-session return <= "
                f"{self.return_threshold*100:.1f}% OR max drawdown <= "
                f"{self.drawdown_threshold*100:.1f}%"
            ),
            "top_drivers": drivers,
            "recommendation": recommendations[level],
            "stress_score": float(score.iloc[-1]),
            "geopolitical": geo_snapshot,
        }

    def predict_series(
        self,
        signals: pd.DataFrame,
        score: pd.Series,
    ) -> pd.Series:
        _, X = self._feature_matrix_for_inference(signals, score)
        prob = self._ensemble_proba(X)
        return pd.Series(
            prob,
            index=signals.index,
            name=f"crash_prob_{self.market}",
        )

    # -----------------------------------------------------------------------
    # Safe persistence
    # -----------------------------------------------------------------------

    def save(self, path: Optional[str] = None):
        if path is None:
            path = get_save_path(self.market)

        if self.lstm_net is None:
            raise RuntimeError("Cannot save before LSTM is trained.")

        payload = {
            "model_version": MODEL_VERSION,
            "market": self.market,
            "ticker": self.ticker,
            "gbt": self.gbt,
            "scaler": self.scaler,
            "lstm_scaler": self.lstm_scaler,
            "feat_cols": self.feat_cols,
            "trained": self.trained,
            "seq_len": self.seq_len,
            "input_dim": self.input_dim,
            "horizon": self.horizon,
            "return_threshold": self.return_threshold,
            "drawdown_threshold": self.drawdown_threshold,
            "geo_metadata": self.geo_metadata,
            "lstm_training_stats": self.lstm_training_stats,
            "lstm_state_dict": {
                k: v.detach().cpu()
                for k, v in self.lstm_net.state_dict().items()
            },
        }

        with open(path, "wb") as f:
            pickle.dump(payload, f)

        print(f"Model saved -> {path}")

    @classmethod
    def load(
        cls,
        path: Optional[str] = None,
        market: Optional[str] = None,
    ):
        if path is None:
            if market is None:
                market = "us"
            path = get_save_path(market)

        with open(path, "rb") as f:
            payload = pickle.load(f)

        version = payload.get("model_version", 1)
        if version != MODEL_VERSION:
            raise RuntimeError(
                f"Incompatible model version {version}. "
                f"Expected v{MODEL_VERSION}; retrain the model."
            )

        saved_market = payload["market"]

        if market is not None and market.lower() != saved_market:
            raise RuntimeError(
                f"Model file is for {saved_market.upper()}, "
                f"but {market.upper()} was requested."
            )

        m = cls(saved_market)

        m.ticker = payload["ticker"]
        m.gbt = payload["gbt"]
        m.scaler = payload["scaler"]
        m.lstm_scaler = payload["lstm_scaler"]
        m.feat_cols = payload["feat_cols"]
        m.trained = payload["trained"]
        m.seq_len = payload["seq_len"]
        m.input_dim = payload["input_dim"]
        m.horizon = payload.get("horizon", HORIZON)
        m.return_threshold = payload.get(
            "return_threshold", RETURN_CRASH_THRESHOLD
        )
        m.drawdown_threshold = payload.get(
            "drawdown_threshold", DRAWDOWN_CRASH_THRESHOLD
        )
        m.geo_metadata = payload.get("geo_metadata", {})
        m.lstm_training_stats = payload.get("lstm_training_stats", {})

        m.lstm_net = LSTMNet(m.input_dim).to(DEVICE)
        m.lstm_net.load_state_dict(payload["lstm_state_dict"])
        m.lstm_net.eval()

        print(f"Model loaded from {path} [{saved_market.upper()}]")
        return m


# ---------------------------------------------------------------------------
# Standalone
# ---------------------------------------------------------------------------

def _run_market(market: str):
    signals = load_all_signals()
    results = run_full_pipeline(signals)
    score = results["score"]

    model = EarlyWarningModel(market=market)
    stats = model.train(signals, score, lstm_epochs=60)
    model.save()

    pred = model.predict_today(signals, score)

    print("\n" + "=" * 65)
    print(f"EARLY WARNING v3 + GEOPOLITICAL RISK — {market.upper()}")
    print("=" * 65)
    print(f"Benchmark:         {pred['benchmark']}")
    print(f"Crash probability: {pred['probability']}%")
    print(f"Alert:             {pred['alert']}")
    print(f"Stress score:      {pred['stress_score']:.1f}/100")
    print(f"Target:            {pred['target_definition']}")
    print(
        f"CV AUC:            {stats['cv_auc']:.3f} | "
        f"AP: {stats['cv_average_precision']:.3f} | "
        f"Brier: {stats['cv_brier']:.3f}"
    )
    if stats.get("lstm_selected_epoch") is not None:
        va_auc = stats.get("lstm_validation_auc")
        va_ap = stats.get("lstm_validation_ap")
        va_br = stats.get("lstm_validation_brier")
        print(
            f"LSTM early stop:    epoch {stats['lstm_selected_epoch']} | "
            f"val AUC: {va_auc if va_auc is not None else 'n/a'} | "
            f"AP: {va_ap if va_ap is not None else 'n/a'} | "
            f"Brier: {va_br if va_br is not None else 'n/a'}"
        )

    geo = pred.get("geopolitical", {})
    if "error" not in geo:
        print("\nGeopolitical model features:")
        features = geo.get("features", {})
        for key in (
            "gpr_ai",
            "gpr_threats",
            "gpr_acts",
            "gpr_oil",
            "brent_roc5",
            "brent_vol20",
            "gold_roc5",
            "usd_index_roc5",
            "geo_market_stress",
        ):
            if key in features and features[key] is not None:
                print(f"  {key:28s} {features[key]:.4f}")

        age = geo.get("metadata", {}).get("ai_gpr_age_days")
        if age is not None:
            print(f"  AI-GPR age:                 {age} day(s)")

        news = geo.get("live_news", {})
        if news:
            print("\nLive geopolitical news overlay (diagnostic only; not ML input):")

            summary = news.get("summary", {})
            live_score = summary.get("live_score")
            live_level = summary.get("live_level")

            if live_score is not None:
                print(
                    f"  Risk:                       "
                    f"{float(live_score):.1f}/100 ({live_level})"
                )
            else:
                print("  Risk:                       unavailable")

            print(
                f"  Fresh headlines:            "
                f"{summary.get('fresh_headlines', 'n/a')}"
            )
            print(
                f"  Last 24h / 72h:             "
                f"{summary.get('last_24h', 'n/a')} / "
                f"{summary.get('last_72h', 'n/a')}"
            )

            event_counts = summary.get("event_counts") or {}
            if event_counts:
                print("  Event counts:")
                for event_name, count in event_counts.items():
                    print(f"    {event_name:25s} {count}")

            print(
                f"  De-escalation headlines:    "
                f"{summary.get('deescalation_count', 'n/a')}"
            )

            google = news.get("google_news") or {}
            risk_detail = google.get("live_geopolitical_risk") or {}
            top = risk_detail.get("top_risk_headlines") or []

            if top:
                print("  Top live geopolitical drivers:")
                for item in top[:5]:
                    contribution = item.get("risk_contribution", 0.0)
                    title = item.get("title", "")
                    print(f"    [{contribution:5.1f}] {title}")

            gdelt = news.get("gdelt") or {}
            if gdelt.get("errors"):
                print(
                    "  GDELT: some queries rate-limited/unavailable; "
                    "Google News used as primary live source."
                )
    else:
        print(f"\nGeopolitical snapshot unavailable: {geo['error']}")
    print("\nTop drivers:")
    for name, importance in pred["top_drivers"]:
        print(f"  {name:32s} {importance:5.1f}%")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--market",
        choices=["us", "india"],
        default="us",
    )
    args = parser.parse_args()

    _run_market(args.market)
