"""
live_data_v2.py
---------------
Deterministic live-data layer for TRAILING.live.

Key change:
The live row is generated from the SAME real/proxy methodology used by
data_loader_v2.py. No np.random values are used.

This keeps historical and live feature distributions consistent.
"""

import os
from datetime import datetime, timedelta

import pandas as pd

from data_loader import load_all_signals, SIGNAL_COLS

LIVE_DATA_FILE = "live_data_log.csv"


def fetch_live_signals() -> dict:
    """
    Fetch the latest deterministic real/proxy signal row.

    We request enough history for 200-day moving-average and other proxies.
    """
    print("  Fetching deterministic live market data...")

    end = pd.Timestamp.today().normalize() + pd.Timedelta(days=1)
    start = end - pd.Timedelta(days=500)

    df = load_all_signals(
        start=start.strftime("%Y-%m-%d"),
        end=end.strftime("%Y-%m-%d"),
        use_cache=False,
        persist_cache=False,
    )

    if df is None or len(df) == 0:
        raise RuntimeError("No live signal data could be constructed.")

    latest = df.iloc[-1]
    latest_date = df.index[-1]

    out = {col: float(latest[col]) for col in SIGNAL_COLS}
    out["date"] = latest_date.strftime("%Y-%m-%d")
    out["source"] = "yfinance_real_plus_deterministic_proxies"

    print(f"  Source: {out['source']} [ok]")
    print(f"  Latest market date: {out['date']}")
    return out


def log_daily_signals(signals: dict, path: str = LIVE_DATA_FILE):
    """Append/replace one row for the market date; never create duplicates."""
    row = {"date": signals["date"]}
    for col in SIGNAL_COLS:
        row[col] = float(signals[col])
    row["source"] = signals.get("source", "unknown")

    df_new = pd.DataFrame([row])

    if os.path.exists(path):
        old = pd.read_csv(path)
        old = old[old["date"] != row["date"]]
        out = pd.concat([old, df_new], ignore_index=True)
    else:
        out = df_new

    out = out.sort_values("date").reset_index(drop=True)
    out.to_csv(path, index=False)
    print(f"  Logged to {path} ({len(out)} total rows)")


def load_signal_history(
    path: str = LIVE_DATA_FILE,
    fallback_days: int = 252,
) -> pd.DataFrame:
    """
    Load historical real/proxy signals and append frozen live rows.

    Because data_loader now extends to the present, duplicate dates are replaced
    by the logged live row. This preserves what was actually seen on that day.
    """
    hist = load_all_signals()

    if os.path.exists(path):
        live = pd.read_csv(path, parse_dates=["date"])
        if len(live) > 0:
            live = live.set_index("date")
            live.index = pd.DatetimeIndex(live.index)
            live = live[SIGNAL_COLS]

            combined = pd.concat([hist, live])
            combined = combined[~combined.index.duplicated(keep="last")]
            combined = combined.sort_index()

            print(
                f"  History: {len(hist)} historical + {len(live)} frozen live "
                f"= {len(combined)} total"
            )
            return combined

    print(f"  Using historical real/proxy data only ({len(hist)} days)")
    return hist


def signals_to_dataframe(signals_dict: dict) -> pd.Series:
    return pd.Series(
        {col: signals_dict.get(col, 0.0) for col in SIGNAL_COLS},
        name=pd.Timestamp(signals_dict.get("date", datetime.now().strftime("%Y-%m-%d"))),
    )


if __name__ == "__main__":
    print("=" * 60)
    print("LIVE DATA v2 — deterministic forward-test input")
    print("=" * 60)
    signals = fetch_live_signals()
    for col in SIGNAL_COLS:
        print(f"{col:25s} {signals[col]:10.4f}")
    log_daily_signals(signals)
