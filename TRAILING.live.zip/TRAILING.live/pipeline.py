"""
pipeline.py
-----------
Master pipeline integrating all three models:

  1. Z-score stress index    (data_loader + signal_processor)
  2. Diffusion model         (diffusion_model) → 1000 market scenarios
  3. CVaR engine             (cvar_engine)     → tail risk computation
  4. Safe RL agent           (safe_rl_agent)   → CVaR-safe portfolio action

Run modes:
  python pipeline.py --mode train     Train diffusion + RL from scratch
  python pipeline.py --mode infer     Load trained models, get recommendation
  python pipeline.py --mode backtest  Full backtest with all three models
  python pipeline.py --mode demo      Quick demo with mock models (fast)
"""

import os, sys, argparse
import numpy as np
import pandas as pd
import torch
import warnings
warnings.filterwarnings("ignore")

sys.path.insert(0, "/home/claude/crisis_detector")

from data_loader      import load_all_signals
from signal_processor import run_full_pipeline, get_current_snapshot
from diffusion_model  import FinancialDiffusionModel
from cvar_engine      import CVaREngine, ASSET_CLASSES
from safe_rl_agent    import SafeRLAgent, N_ASSETS, train_agent

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ---------------------------------------------------------------------------
# Quick recommendation (single inference pass)
# ---------------------------------------------------------------------------
def get_recommendation(signals: pd.DataFrame,
                        diffusion: FinancialDiffusionModel,
                        agent: SafeRLAgent,
                        n_scenarios: int = 500,
                        max_cvar: float = -0.15) -> dict:
    """
    Given current market state, produce a CVaR-safe portfolio recommendation
    with full explanation.
    """
    signal_dim   = signals.shape[1]
    current_state = signals.iloc[-1].values.astype(np.float32)
    current_weights = np.ones(N_ASSETS) / N_ASSETS  # assume equal-weight start

    # State vector for RL agent
    state = np.concatenate([current_state, current_weights]).astype(np.float32)

    print(f"  Generating {n_scenarios} diffusion scenarios...")
    scenarios = diffusion.generate_scenarios(current_state, n_scenarios)

    print("  Running safe RL agent + action repair...")
    action, info = agent.select_action(state, scenarios, deterministic=True)

    # Full CVaR analysis
    engine  = CVaREngine(alpha=0.05)
    metrics = engine.compute(action, scenarios)
    risk_explanation = engine.explain_risk(action, scenarios, metrics)
    action_explanation = agent.explain_action(info)

    return {
        "weights":             action,
        "weights_named":       dict(zip(ASSET_CLASSES, action)),
        "cvar_metrics":        metrics,
        "action_info":         info,
        "risk_explanation":    risk_explanation,
        "action_explanation":  action_explanation,
        "scenarios":           scenarios,
    }


# ---------------------------------------------------------------------------
# Rolling backtest with all three models
# ---------------------------------------------------------------------------
def backtest_full_pipeline(signals: pd.DataFrame,
                           diffusion: FinancialDiffusionModel,
                           agent: SafeRLAgent,
                           n_scenarios: int = 200,
                           lookback: int = 60,
                           step: int = 21) -> pd.DataFrame:
    """
    Walk-forward backtest of the full pipeline.
    Every `step` days, generate a new portfolio recommendation
    and record performance vs a passive 60/40 benchmark.
    """
    from cvar_engine import signals_to_returns

    signal_dim = signals.shape[1]
    records    = []

    indices = range(lookback, len(signals) - 30, step)
    print(f"\nRunning walk-forward backtest ({len(indices)} rebalance points)...")

    for i, idx in enumerate(indices):
        current_state   = signals.iloc[idx].values.astype(np.float32)
        current_weights = np.ones(N_ASSETS) / N_ASSETS
        state = np.concatenate([current_state, current_weights]).astype(np.float32)

        # Generate scenarios
        scenarios = diffusion.generate_scenarios(current_state, n_scenarios)

        # Get safe allocation
        action, info = agent.select_action(state, scenarios, deterministic=True)

        # Compute 21-day forward return
        asset_rets = signals_to_returns(scenarios)
        fwd_rets   = asset_rets[:, :step, :]

        # Strategy return
        strat_ret  = float(
            ((1 + (fwd_rets * action).sum(-1)).prod(1) - 1).mean()
        )

        # Benchmark: 60% Indian equity, 30% bonds, 10% gold
        bench_w = np.zeros(N_ASSETS)
        bench_w[0] = 0.60   # Indian equity
        bench_w[4] = 0.30   # Indian bonds
        bench_w[3] = 0.10   # Gold
        bench_ret = float(
            ((1 + (fwd_rets * bench_w).sum(-1)).prod(1) - 1).mean()
        )

        records.append({
            "date":          str(signals.index[idx].date()),
            "stress_score":  float(
                run_full_pipeline(signals.iloc[max(0, idx-60):idx+1])["score"].iloc[-1]
            ),
            "cvar":          info["cvar"],
            "expected_ret":  info["expected_ret"],
            "strategy_ret":  strat_ret,
            "benchmark_ret": bench_ret,
            "repaired":      info["repaired"],
            "top_asset":     max(info["weights_named"].items(),
                                key=lambda x: x[1])[0],
        })

        if (i + 1) % 5 == 0:
            print(f"  Step {i+1}/{len(indices)} | "
                  f"strategy={strat_ret*100:.1f}% "
                  f"benchmark={bench_ret*100:.1f}%")

    df = pd.DataFrame(records)

    # Cumulative performance
    df["strategy_cum"]  = (1 + df["strategy_ret"]).cumprod()
    df["benchmark_cum"] = (1 + df["benchmark_ret"]).cumprod()

    print("\nBacktest summary:")
    print(f"  Strategy  ann. return:  "
          f"{((df['strategy_cum'].iloc[-1]) ** (252/len(df)/step) - 1)*100:.1f}%")
    print(f"  Benchmark ann. return:  "
          f"{((df['benchmark_cum'].iloc[-1]) ** (252/len(df)/step) - 1)*100:.1f}%")
    print(f"  Avg CVaR:               {df['cvar'].mean()*100:.1f}%")
    print(f"  Repair rate:            {df['repaired'].mean()*100:.0f}%")

    return df


# ---------------------------------------------------------------------------
# Demo mode: fast run with mock diffusion (no training needed)
# ---------------------------------------------------------------------------
def run_demo(signals: pd.DataFrame, max_cvar: float = -0.15):
    """
    Fast demo using a mock diffusion model.
    Shows the full pipeline output without requiring model training.
    """
    print("\n" + "=" * 60)
    print("  DEMO MODE — mock diffusion model, real CVaR + RL")
    print("=" * 60)

    signal_dim  = signals.shape[1]
    state_dim   = signal_dim + N_ASSETS
    rng         = np.random.default_rng(42)

    # Mock diffusion: generate plausible-looking scenarios
    class MockDiffusion:
        def generate_scenarios(self, state, n_scenarios):
            n_sc = n_scenarios
            scenarios = rng.normal(0, 1, (n_sc, 30, signal_dim)).astype(np.float32)
            # Anchor to current state with some persistence
            for t in range(1, 30):
                scenarios[:, t, :] = (
                    0.85 * scenarios[:, t-1, :]
                    + 0.15 * rng.normal(0, 1, (n_sc, signal_dim))
                )
            scenarios[:, 0, :] = state
            return scenarios

    diffusion = MockDiffusion()
    agent     = SafeRLAgent(state_dim=state_dim, max_cvar=max_cvar)

    # Stress index
    print("\n[1] Computing stress index...")
    results = run_full_pipeline(signals)
    snap    = get_current_snapshot(results)
    print(f"  Stress score: {snap['stress_score']:.1f} / 100 "
          f"({snap['regime'].upper()})")
    print(f"  Trend: {snap['trend']}")

    # Recommendation
    print("\n[2] Generating portfolio recommendation...")
    rec = get_recommendation(signals, diffusion, agent,
                             n_scenarios=300, max_cvar=max_cvar)

    print("\n" + rec["action_explanation"])
    print("\n" + rec["risk_explanation"])

    # Full allocation table
    print("\n[3] Full allocation breakdown:")
    print(f"  {'Asset class':20s} {'Weight':>8s}")
    print(f"  {'-'*30}")
    for asset, w in sorted(rec["weights_named"].items(),
                            key=lambda x: -x[1]):
        bar = "█" * int(w * 40)
        print(f"  {asset:20s} {w*100:6.1f}%  {bar}")


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="Financial crisis detection + safe portfolio optimization"
    )
    parser.add_argument("--mode", choices=["train", "infer", "backtest", "demo"],
                        default="demo")
    parser.add_argument("--epochs_diff", type=int, default=100,
                        help="Diffusion model training epochs")
    parser.add_argument("--episodes_rl", type=int, default=50,
                        help="RL agent training episodes")
    parser.add_argument("--n_scenarios", type=int, default=300,
                        help="Diffusion scenarios per inference step")
    parser.add_argument("--max_cvar", type=float, default=-0.15,
                        help="CVaR loss limit (e.g. -0.15 = max -15%)")
    parser.add_argument("--diff_path", default="diffusion_model.pt")
    parser.add_argument("--rl_path",   default="safe_rl_agent.pt")
    args = parser.parse_args()

    print("=" * 60)
    print("  CRISIS DETECTION + SAFE PORTFOLIO OPTIMIZATION")
    print(f"  Device: {DEVICE}")
    print("=" * 60)

    print("\nLoading signals...")
    signals    = load_all_signals()
    signal_dim = signals.shape[1]
    state_dim  = signal_dim + N_ASSETS

    if args.mode == "demo":
        run_demo(signals, max_cvar=args.max_cvar)

    elif args.mode == "train":
        # Train diffusion model
        print("\n[1/2] Training diffusion model...")
        diffusion = FinancialDiffusionModel(
            signal_dim=signal_dim, horizon=30,
            T=200, model_dim=128
        )
        diffusion.train_model(signals, epochs=args.epochs_diff,
                              save_path=args.diff_path)

        # Train RL agent
        print("\n[2/2] Training safe RL agent...")
        agent = train_agent(
            signals, diffusion,
            n_episodes=args.episodes_rl,
            max_cvar=args.max_cvar,
            n_scenarios=args.n_scenarios,
            save_path=args.rl_path
        )
        print("\nTraining complete.")

    elif args.mode == "infer":
        print("\nLoading trained models...")
        diffusion = FinancialDiffusionModel.load(args.diff_path)
        agent     = SafeRLAgent.load(args.rl_path, state_dim=state_dim,
                                      max_cvar=args.max_cvar)

        print("\nGenerating recommendation...")
        rec = get_recommendation(signals, diffusion, agent,
                                 n_scenarios=args.n_scenarios,
                                 max_cvar=args.max_cvar)
        print("\n" + rec["action_explanation"])
        print("\n" + rec["risk_explanation"])

    elif args.mode == "backtest":
        print("\nLoading trained models for backtest...")
        diffusion = FinancialDiffusionModel.load(args.diff_path)
        agent     = SafeRLAgent.load(args.rl_path, state_dim=state_dim,
                                      max_cvar=args.max_cvar)

        df = backtest_full_pipeline(
            signals, diffusion, agent,
            n_scenarios=args.n_scenarios
        )
        df.to_csv("backtest_results.csv", index=False)
        print("Backtest results saved → backtest_results.csv")


if __name__ == "__main__":
    main()
