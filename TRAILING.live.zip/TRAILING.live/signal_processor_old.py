"""
signal_processor.py
--------------------
Transforms raw signals into a composite Financial Stress Index (FSI).

Pipeline:
  1. Rolling Z-score normalisation (60-day window)
  2. Per-category aggregation (credit, yield, liquidity, India)
  3. Weighted composite stress score (0-100)
  4. Exponential smoothing to remove day-to-day noise
  5. Regime classification (calm / elevated / critical)

Why Z-scores?
  Every raw signal lives on a different scale: VIX is 10-80,
  credit spread is 2-20%, FII flows are in ₹ crore. We can't
  add them directly. Rolling Z-scores convert each to "how many
  standard deviations above its recent normal is this reading?"
  That's a universal unit we can combine meaningfully.

Why rolling (not static)?
  Markets change their "normal." VIX of 25 was alarming in 2006
  but unremarkable in 2020. A 60-day rolling window adapts the
  baseline so signals stay relevant across different market regimes.
"""

import numpy as np
import pandas as pd
from typing import Dict, Tuple


# ---------------------------------------------------------------------------
# Signal direction: some signals go UP in stress, some go DOWN
# We flip the ones that go DOWN so all Z-scores point in the same direction
# (positive Z = more stress)
# ---------------------------------------------------------------------------
SIGNAL_DIRECTION = {
    "vix":                +1,   # High VIX = high fear
    "india_vix":          +1,   # High India VIX = high fear
    "yield_curve_spread": -1,   # Low / negative spread = stressed (inverted curve)
    "credit_spread":      +1,   # Wide spread = credit stress
    "ted_spread":         +1,   # Wide spread = interbank stress
    "market_breadth":     -1,   # Low breadth = fewer stocks holding up
    "put_call_ratio":     +1,   # High ratio = fear / hedging
    "fii_flows":          -1,   # Negative flows (outflows) = EM stress
    "inr_usd_roc":        +1,   # Fast INR depreciation = stress
}

# ---------------------------------------------------------------------------
# Category groupings — for explainability
# Users see: "Credit stress is elevated" not "ted_spread Z = 1.8"
# ---------------------------------------------------------------------------
CATEGORIES = {
    "credit": {
        "signals": ["credit_spread", "ted_spread"],
        "weight": 0.30,
        "label": "Credit & interbank stress",
        "description": "Corporate bond spreads and interbank lending rates",
    },
    "yield_curve": {
        "signals": ["yield_curve_spread"],
        "weight": 0.20,
        "label": "Yield curve",
        "description": "10Y-2Y Treasury spread (inverted = recession signal)",
    },
    "liquidity": {
        "signals": ["vix", "market_breadth", "put_call_ratio"],
        "weight": 0.25,
        "label": "Market liquidity & sentiment",
        "description": "Volatility, market breadth, options positioning",
    },
    "india": {
        "signals": ["india_vix", "fii_flows", "inr_usd_roc"],
        "weight": 0.25,
        "label": "India-specific stress",
        "description": "India VIX, FII flows, rupee velocity",
    },
}

# ---------------------------------------------------------------------------
# Regime thresholds
# ---------------------------------------------------------------------------
REGIMES = {
    "calm":     (0,  35,  "green",  "Markets stable. Strategy: hold."),
    "elevated": (35, 65,  "amber",  "Stress building. Strategy: trim risk, raise bonds."),
    "critical": (65, 101, "red",    "High risk of correction. Strategy: defensive shift."),
}


# ---------------------------------------------------------------------------
# Core functions
# ---------------------------------------------------------------------------

def rolling_zscore(series: pd.Series, window: int = 60) -> pd.Series:
    """
    Compute rolling Z-score with a minimum of 20 observations.
    Z = (x - rolling_mean) / rolling_std

    Clipped to [-4, +4] to prevent extreme outliers from dominating.
    """
    roll = series.rolling(window=window, min_periods=20)
    mean = roll.mean()
    std  = roll.std()

    # Avoid division by zero on flat series
    std = std.replace(0, np.nan).ffill().fillna(1.0)

    z = (series - mean) / std
    return z.clip(-4, 4)


def compute_signal_zscores(df: pd.DataFrame,
                           window: int = 60) -> pd.DataFrame:
    """
    Compute Z-scores for all signals, flipping direction so that
    positive Z always means MORE stress.

    Returns DataFrame with same columns, all in stress-direction Z-score space.
    """
    z_df = pd.DataFrame(index=df.index)

    for col in df.columns:
        if col not in SIGNAL_DIRECTION:
            continue
        direction = SIGNAL_DIRECTION[col]
        z = rolling_zscore(df[col], window=window)
        z_df[col] = z * direction  # flip if needed

    return z_df


def compute_category_scores(z_df: pd.DataFrame) -> pd.DataFrame:
    """
    Average Z-scores within each category.
    Returns a DataFrame with one column per category, in Z-score space.
    """
    cat_df = pd.DataFrame(index=z_df.index)

    for cat_name, cat_info in CATEGORIES.items():
        signals = [s for s in cat_info["signals"] if s in z_df.columns]
        if not signals:
            continue
        cat_df[cat_name] = z_df[signals].mean(axis=1)

    return cat_df


def compute_composite_stress(cat_df: pd.DataFrame,
                              smooth_span: int = 5) -> pd.Series:
    """
    Weighted average of category scores → percentile rank → 0-100 score.

    Steps:
      1. Weighted average of category Z-scores
      2. Exponential moving average (span=5) to smooth day-to-day noise
      3. Percentile rank over the full history → 0-100

    The percentile approach means "score of 80" = "more stressed than
    80% of all historical days" — interpretable to non-experts.
    """
    composite = pd.Series(0.0, index=cat_df.index)

    for cat_name, cat_info in CATEGORIES.items():
        if cat_name not in cat_df.columns:
            continue
        composite += cat_df[cat_name] * cat_info["weight"]

    # Smooth with EMA
    smoothed = composite.ewm(span=smooth_span, adjust=False).mean()

    # Convert to 0-100 percentile rank
    score = smoothed.rank(pct=True) * 100

    return score.rename("stress_score")


def classify_regime(score: float) -> Tuple[str, str, str]:
    """
    Returns (regime_name, color, action_description) for a given score.
    """
    for regime, (low, high, color, desc) in REGIMES.items():
        if low <= score < high:
            return regime, color, desc
    return "critical", "red", REGIMES["critical"][3]


def run_full_pipeline(df: pd.DataFrame,
                      window: int = 60) -> Dict[str, pd.DataFrame]:
    """
    Master function: raw signals → stress score.

    Returns a dict with:
      'raw'       - original signals
      'z_scores'  - per-signal Z-scores
      'categories'- per-category scores
      'score'     - final 0-100 stress score
      'full'      - all of the above merged
    """
    print(f"Processing {len(df)} days of signals...")

    z_df    = compute_signal_zscores(df, window=window)
    cat_df  = compute_category_scores(z_df)
    score   = compute_composite_stress(cat_df)

    full_df = pd.concat([df, z_df.add_suffix("_z"), cat_df, score], axis=1)

    print(f"  Score range: {score.min():.1f} – {score.max():.1f}")
    print(f"  Days calm:     {(score < 35).sum():4d} ({(score < 35).mean()*100:.1f}%)")
    print(f"  Days elevated: {((score >= 35) & (score < 65)).sum():4d} "
          f"({((score >= 35) & (score < 65)).mean()*100:.1f}%)")
    print(f"  Days critical: {(score >= 65).sum():4d} ({(score >= 65).mean()*100:.1f}%)")

    return {
        "raw":        df,
        "z_scores":   z_df,
        "categories": cat_df,
        "score":      score,
        "full":       full_df,
    }


def get_current_snapshot(results: Dict,
                          lookback_days: int = 1) -> Dict:
    """
    Returns a human-readable snapshot of the current stress state.
    Useful for the user-facing dashboard / alert system.
    """
    score_series = results["score"]
    cat_df       = results["categories"]
    z_df         = results["z_scores"]

    latest_score = float(score_series.iloc[-lookback_days])
    regime, color, action = classify_regime(latest_score)

    # Per-category breakdown
    cat_snapshot = {}
    for cat_name, cat_info in CATEGORIES.items():
        if cat_name not in cat_df.columns:
            continue
        cat_z = float(cat_df[cat_name].iloc[-lookback_days])
        # Map Z to 0-100 intuitively for display
        cat_pct = float(
            (cat_df[cat_name].rank(pct=True) * 100).iloc[-lookback_days]
        )
        cat_snapshot[cat_name] = {
            "label":       cat_info["label"],
            "z_score":     round(cat_z, 2),
            "percentile":  round(cat_pct, 1),
            "description": cat_info["description"],
        }

    # Top 3 most stressed individual signals
    latest_z = z_df.iloc[-lookback_days]
    top_signals = (
        latest_z.sort_values(ascending=False)
                 .head(3)
                 .to_dict()
    )

    # 30-day trend
    recent_scores = score_series.iloc[-30:]
    trend = "rising" if recent_scores.iloc[-1] > recent_scores.mean() else "falling"

    return {
        "date":          str(score_series.index[-lookback_days].date()),
        "stress_score":  round(latest_score, 1),
        "regime":        regime,
        "color":         color,
        "action":        action,
        "trend":         trend,
        "categories":    cat_snapshot,
        "top_signals":   {k: round(v, 2) for k, v in top_signals.items()},
    }


if __name__ == "__main__":
    from data_loader import load_all_signals

    df = load_all_signals()
    results = run_full_pipeline(df)

    snap = get_current_snapshot(results)
    print("\n--- Latest market snapshot ---")
    print(f"Date:          {snap['date']}")
    print(f"Stress score:  {snap['stress_score']:.1f} / 100")
    print(f"Regime:        {snap['regime'].upper()} ({snap['color']})")
    print(f"Action:        {snap['action']}")
    print(f"Trend:         {snap['trend']}")
    print("\nCategory breakdown:")
    for cat, info in snap["categories"].items():
        print(f"  {info['label']:35s} Z={info['z_score']:+.2f}  "
              f"({info['percentile']:.0f}th pct)")
    print("\nTop stressed signals:")
    for sig, z in snap["top_signals"].items():
        print(f"  {sig:30s} Z={z:+.2f}")
