"""
backtester.py
-------------
Evaluates how well the stress index would have predicted historical crises.

For each known crisis event, we measure:
  - What was the stress score N days before the crash?
  - How many days of warning did the model give? (days before score > threshold)
  - Peak score in the 30 days leading up to the crash
  - False positive rate: days flagged as critical outside crisis windows

This is the output you show investors.
"Our model flagged a score above 65 an average of 14 days before each crash,
with a false positive rate of only 4.2% of trading days."
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple
from signal_processor import classify_regime
from data_loader import CRISIS_EVENTS


# ---------------------------------------------------------------------------
# Backtesting configuration
# ---------------------------------------------------------------------------

# Window around each crisis to define "crisis period"
# Signals within PRE_CRISIS_WINDOW days before crash are "true positives"
PRE_CRISIS_WINDOW  = 30   # days before crisis
POST_CRISIS_WINDOW = 20   # days after (still in crisis mode, not false pos)

# Score threshold for "alert" — above this = model is warning
ALERT_THRESHOLD = 55.0    # elevated warning level
CRITICAL_THRESHOLD = 65.0  # critical warning level


# ---------------------------------------------------------------------------
# Core backtesting functions
# ---------------------------------------------------------------------------

def get_crisis_windows(score_index: pd.DatetimeIndex) -> pd.Series:
    """
    Returns a boolean Series marking all dates within any crisis window.
    Used to exclude these dates from false positive calculation.
    """
    in_crisis = pd.Series(False, index=score_index)

    for crisis_date_str in CRISIS_EVENTS:
        crisis_dt = pd.Timestamp(crisis_date_str)
        window_start = crisis_dt - pd.Timedelta(days=PRE_CRISIS_WINDOW)
        window_end   = crisis_dt + pd.Timedelta(days=POST_CRISIS_WINDOW)
        mask = (score_index >= window_start) & (score_index <= window_end)
        in_crisis = in_crisis | mask

    return in_crisis


def analyse_single_crisis(crisis_date: str,
                           crisis_label: str,
                           score: pd.Series,
                           threshold: float = ALERT_THRESHOLD) -> Dict:
    """
    For a single crisis event, compute:
      - Score at crash date
      - Peak score in 30-day pre-crash window
      - Days of early warning (days before score first crossed threshold)
      - Score trajectory: [T-30, T-20, T-10, T-5, T-0]
    """
    crash_dt = pd.Timestamp(crisis_date)

    # Get 30 days before crash
    window_start = crash_dt - pd.Timedelta(days=40)
    window_end   = crash_dt + pd.Timedelta(days=5)

    pre_crash = score.loc[
        (score.index >= window_start) & (score.index <= crash_dt)
    ]
    at_crash_score = float(score.asof(crash_dt)) if crash_dt in score.index \
        else float(pre_crash.iloc[-1]) if len(pre_crash) > 0 else np.nan

    if len(pre_crash) == 0:
        return {
            "crisis":           crisis_label,
            "date":             crisis_date,
            "score_at_crash":   np.nan,
            "peak_pre_score":   np.nan,
            "days_warning":     np.nan,
            "warning_given":    False,
        }

    peak_score = float(pre_crash.max())

    # Find first day score crossed threshold before crash
    above_threshold = pre_crash[pre_crash >= threshold]
    if len(above_threshold) > 0:
        first_warning_dt = above_threshold.index[0]
        days_warning = (crash_dt - first_warning_dt).days
    else:
        days_warning = 0

    # Score trajectory at specific lookbacks
    trajectory = {}
    for lookback in [30, 20, 10, 5, 0]:
        target_dt = crash_dt - pd.Timedelta(days=lookback)
        val = score.asof(target_dt)
        trajectory[f"T-{lookback}"] = round(float(val), 1) if pd.notna(val) else None

    return {
        "crisis":           crisis_label,
        "date":             crisis_date,
        "score_at_crash":   round(at_crash_score, 1),
        "peak_pre_score":   round(peak_score, 1),
        "days_warning":     days_warning,
        "warning_given":    days_warning > 0,
        "trajectory":       trajectory,
    }


def compute_false_positive_rate(score: pd.Series,
                                threshold: float = ALERT_THRESHOLD) -> Dict:
    """
    False positive rate: what % of non-crisis days did we flag as stressed?
    Lower is better. Real-world target: < 8%.
    """
    in_crisis = get_crisis_windows(score.index)

    non_crisis_days  = score[~in_crisis]
    flagged_non_crisis = non_crisis_days[non_crisis_days >= threshold]

    fp_rate = len(flagged_non_crisis) / len(non_crisis_days) * 100 if len(non_crisis_days) > 0 else 0

    return {
        "total_days":       len(score),
        "crisis_days":      int(in_crisis.sum()),
        "non_crisis_days":  len(non_crisis_days),
        "flagged_fp":       len(flagged_non_crisis),
        "fp_rate_pct":      round(fp_rate, 2),
    }


def run_full_backtest(score: pd.Series,
                      threshold: float = ALERT_THRESHOLD) -> Dict:
    """
    Run backtest across all known crisis events.
    Returns a comprehensive results dict.
    """
    print(f"\nRunning backtest (threshold: {threshold:.0f})...")
    print(f"  Evaluating {len(CRISIS_EVENTS)} historical crisis events")

    results = []
    for crisis_date, (label, _) in CRISIS_EVENTS.items():
        crisis_dt = pd.Timestamp(crisis_date)
        if crisis_dt < score.index[0] or crisis_dt > score.index[-1]:
            print(f"  Skipping {label} (outside data range)")
            continue

        result = analyse_single_crisis(crisis_date, label, score, threshold)
        results.append(result)
        status = "✓ WARNING GIVEN" if result["warning_given"] else "✗ MISSED"
        print(f"  {label:25s} | score={result['score_at_crash']:.0f} "
              f"| peak={result['peak_pre_score']:.0f} "
              f"| {result['days_warning']} days early | {status}")

    fp_stats = compute_false_positive_rate(score, threshold)

    # Summary stats
    warned = [r for r in results if r["warning_given"]]
    detection_rate = len(warned) / len(results) * 100 if results else 0
    avg_warning    = np.mean([r["days_warning"] for r in warned]) if warned else 0
    avg_peak_score = np.mean([r["peak_pre_score"] for r in results
                              if not np.isnan(r["peak_pre_score"])])

    summary = {
        "total_crises_tested":   len(results),
        "crises_detected":       len(warned),
        "detection_rate_pct":    round(detection_rate, 1),
        "avg_days_warning":      round(avg_warning, 1),
        "avg_peak_score":        round(avg_peak_score, 1),
        "false_positive_rate":   fp_stats["fp_rate_pct"],
        "threshold_used":        threshold,
    }

    print(f"\n  Detection rate:      {summary['detection_rate_pct']}%")
    print(f"  Avg days warning:    {summary['avg_days_warning']} days")
    print(f"  False positive rate: {summary['false_positive_rate']}%")

    return {
        "per_crisis":   results,
        "false_pos":    fp_stats,
        "summary":      summary,
    }


def _download_real_returns(
    start: pd.Timestamp,
    end: pd.Timestamp,
    market: str = "us",
) -> Tuple[pd.Series, pd.Series]:
    """
    Download REAL historical daily returns.

    IMPORTANT:
      - No synthetic returns are used.
      - Strategy signals are shifted by one trading day before being applied.
      - Equity and bond series are aligned on common trading dates.
    """
    try:
        import yfinance as yf
    except ImportError as exc:
        raise ImportError(
            "yfinance is required for the real-data backtest. "
            "Install it with: pip install yfinance"
        ) from exc

    market = market.lower()
    if market == "india":
        equity_ticker = "^NSEI"
    elif market == "us":
        equity_ticker = "^GSPC"
    else:
        raise ValueError("market must be 'india' or 'us'")

    # IEF is a liquid US 7-10Y Treasury ETF and is used as a
    # defensive bond proxy for a comparable, consistently available series.
    tickers = [equity_ticker, "IEF"]

    data = yf.download(
        tickers,
        start=(start - pd.Timedelta(days=10)).strftime("%Y-%m-%d"),
        end=(end + pd.Timedelta(days=2)).strftime("%Y-%m-%d"),
        auto_adjust=True,
        progress=False,
        group_by="column",
        threads=False,
    )

    if data.empty:
        raise RuntimeError("No market data returned by yfinance.")

    if isinstance(data.columns, pd.MultiIndex):
        close = data["Close"].copy()
    else:
        close = data[["Close"]].copy()

    missing = [t for t in tickers if t not in close.columns]
    if missing:
        raise RuntimeError(f"Missing downloaded series: {missing}")

    close = close[tickers].dropna(how="all")
    returns = close.pct_change().dropna()
    returns = returns.loc[(returns.index >= start) & (returns.index <= end)]

    if len(returns) < 252:
        raise RuntimeError(
            f"Only {len(returns)} overlapping trading days were available. "
            "At least 252 are recommended."
        )

    return returns[equity_ticker].rename("equity"), returns["IEF"].rename("bonds")


def _performance_metrics(returns: pd.Series, initial: float = 100.0) -> Dict:
    """Calculate standard portfolio performance statistics."""
    returns = pd.Series(returns).dropna()
    if returns.empty:
        return {}

    equity_curve = initial * (1.0 + returns).cumprod()
    years = len(returns) / 252.0

    total_return = equity_curve.iloc[-1] / initial - 1.0
    cagr = (equity_curve.iloc[-1] / initial) ** (1.0 / years) - 1.0

    rf_daily = (1.05 ** (1 / 252.0)) - 1.0
    excess = returns - rf_daily
    vol = returns.std(ddof=1) * np.sqrt(252)

    sharpe = (
        excess.mean() / returns.std(ddof=1) * np.sqrt(252)
        if returns.std(ddof=1) > 0 else np.nan
    )

    downside = returns[returns < rf_daily] - rf_daily
    downside_dev = downside.std(ddof=1) * np.sqrt(252) if len(downside) > 1 else np.nan
    sortino = (
        (returns.mean() - rf_daily) * 252 / downside_dev
        if pd.notna(downside_dev) and downside_dev > 0 else np.nan
    )

    rolling_max = equity_curve.cummax()
    drawdown = equity_curve / rolling_max - 1.0
    max_dd = drawdown.min()

    calmar = cagr / abs(max_dd) if max_dd < 0 else np.nan

    return {
        "final_value": float(equity_curve.iloc[-1]),
        "total_return_pct": float(total_return * 100),
        "cagr_pct": float(cagr * 100),
        "annual_vol_pct": float(vol * 100),
        "max_drawdown_pct": float(max_dd * 100),
        "sharpe": float(sharpe),
        "sortino": float(sortino),
        "calmar": float(calmar),
        "equity_curve": equity_curve,
        "drawdown": drawdown,
    }


def compute_portfolio_protection(
    score: pd.Series,
    market_returns: pd.Series = None,
    bond_returns: pd.Series = None,
    market: str = "us",
    transaction_cost_bps: float = 5.0,
    normal_equity: float = 0.70,
    warning_equity: float = 0.50,
    critical_equity: float = 0.25,
) -> Dict:
    """
    Real-data portfolio protection backtest.

    The previous implementation generated synthetic returns when no returns
    were supplied. This version downloads actual historical market data by
    default and applies yesterday's signal to today's return, preventing
    look-ahead bias.

    Allocation:
      score < 55 : 70% equity / 30% bonds
      55-65      : 50% equity / 50% bonds
      > 65       : 25% equity / 75% bonds

    Transaction costs are charged only when the target allocation changes.
    """
    score = pd.Series(score).copy()
    score.index = pd.to_datetime(score.index)
    score = score.sort_index().dropna()

    if market_returns is None or bond_returns is None:
        equity_returns, bond_returns_real = _download_real_returns(
            score.index.min(), score.index.max(), market=market
        )
        market_returns = equity_returns
        bond_returns = bond_returns_real

    market_returns = pd.Series(market_returns).copy()
    bond_returns = pd.Series(bond_returns).copy()
    market_returns.index = pd.to_datetime(market_returns.index)
    bond_returns.index = pd.to_datetime(bond_returns.index)

    data = pd.concat(
        [score.rename("score"),
         market_returns.rename("equity_return"),
         bond_returns.rename("bond_return")],
        axis=1,
        join="inner",
    ).dropna().sort_index()

    if len(data) < 252:
        raise RuntimeError(
            f"Only {len(data)} common observations remain after alignment."
        )

    # CRITICAL: use yesterday's information for today's trade/return.
    data["score_used"] = data["score"].shift(1)

    # Drop first row because it has no previous-day signal.
    data = data.dropna(subset=["score_used"])

    # Smooth the score slightly to reduce one-day whipsaw.
    data["score_ema"] = data["score_used"].ewm(span=3, adjust=False).mean()

    # Dynamic risk allocation.
    weights = pd.Series(normal_equity, index=data.index, dtype=float)
    weights[data["score_ema"] >= ALERT_THRESHOLD] = warning_equity
    weights[data["score_ema"] >= CRITICAL_THRESHOLD] = critical_equity

    # Portfolio return BEFORE transaction costs.
    strategy_gross = (
        weights * data["equity_return"]
        + (1.0 - weights) * data["bond_return"]
    )

    # Turnover = absolute change in target weights.
    turnover = weights.diff().abs().fillna(0.0)

    # bps -> decimal. A 5 bp one-way rebalance cost is 0.0005.
    costs = turnover * (transaction_cost_bps / 10000.0)
    strategy_returns = strategy_gross - costs

    # Static benchmark: same defensive asset pair, fixed 70/30.
    benchmark_returns = (
        normal_equity * data["equity_return"]
        + (1.0 - normal_equity) * data["bond_return"]
    )

    strategy_stats = _performance_metrics(strategy_returns)
    benchmark_stats = _performance_metrics(benchmark_returns)

    return {
        "benchmark_cumulative": benchmark_stats["equity_curve"],
        "strategy_cumulative": strategy_stats["equity_curve"],
        "benchmark_final": round(benchmark_stats["final_value"], 2),
        "strategy_final": round(strategy_stats["final_value"], 2),
        "benchmark_annualised_pct": round(benchmark_stats["cagr_pct"], 2),
        "strategy_annualised_pct": round(strategy_stats["cagr_pct"], 2),
        "benchmark_max_drawdown_pct": round(benchmark_stats["max_drawdown_pct"], 2),
        "strategy_max_drawdown_pct": round(strategy_stats["max_drawdown_pct"], 2),
        "benchmark_sharpe": round(benchmark_stats["sharpe"], 2),
        "strategy_sharpe": round(strategy_stats["sharpe"], 2),
        "benchmark_metrics": benchmark_stats,
        "strategy_metrics": strategy_stats,
        "equity_weight_series": weights,
        "score_series": data["score"],
        "score_used_series": data["score_used"],
        "turnover_series": turnover,
        "transaction_cost_series": costs,
        "backtest_data": data,
    }


def _print_performance_report(portfolio: Dict, market: str) -> None:
    b = portfolio["benchmark_metrics"]
    s = portfolio["strategy_metrics"]

    print("\n" + "=" * 68)
    print(f"  REAL-DATA PORTFOLIO BACKTEST — {market.upper()}")
    print("=" * 68)
    print("  Benchmark: static 70% equity / 30% bonds")
    print("  Strategy : score-conditioned 70% / 50% / 25% equity")
    print("  Signal   : shifted by 1 trading day (no look-ahead)")
    print("  Costs    : 5 bps on allocation turnover")
    print("-" * 68)

    print(f"  {'Metric':24s} {'Strategy':>14s} {'Benchmark':>14s}")
    print("-" * 68)
    rows = [
        ("Final value", s["final_value"], b["final_value"], "x"),
        ("Total return", s["total_return_pct"], b["total_return_pct"], "%"),
        ("CAGR", s["cagr_pct"], b["cagr_pct"], "%"),
        ("Annual volatility", s["annual_vol_pct"], b["annual_vol_pct"], "%"),
        ("Max drawdown", s["max_drawdown_pct"], b["max_drawdown_pct"], "%"),
        ("Sharpe", s["sharpe"], b["sharpe"], ""),
        ("Sortino", s["sortino"], b["sortino"], ""),
        ("Calmar", s["calmar"], b["calmar"], ""),
    ]

    for name, sv, bv, unit in rows:
        if unit == "x":
            print(f"  {name:24s} {sv:14.2f} {bv:14.2f}")
        elif unit == "%":
            print(f"  {name:24s} {sv:13.2f}% {bv:13.2f}%")
        else:
            print(f"  {name:24s} {sv:14.2f} {bv:14.2f}")

    avg_equity = portfolio["equity_weight_series"].mean() * 100
    avg_turnover = portfolio["turnover_series"].mean() * 100
    print("-" * 68)
    print(f"  Average equity exposure: {avg_equity:.1f}%")
    print(f"  Average daily turnover:  {avg_turnover:.2f}%")
    print("=" * 68)


if __name__ == "__main__":
    import argparse
    from data_loader import load_all_signals
    from signal_processor import run_full_pipeline

    parser = argparse.ArgumentParser(
        description="TRAILING.live real-data stress/protection backtester"
    )
    parser.add_argument(
        "--market",
        choices=["india", "us"],
        default="us",
        help="Market used for the real historical return series",
    )
    parser.add_argument(
        "--cost-bps",
        type=float,
        default=5.0,
        help="One-way transaction cost in basis points",
    )
    args = parser.parse_args()

    print("\n" + "=" * 68)
    print("  TRAILING.live — REAL HISTORICAL BACKTEST")
    print("=" * 68)
    print("  Loading historical signals...")

    df = load_all_signals()
    results = run_full_pipeline(df)
    score = results["score"]

    # Crisis-warning evaluation remains part of the original backtest.
    crisis_results = run_full_backtest(score)

    # Portfolio simulation now uses REAL market/bond returns.
    portfolio = compute_portfolio_protection(
        score,
        market=args.market,
        transaction_cost_bps=args.cost_bps,
    )
    _print_performance_report(portfolio, args.market)

    # Save machine-readable results for GitHub/research.
    output = pd.DataFrame({
        "score": portfolio["score_series"],
        "score_used": portfolio["score_used_series"],
        "equity_weight": portfolio["equity_weight_series"],
        "turnover": portfolio["turnover_series"],
        "transaction_cost": portfolio["transaction_cost_series"],
        "strategy_value": portfolio["strategy_cumulative"],
        "benchmark_value": portfolio["benchmark_cumulative"],
    })
    out_name = f"backtest_{args.market}.csv"
    output.to_csv(out_name)
    print(f"\n  ✓ Saved daily backtest data → {out_name}")

    print("\n  IMPORTANT:")
    print("  This is a valid historical backtest, not a guaranteed forecast.")
    print("  Compare multiple periods and keep the holdout period untouched.")
