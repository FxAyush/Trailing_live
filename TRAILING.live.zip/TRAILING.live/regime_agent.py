"""
regime_agent.py
---------------
AGENT 1: Regime Detection Agent

Classifies the current market into one of 4 regimes:
  BULL     — sustained uptrend, low volatility, positive breadth
  BEAR     — sustained downtrend, elevated volatility
  SIDEWAYS — range-bound, no clear trend, normal volatility
  CRISIS   — extreme volatility, correlation breakdown, sharp drawdown

This is NOT the same as the stress score (0-100 continuous).
This is a discrete CLASSIFICATION — like a weather forecast saying
"sunny" vs "stormy" rather than "73% humidity".

Why separate from stress score?
  Stress score tells you HOW MUCH danger.
  Regime tells you WHAT KIND of market you're in.
  A "sideways" market at stress=40 needs different handling than
  a "bear" market at stress=40 — same score, different strategy.

Method: Hidden Markov Model (HMM) — the industry standard for
regime detection. Learns regime transition probabilities from
historical data, classifies current state from recent returns
and volatility patterns.
"""

import numpy as np
import pandas as pd
from typing import Dict, Tuple
from dataclasses import dataclass
import warnings
warnings.filterwarnings("ignore")


REGIMES = ["BULL", "BEAR", "SIDEWAYS", "CRISIS"]

REGIME_COLORS = {
    "BULL":     "🟢",
    "BEAR":     "🔴",
    "SIDEWAYS": "🟡",
    "CRISIS":   "🟣",
}

REGIME_DESCRIPTIONS = {
    "BULL":     "Sustained uptrend, low volatility, broad participation",
    "BEAR":     "Sustained downtrend, elevated volatility, narrow breadth",
    "SIDEWAYS": "Range-bound, no clear trend, normal volatility",
    "CRISIS":   "Extreme volatility, correlation breakdown, sharp drawdown",
}


@dataclass
class RegimeState:
    regime:          str
    confidence:       float           # 0-1, how confident in classification
    probabilities:    Dict[str, float] # probability of each regime
    days_in_regime:   int
    transition_risk:  float           # 0-1, probability of regime change soon
    description:      str


class RegimeDetectionAgent:
    """
    Classifies market regime using a Gaussian Mixture / rule-hybrid approach.

    Features used:
      - 20-day return (trend direction)
      - 20-day volatility (regime intensity)
      - 60-day return (longer trend confirmation)
      - Drawdown from 60-day high (crisis detector)
      - Volatility-of-volatility (regime instability)
      - Skewness of returns (crash asymmetry)
    """

    def __init__(self, lookback_short: int = 20,
                 lookback_long: int = 60):
        self.lookback_short = lookback_short
        self.lookback_long  = lookback_long

        # Regime thresholds — calibrated to typical equity market behaviour
        # These act as the "means" each regime cluster is centered around
        self.regime_profiles = {
            "BULL": {
                "ret_short_mean":  0.012,   # +1.2% per 20 days = realistic bull drift
                "ret_short_std":   0.012,   # wide enough for daily noise
                "vol_mean":        0.13,    # annualised ~13%
                "vol_std":         0.04,
                "drawdown_mean":   -0.02,
                "skew_mean":       -0.1,
            },
            "BEAR": {
                "ret_short_mean":  -0.025,
                "ret_short_std":   0.025,
                "vol_mean":        0.22,
                "vol_std":         0.06,
                "drawdown_mean":   -0.12,
                "skew_mean":       -0.3,
            },
            "SIDEWAYS": {
                "ret_short_mean":  0.000,
                "ret_short_std":   0.018,   # wide enough to claim near-zero drift
                "vol_mean":        0.13,
                "vol_std":         0.03,
                "drawdown_mean":   -0.035,
                "skew_mean":       0.0,
            },
            "CRISIS": {
                "ret_short_mean":  -0.06,
                "ret_short_std":   0.05,
                "vol_mean":        0.40,
                "vol_std":         0.12,
                "drawdown_mean":   -0.20,
                "skew_mean":       -0.8,
            },
        }

        self._history: list = []   # tracks regime over time

    def _extract_features(self, returns: pd.Series) -> Dict[str, float]:
        """Extract regime-classification features from a return series."""
        if len(returns) < self.lookback_long:
            # Pad with zeros if insufficient history
            returns = pd.concat([
                pd.Series(np.zeros(self.lookback_long - len(returns))),
                returns
            ])

        short = returns.iloc[-self.lookback_short:]
        long_ = returns.iloc[-self.lookback_long:]

        ret_short = float(short.sum())
        ret_long  = float(long_.sum())
        vol       = float(short.std() * np.sqrt(252))
        vol_long  = float(long_.std() * np.sqrt(252))
        vol_of_vol = float(
            short.rolling(5).std().std()
        ) if len(short) >= 5 else 0.0

        # Drawdown from local high
        cum = (1 + long_).cumprod()
        running_max = cum.cummax()
        drawdown = float(((cum - running_max) / running_max).iloc[-1])

        # Skewness — crashes have strong negative skew
        skew = float(short.skew()) if len(short) > 3 else 0.0

        return {
            "ret_short": ret_short,
            "ret_long":  ret_long,
            "vol":       vol,
            "vol_long":  vol_long,
            "vol_of_vol": vol_of_vol,
            "drawdown":  drawdown,
            "skew":      skew,
        }

    def _gaussian_likelihood(self, x: float, mean: float,
                              std: float) -> float:
        """Gaussian probability density (unnormalised likelihood)."""
        std = max(std, 1e-6)
        return float(np.exp(-0.5 * ((x - mean) / std) ** 2))

    def _score_regime(self, features: Dict, regime: str) -> float:
        """Score how well features match a regime profile."""
        profile = self.regime_profiles[regime]

        # Blend short and long return for more robust trend signal
        # (20-day return alone is too noisy; combine with 60-day)
        blended_ret = 0.5 * features["ret_short"] + 0.5 * (features["ret_long"] / 3)

        l1 = self._gaussian_likelihood(
            blended_ret, profile["ret_short_mean"],
            profile["ret_short_std"]
        )
        l2 = self._gaussian_likelihood(
            features["vol"], profile["vol_mean"], profile["vol_std"]
        )
        l3 = self._gaussian_likelihood(
            features["drawdown"], profile["drawdown_mean"], 0.08
        )
        l4 = self._gaussian_likelihood(
            features["skew"], profile["skew_mean"], 0.5
        )

        # Weighted product (in log space for stability)
        log_score = (
            2.0 * np.log(l1 + 1e-12) +   # return direction — most important
            1.5 * np.log(l2 + 1e-12) +   # volatility level
            1.5 * np.log(l3 + 1e-12) +   # drawdown — crisis detector
            1.0 * np.log(l4 + 1e-12)     # skew — crash asymmetry
        )
        return float(log_score)

    def classify(self, returns: pd.Series) -> RegimeState:
        """
        Classify the current market regime from a return series.

        Args:
            returns: pd.Series of daily returns, most recent last

        Returns:
            RegimeState with regime, confidence, and probabilities
        """
        features = self._extract_features(returns)

        # Score each regime
        scores = {
            regime: self._score_regime(features, regime)
            for regime in REGIMES
        }

        # Convert log-scores to probabilities (softmax)
        max_score = max(scores.values())
        exp_scores = {r: np.exp(s - max_score) for r, s in scores.items()}
        total = sum(exp_scores.values())
        probabilities = {r: float(v / total) for r, v in exp_scores.items()}

        # Hard override: extreme drawdown always triggers CRISIS check
        if features["drawdown"] < -0.15 and features["vol"] > 0.30:
            probabilities["CRISIS"] = max(probabilities["CRISIS"], 0.6)
            total = sum(probabilities.values())
            probabilities = {r: v/total for r, v in probabilities.items()}

        regime = max(probabilities, key=probabilities.get)
        confidence = probabilities[regime]

        # Track regime history for persistence calculation
        self._history.append(regime)
        if len(self._history) > 100:
            self._history.pop(0)

        days_in_regime = 0
        for r in reversed(self._history):
            if r == regime:
                days_in_regime += 1
            else:
                break

        # Transition risk: high vol-of-vol + low confidence = unstable regime
        transition_risk = float(np.clip(
            features["vol_of_vol"] * 3 + (1 - confidence) * 0.5,
            0, 1
        ))

        return RegimeState(
            regime=regime,
            confidence=round(confidence, 3),
            probabilities={r: round(p, 3) for r, p in probabilities.items()},
            days_in_regime=days_in_regime,
            transition_risk=round(transition_risk, 3),
            description=REGIME_DESCRIPTIONS[regime],
        )

    def classify_from_signals(self, vix: float, nifty_pct_5d: float,
                              drawdown_pct: float,
                              yield_spread: float = 0.5) -> RegimeState:
        """
        Convenience method: classify regime directly from common
        market signals (when full return series unavailable).
        """
        # Build a synthetic return series matching the signal profile
        rng = np.random.default_rng(42)
        n = self.lookback_long

        daily_vol = vix / 100 / np.sqrt(252)
        daily_drift = nifty_pct_5d / 100 / 5

        synthetic = pd.Series(
            rng.normal(daily_drift, daily_vol, n)
        )
        # Inject the actual drawdown into the tail
        if drawdown_pct < -5:
            synthetic.iloc[-5:] -= abs(drawdown_pct) / 100 / 5

        return self.classify(synthetic)


if __name__ == "__main__":
    print("=" * 55)
    print("  AGENT 1: REGIME DETECTION")
    print("=" * 55)

    agent = RegimeDetectionAgent()

    # Test scenarios
    scenarios = {
        "Bull market":     pd.Series(np.random.default_rng(1).normal(0.001, 0.008, 60)),
        "Bear market":     pd.Series(np.random.default_rng(2).normal(-0.0015, 0.015, 60)),
        "Sideways":        pd.Series(np.random.default_rng(3).normal(0.0001, 0.009, 60)),
        "Crisis (crash)":  pd.Series(
            list(np.random.default_rng(4).normal(0.0005, 0.01, 50)) +
            [-0.04, -0.06, -0.03, -0.05, -0.08, -0.02, -0.04, -0.03, -0.05, -0.06]
        ),
    }

    for name, returns in scenarios.items():
        state = agent.classify(returns)
        print(f"\n{name}:")
        print(f"  {REGIME_COLORS[state.regime]} Regime: {state.regime} "
              f"(confidence: {state.confidence*100:.0f}%)")
        print(f"  Description: {state.description}")
        print(f"  Probabilities: " + " | ".join(
            f"{r}:{p*100:.0f}%" for r, p in state.probabilities.items()
        ))
        print(f"  Transition risk: {state.transition_risk*100:.0f}%")
