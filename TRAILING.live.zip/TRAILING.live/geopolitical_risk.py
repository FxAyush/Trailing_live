"""
geopolitical_risk.py
--------------------
Causal geopolitical-risk module for TRAILING.live.

Design:
1) HISTORICAL / MODEL FEATURES
   - Official AI-GPR daily index from Iacoviello & Tong (2026), when available.
   - Real market transmission channels from Yahoo Finance:
       Brent crude, gold, USD index.
   - All rolling features are causal (past/current data only).
   - No random values, no known-crisis-date injection, no backward fill.

2) LIVE NEWS OVERLAY (DIAGNOSTIC / EXPLANATION)
   - Optional GDELT DOC 2.0 queries for current conflict/Hormuz coverage.
   - This overlay is NOT inserted into the ML feature matrix by default,
     because a comparable full 2007-present historical GDELT feature has not
     been backfilled. That prevents train/live leakage or distribution mismatch.

This module is intentionally conservative. If a source fails, it reports the
failure and does not fabricate a geopolitical reading.
"""

from __future__ import annotations

import io
import hashlib
import json
import os
import re
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from urllib.error import HTTPError, URLError
from dataclasses import dataclass, asdict
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd

AI_GPR_DAILY_URL = (
    "https://www.matteoiacoviello.com/ai_gpr_files/ai_gpr_data_daily.csv"
)

GDELT_DOC_URL = "https://api.gdeltproject.org/api/v2/doc/doc"

CACHE_DIR = Path(".trailing_cache")
GPR_CACHE = CACHE_DIR / "ai_gpr_data_daily.csv"
MARKET_CACHE = CACHE_DIR / "geopolitical_market_channels.csv"

# Yahoo Finance market transmission channels.
GEO_MARKET_TICKERS = {
    "brent": "BZ=F",
    "gold": "GC=F",
    "usd_index": "DX-Y.NYB",
}

# Historical model features produced by this module.
GEO_MODEL_COLUMNS = [
    # Raw historical geopolitical levels.
    "gpr_ai",
    "gpr_threats",
    "gpr_acts",
    "gpr_oil",

    # Causal normalization/change/acceleration features.
    "gpr_ai_z252",
    "gpr_threats_z252",
    "gpr_acts_z252",
    "gpr_oil_z252",
    "gpr_ai_logchg5",
    "gpr_ai_logchg20",
    "gpr_threats_logchg5",
    "gpr_acts_logchg5",
    "gpr_oil_logchg5",
    "gpr_ai_accel",
    "gpr_threats_accel",
    "gpr_acts_accel",
    "gpr_oil_accel",

    # Real market transmission channels.
    "brent_roc5",
    "brent_vol20",
    "gold_roc5",
    "usd_index_roc5",
    "geo_market_stress",
]


@dataclass
class GeoSourceStatus:
    ai_gpr_available: bool = False
    ai_gpr_last_date: Optional[str] = None
    ai_gpr_age_days: Optional[int] = None
    market_channels_available: bool = False
    gdelt_available: bool = False
    note: str = ""


def _ensure_cache_dir():
    CACHE_DIR.mkdir(parents=True, exist_ok=True)


def _download_text(url: str, timeout: int = 30) -> str:
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "TRAILING.live research client/1.0",
            "Accept": "text/csv,text/plain,*/*",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()
    return raw.decode("utf-8-sig", errors="replace")


def _normalise_name(name: str) -> str:
    return (
        str(name)
        .strip()
        .lower()
        .replace("-", "_")
        .replace(" ", "_")
        .replace(".", "_")
        .replace("/", "_")
    )


def _find_date_column(df: pd.DataFrame) -> str:
    norm = {_normalise_name(c): c for c in df.columns}
    preferred = [
        "date",
        "day",
        "datetime",
        "observation_date",
        "date_daily",
    ]
    for p in preferred:
        if p in norm:
            return norm[p]

    # Heuristic: pick a column that parses mostly as dates.
    for c in df.columns:
        parsed = pd.to_datetime(df[c], errors="coerce")
        if parsed.notna().mean() > 0.90:
            return c

    raise ValueError("Could not identify a date column in AI-GPR CSV.")


def _pick_series_column(
    df: pd.DataFrame,
    required_tokens: Tuple[str, ...],
    excluded_tokens: Tuple[str, ...] = (),
) -> Optional[str]:
    """
    Find a numeric AI-GPR column robustly across possible publisher naming changes.
    """
    candidates = []
    for c in df.columns:
        n = _normalise_name(c)
        if all(tok in n for tok in required_tokens) and not any(
            tok in n for tok in excluded_tokens
        ):
            numeric_ratio = pd.to_numeric(df[c], errors="coerce").notna().mean()
            if numeric_ratio > 0.50:
                candidates.append((c, n))

    if not candidates:
        return None

    # Prefer shorter / simpler names.
    candidates.sort(key=lambda x: (len(x[1]), x[1]))
    return candidates[0][0]


def _map_ai_gpr_columns(df: pd.DataFrame) -> Dict[str, Optional[str]]:
    """
    Robust aliases for the official daily file.

    We intentionally return None when a component cannot be identified rather
    than creating a synthetic substitute.
    """
    norm_map = {_normalise_name(c): c for c in df.columns}

    aliases = {
        "gpr_ai": [
            "gpr_ai",
            "ai_gpr",
            "gpr",
        ],
        "gpr_threats": [
            "gpr_threats",
            "gpr_ai_threats",
            "ai_gpr_threats",
            "gprt",
        ],
        "gpr_acts": [
            "gpr_acts",
            "gpr_ai_acts",
            "ai_gpr_acts",
            "gpra",
        ],
        "gpr_oil": [
            "gpr_oil",
            "oil_gpr",
            "gpr_ai_oil",
            "ai_gpr_oil",
        ],
    }

    out: Dict[str, Optional[str]] = {}

    for target, opts in aliases.items():
        found = None
        for a in opts:
            if a in norm_map:
                found = norm_map[a]
                break

        if found is None:
            if target == "gpr_threats":
                found = _pick_series_column(df, ("gpr", "threat"))
            elif target == "gpr_acts":
                found = _pick_series_column(df, ("gpr", "act"))
            elif target == "gpr_oil":
                found = _pick_series_column(df, ("gpr", "oil"))
            elif target == "gpr_ai":
                # Avoid accidentally choosing threats/acts/oil as the main index.
                found = _pick_series_column(
                    df,
                    ("gpr",),
                    ("threat", "act", "oil", "original", "country", "event"),
                )

        out[target] = found

    return out


def load_ai_gpr_daily(
    start: Optional[str] = None,
    end: Optional[str] = None,
    use_cache: bool = True,
    max_cache_age_hours: int = 24,
) -> Tuple[pd.DataFrame, Dict]:
    """
    Load official daily AI-GPR data.

    The publisher currently updates the dataset periodically rather than
    necessarily every market day. We forward-fill past published observations
    when aligning later, but we never back-fill future observations.
    """
    _ensure_cache_dir()

    use_existing = False
    if use_cache and GPR_CACHE.exists():
        age_hours = (time.time() - GPR_CACHE.stat().st_mtime) / 3600.0
        use_existing = age_hours <= max_cache_age_hours

    source = "cache"
    if use_existing:
        text = GPR_CACHE.read_text(encoding="utf-8", errors="replace")
    else:
        try:
            text = _download_text(AI_GPR_DAILY_URL)
            GPR_CACHE.write_text(text, encoding="utf-8")
            source = "official_download"
        except Exception as exc:
            if GPR_CACHE.exists():
                text = GPR_CACHE.read_text(encoding="utf-8", errors="replace")
                source = "stale_cache"
            else:
                raise RuntimeError(
                    "AI-GPR download failed and no cached copy exists. "
                    f"Original error: {exc}"
                ) from exc

    raw = pd.read_csv(io.StringIO(text))
    if raw.empty:
        raise RuntimeError("AI-GPR CSV is empty.")

    date_col = _find_date_column(raw)
    dates = pd.to_datetime(raw[date_col], errors="coerce")

    mapping = _map_ai_gpr_columns(raw)

    out = pd.DataFrame(index=pd.DatetimeIndex(dates).tz_localize(None))

    for target, source_col in mapping.items():
        if source_col is not None:
            out[target] = pd.to_numeric(raw[source_col], errors="coerce").values

    out = out[~out.index.isna()]
    out = out[~out.index.duplicated(keep="last")].sort_index()

    # Only keep components with enough real observations.
    keep = [
        c for c in out.columns
        if out[c].notna().sum() >= max(30, int(len(out) * 0.20))
    ]
    out = out[keep]

    if start:
        out = out.loc[out.index >= pd.Timestamp(start)]
    if end:
        out = out.loc[out.index <= pd.Timestamp(end)]

    meta = {
        "source": source,
        "publisher_url": AI_GPR_DAILY_URL,
        "column_mapping": mapping,
        "available_columns": list(out.columns),
        "last_date": (
            out.dropna(how="all").index.max().strftime("%Y-%m-%d")
            if not out.dropna(how="all").empty
            else None
        ),
    }

    return out, meta


def _download_yahoo_close(
    tickers: Dict[str, str],
    start: str,
    end: Optional[str],
) -> pd.DataFrame:
    import yfinance as yf

    series = {}

    for name, ticker in tickers.items():
        try:
            df = yf.download(
                ticker,
                start=start,
                end=end,
                auto_adjust=True,
                progress=False,
                actions=False,
                threads=False,
            )

            if df is None or df.empty:
                continue

            close = df["Close"]
            if isinstance(close, pd.DataFrame):
                close = close.iloc[:, 0]

            close = pd.to_numeric(close, errors="coerce").dropna()
            close.index = pd.DatetimeIndex(close.index).tz_localize(None)
            series[name] = close

        except Exception:
            continue

    if not series:
        raise RuntimeError("No geopolitical market-channel prices downloaded.")

    return pd.concat(series, axis=1).sort_index()


def _causal_zscore(
    s: pd.Series,
    window: int = 252,
    min_periods: int = 60,
) -> pd.Series:
    mean = s.rolling(window, min_periods=min_periods).mean()
    std = s.rolling(window, min_periods=min_periods).std()
    return (s - mean) / std.replace(0, np.nan)


def _add_causal_gpr_dynamics(gpr: pd.DataFrame) -> pd.DataFrame:
    """
    Add causal geopolitical dynamics without using future information.

    log1p differences are used instead of pct_change because GPR series are
    non-negative and percentage changes can explode when the prior level is
    small. Acceleration compares the recent 5-day move with the average
    5-day pace implied by the 20-day move.
    """
    if gpr is None or gpr.empty:
        return gpr

    out = gpr.copy()

    for col in ("gpr_ai", "gpr_threats", "gpr_acts", "gpr_oil"):
        if col not in out.columns:
            continue

        s = pd.to_numeric(out[col], errors="coerce").clip(lower=0)

        out[f"{col}_z252"] = _causal_zscore(
            s,
            window=252,
            min_periods=60,
        )

        log_s = np.log1p(s)
        chg5 = log_s.diff(5)
        chg20 = log_s.diff(20)

        out[f"{col}_logchg5"] = chg5
        if col == "gpr_ai":
            out[f"{col}_logchg20"] = chg20

        out[f"{col}_accel"] = chg5 - (chg20 / 4.0)

    return out.replace([np.inf, -np.inf], np.nan)


def load_market_geopolitical_channels(
    start: str = "2007-01-01",
    end: Optional[str] = None,
) -> pd.DataFrame:
    """
    Real market-price channels through which geopolitical shocks can transmit.
    """
    px = _download_yahoo_close(GEO_MARKET_TICKERS, start, end)

    f = pd.DataFrame(index=px.index)

    if "brent" in px:
        brent_ret = px["brent"].pct_change()
        f["brent_roc5"] = px["brent"].pct_change(5)
        f["brent_vol20"] = brent_ret.rolling(20, min_periods=20).std() * np.sqrt(252)

    if "gold" in px:
        f["gold_roc5"] = px["gold"].pct_change(5)

    if "usd_index" in px:
        f["usd_index_roc5"] = px["usd_index"].pct_change(5)

    # Composite market stress. No future data and no fitted "crisis" weights.
    parts = []

    if "brent_roc5" in f:
        # Both sharp upward and downward oil moves can indicate geopolitical stress;
        # upward shocks matter more, so retain sign but emphasize positive moves.
        oil_z = _causal_zscore(f["brent_roc5"])
        parts.append(oil_z.clip(-3, 3))

    if "brent_vol20" in f:
        vol_z = _causal_zscore(f["brent_vol20"])
        parts.append(vol_z.clip(-3, 3))

    if "gold_roc5" in f:
        gold_z = _causal_zscore(f["gold_roc5"])
        parts.append(gold_z.clip(-3, 3))

    if "usd_index_roc5" in f:
        usd_z = _causal_zscore(f["usd_index_roc5"])
        parts.append(usd_z.clip(-3, 3))

    if parts:
        # Equal-weight engineering prior; not optimized against crash labels.
        f["geo_market_stress"] = pd.concat(parts, axis=1).mean(axis=1)

    return f.replace([np.inf, -np.inf], np.nan)


def load_geopolitical_features(
    start: str = "2007-01-01",
    end: Optional[str] = None,
    target_index: Optional[pd.DatetimeIndex] = None,
    use_cache: bool = True,
) -> Tuple[pd.DataFrame, Dict]:
    """
    Return causal daily geopolitical model features.

    If target_index is supplied, values are aligned to that index with forward
    fill only. There is intentionally NO backward fill.
    """
    gpr = pd.DataFrame()
    gpr_meta = {}
    errors = []

    try:
        gpr, gpr_meta = load_ai_gpr_daily(start=start, end=end, use_cache=use_cache)
        gpr = _add_causal_gpr_dynamics(gpr)
    except Exception as exc:
        errors.append(f"AI-GPR unavailable: {exc}")

    market = pd.DataFrame()
    try:
        market = load_market_geopolitical_channels(start=start, end=end)
    except Exception as exc:
        errors.append(f"Market geo channels unavailable: {exc}")

    if gpr.empty and market.empty:
        raise RuntimeError(
            "No geopolitical feature sources are available. " + " | ".join(errors)
        )

    combined = pd.concat([gpr, market], axis=1).sort_index()

    if target_index is not None:
        idx = pd.DatetimeIndex(target_index).tz_localize(None)
        # Union before ffill ensures the latest prior observation is usable.
        combined = combined.reindex(combined.index.union(idx)).sort_index().ffill()
        combined = combined.reindex(idx)

    meta = {
        "ai_gpr": gpr_meta,
        "errors": errors,
        "columns": list(combined.columns),
    }

    if not gpr.empty:
        last_gpr = gpr.dropna(how="all").index.max()
        reference = (
            pd.DatetimeIndex(target_index).max()
            if target_index is not None and len(target_index)
            else pd.Timestamp.today().normalize()
        )
        meta["ai_gpr_age_days"] = int((reference.normalize() - last_gpr.normalize()).days)

    return combined, meta


def augment_signals_with_geopolitical(
    signals: pd.DataFrame,
    use_cache: bool = True,
) -> Tuple[pd.DataFrame, Dict]:
    """
    Add geopolitical features to the existing TRAILING.live signal DataFrame.

    Existing signal columns are preserved unchanged.
    """
    signals = signals.sort_index().copy()

    start = (signals.index.min() - pd.Timedelta(days=10)).strftime("%Y-%m-%d")
    end = (signals.index.max() + pd.Timedelta(days=5)).strftime("%Y-%m-%d")

    geo, meta = load_geopolitical_features(
        start=start,
        end=end,
        target_index=signals.index,
        use_cache=use_cache,
    )

    # Do not inject all-NaN columns.
    geo = geo.loc[:, geo.notna().any(axis=0)]

    augmented = pd.concat([signals, geo], axis=1)

    # Causal forward fill only. Leave unresolved warm-up NaNs for training to drop.
    augmented = augmented.ffill()

    return augmented, meta



# ---------------------------------------------------------------------------
# GOOGLE NEWS RSS FALLBACK / PRIMARY LIVE HEADLINES
# ---------------------------------------------------------------------------

GOOGLE_NEWS_RSS = "https://news.google.com/rss/search"

# Queries are deliberately specific so "trade war", sports-war metaphors, etc.
# are less likely to pollute geopolitical coverage.
LIVE_NEWS_QUERIES = {
    "global_conflict_coverage": (
        '("military strike" OR missile OR airstrike OR drone attack OR '
        'armed conflict OR sanctions OR nuclear threat)'
    ),
    "middle_east_coverage": (
        '((Iran OR Israel OR "United States" OR U.S.) AND '
        '(war OR missile OR strike OR military OR sanctions OR nuclear))'
    ),
    "hormuz_coverage": (
        '("Strait of Hormuz" OR Hormuz) '
        '(shipping OR tanker OR oil OR blockade OR closure OR disruption OR attack)'
    ),
    "energy_disruption_coverage": (
        '((oil OR crude OR LNG OR tanker OR shipping OR refinery) AND '
        '(war OR attack OR blockade OR disruption OR Hormuz OR sanctions))'
    ),
}

# Transparent rule-based taxonomy for the LIVE explanation layer.
# It is intentionally NOT trained against market-crash labels.
EVENT_RULES = {
    "military_escalation": {
        "positive": [
            r"\bairstrike(s)?\b", r"\bmissile(s)?\b", r"\bdrone(s)?\b",
            r"\bbomb(ing|ed|s)?\b", r"\battack(s|ed|ing)?\b",
            r"\bstrike(s|d)?\b", r"\bretaliat(e|ion|ory)\b",
            r"\binvasion\b", r"\bescalat(e|ion|es|ed|ing)\b",
            r"\bmilitary operation\b", r"\bwar spreads?\b",
        ],
        "weight": 8.0,
    },
    "shipping_disruption": {
        "positive": [
            r"\bstrait of hormuz\b", r"\bhormuz\b", r"\bblockade\b",
            r"\bshipping disruption\b", r"\btanker(s)?\b",
            r"\bvessel(s)?\b", r"\bport closure\b", r"\bshipping halted\b",
            r"\bshipping slows?\b", r"\bshipping route(s)?\b",
        ],
        "weight": 7.0,
    },
    "energy_disruption": {
        "positive": [
            r"\boil\b", r"\bcrude\b", r"\blng\b", r"\brefinery\b",
            r"\bpipeline\b", r"\benergy supply\b", r"\benergy costs?\b",
            r"\boil rises?\b", r"\boil surge(s|d)?\b",
        ],
        "weight": 5.0,
    },
    "sanctions": {
        "positive": [
            r"\bsanction(s|ed|ing)?\b", r"\beconomic squeeze\b",
            r"\bembargo\b", r"\bexport controls?\b",
        ],
        "weight": 3.0,
    },
    "nuclear_risk": {
        "positive": [
            r"\bnuclear\b", r"\benrichment\b", r"\buranium\b",
            r"\bnuclear facility\b", r"\bnuclear programme\b",
            r"\bnuclear program\b",
        ],
        "weight": 6.0,
    },
}

# Phrases that indicate de-escalation. These reduce the diagnostic score.
DEESCALATION_PATTERNS = [
    r"\bceasefire\b",
    r"\bpeace talks?\b",
    r"\btruce\b",
    r"\bde[- ]escalat(e|ion|es|ed|ing)\b",
    r"\bdiplomatic breakthrough\b",
    r"\bagreement reached\b",
    r"\bhostilities end\b",
    r"\bwar ends?\b",
    r"\bwithdraw(s|al|ing)?\b",
    r"\btalks resume\b",
    r"\bnegotiations resume\b",
]

# Headlines from these publishers receive a modest reliability boost in the
# diagnostic score. Unlisted publishers are still accepted.
HIGH_QUALITY_SOURCES = {
    "Reuters", "Associated Press", "AP News", "Bloomberg", "Financial Times",
    "The Wall Street Journal", "BBC", "BBC News", "CNBC", "NPR",
    "The New York Times", "The Washington Post", "The Economist",
}


def _parse_published(value: Optional[str]) -> Optional[pd.Timestamp]:
    if not value:
        return None
    try:
        ts = pd.Timestamp(value)
        if ts.tzinfo is None:
            ts = ts.tz_localize("UTC")
        else:
            ts = ts.tz_convert("UTC")
        return ts
    except Exception:
        return None


def _google_news_rss(
    query: str,
    max_items: int = 20,
    timeout: int = 20,
) -> Dict:
    """
    Fetch current headlines from Google News RSS.

    This is used only for the live explanation/diagnostic layer and is not
    inserted into the historical ML feature matrix.
    """
    params = {
        "q": query,
        "hl": "en-US",
        "gl": "US",
        "ceid": "US:en",
    }
    url = GOOGLE_NEWS_RSS + "?" + urllib.parse.urlencode(params)

    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 TRAILING.live/1.0",
            "Accept": "application/rss+xml,application/xml,text/xml,*/*",
        },
    )

    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()

    root = ET.fromstring(raw)

    articles = []
    for item in root.findall(".//item")[:max_items]:
        title = (item.findtext("title") or "").strip()
        link = (item.findtext("link") or "").strip()
        pub = (item.findtext("pubDate") or "").strip()
        source_el = item.find("source")
        source = (source_el.text or "").strip() if source_el is not None else None

        published_iso = None
        if pub:
            try:
                published_iso = parsedate_to_datetime(pub).astimezone().isoformat()
            except Exception:
                published_iso = pub

        if title:
            articles.append(
                {
                    "title": title,
                    "source": source,
                    "published": published_iso,
                    "link": link,
                }
            )

    return {
        "provider": "Google News RSS",
        "query": query,
        "count": len(articles),
        "articles": articles,
        "url": url,
        "status": "ok" if articles else "empty",
    }


def _dedupe_articles(articles):
    """
    De-duplicate near-identical headlines across multiple live queries.
    """
    seen = set()
    unique = []

    for a in articles:
        title = re.sub(r"\s+", " ", (a.get("title") or "").strip().lower())
        if not title:
            continue

        # Remove trailing publisher suffix for a more stable dedupe key.
        normalized = re.sub(r"\s+-\s+[^-]{2,80}$", "", title).strip()
        key = hashlib.sha1(normalized.encode("utf-8")).hexdigest()

        if key not in seen:
            seen.add(key)
            unique.append(a)

    return unique


def _filter_fresh_articles(
    articles,
    now: Optional[pd.Timestamp] = None,
    max_age_days: int = 7,
):
    """
    Keep only recent articles and attach deterministic age metadata.
    """
    if now is None:
        now = pd.Timestamp.now(tz="UTC")
    elif now.tzinfo is None:
        now = now.tz_localize("UTC")
    else:
        now = now.tz_convert("UTC")

    out = []
    max_age = pd.Timedelta(days=max_age_days)

    for a in articles:
        ts = _parse_published(a.get("published"))
        if ts is None:
            continue

        age = now - ts
        if age < pd.Timedelta(0):
            # Clock/source anomaly. Do not treat future timestamps as fresh evidence.
            continue

        if age <= max_age:
            b = dict(a)
            b["age_hours"] = round(age.total_seconds() / 3600.0, 2)
            out.append(b)

    out.sort(key=lambda x: x.get("age_hours", 1e9))
    return out


def _classify_headline(title: str) -> Dict:
    """
    Transparent event classification for one headline.
    """
    text = (title or "").lower()

    categories = {}
    weighted_positive = 0.0

    for category, cfg in EVENT_RULES.items():
        matches = []
        for pattern in cfg["positive"]:
            if re.search(pattern, text, flags=re.I):
                matches.append(pattern)

        hit = len(matches) > 0
        categories[category] = {
            "hit": hit,
            "matches": matches,
            "weight": cfg["weight"] if hit else 0.0,
        }

        if hit:
            weighted_positive += cfg["weight"]

    deesc_matches = [
        pattern for pattern in DEESCALATION_PATTERNS
        if re.search(pattern, text, flags=re.I)
    ]

    deescalation = bool(deesc_matches)

    # One headline cannot contribute an unlimited amount of risk.
    raw = min(weighted_positive, 18.0)

    if deescalation:
        raw -= 10.0

    return {
        "categories": categories,
        "deescalation": deescalation,
        "deescalation_matches": deesc_matches,
        "raw_event_score": raw,
    }


def _recency_weight(age_hours: float) -> float:
    """
    Smooth deterministic recency decay.

    ~1.0 now, ~0.78 at 24h, ~0.47 at 72h, ~0.18 at 7d.
    """
    if age_hours is None:
        return 0.0
    return float(np.exp(-max(0.0, age_hours) / 96.0))


def _score_live_geopolitical_articles(articles) -> Dict:
    """
    Produce a transparent 0-100 LIVE geopolitical diagnostic score.

    This is not a market crash probability and is not fed into the trained
    model. It summarizes current headline evidence for the Explanation Agent.
    """
    if not articles:
        return {
            "score": None,
            "level": "UNKNOWN",
            "article_count": 0,
            "last_24h": 0,
            "last_72h": 0,
            "last_7d": 0,
            "event_counts": {},
            "deescalation_count": 0,
            "explanation": "No sufficiently fresh geopolitical headlines available.",
        }

    event_counts = {k: 0 for k in EVENT_RULES}
    deesc_count = 0
    contributions = []
    last_24h = 0
    last_72h = 0

    analyzed = []

    for a in articles:
        age = float(a.get("age_hours", 9999.0))
        if age <= 24:
            last_24h += 1
        if age <= 72:
            last_72h += 1

        cls = _classify_headline(a.get("title", ""))

        for category, info in cls["categories"].items():
            if info["hit"]:
                event_counts[category] += 1

        if cls["deescalation"]:
            deesc_count += 1

        source = a.get("source")
        source_weight = 1.10 if source in HIGH_QUALITY_SOURCES else 1.0
        recency = _recency_weight(age)

        contribution = cls["raw_event_score"] * recency * source_weight
        contributions.append(contribution)

        analyzed.append(
            {
                **a,
                "classification": cls,
                "recency_weight": round(recency, 4),
                "source_weight": source_weight,
                "risk_contribution": round(float(contribution), 3),
            }
        )

    # Base score from article evidence.
    evidence_score = float(np.clip(sum(contributions), 0.0, 100.0))

    # Breadth bonus rewards several independent fresh stories but is bounded.
    breadth_bonus = min(12.0, 1.5 * min(last_24h, 8))

    # De-escalation reduces the aggregate score beyond per-headline subtraction.
    deesc_penalty = min(20.0, 4.0 * deesc_count)

    score = float(np.clip(evidence_score + breadth_bonus - deesc_penalty, 0.0, 100.0))

    if score < 20:
        level = "LOW"
    elif score < 40:
        level = "ELEVATED"
    elif score < 65:
        level = "HIGH"
    else:
        level = "CRITICAL"

    analyzed.sort(key=lambda x: x.get("risk_contribution", 0.0), reverse=True)

    return {
        "score": round(score, 1),
        "level": level,
        "article_count": len(articles),
        "last_24h": last_24h,
        "last_72h": last_72h,
        "last_7d": len(articles),
        "event_counts": event_counts,
        "deescalation_count": deesc_count,
        "top_risk_headlines": analyzed[:10],
        "explanation": (
            "Rule-based live geopolitical diagnostic. "
            "Not a trained crash probability and not an ML model input."
        ),
    }


def get_google_news_overlay(
    max_age_days: int = 7,
) -> Dict:
    """
    Current geopolitical headlines with freshness filtering and event scoring.
    """
    result = {
        "source": "Google News RSS",
        "model_input": False,
        "reason": (
            "Current-headline overlay only. Historical AI-GPR and market "
            "transmission variables remain the geopolitical ML inputs."
        ),
        "queries": {},
        "errors": [],
    }

    all_articles = []

    for name, query in LIVE_NEWS_QUERIES.items():
        try:
            item = _google_news_rss(query)
            result["queries"][name] = item
            all_articles.extend(item.get("articles", []))
        except Exception as exc:
            result["queries"][name] = {
                "provider": "Google News RSS",
                "query": query,
                "status": "unavailable",
                "error": str(exc),
                "articles": [],
            }
            result["errors"].append(f"{name}: {exc}")

    unique = _dedupe_articles(all_articles)
    fresh = _filter_fresh_articles(unique, max_age_days=max_age_days)

    result["raw_unique_headline_count"] = len(unique)
    result["fresh_headline_count"] = len(fresh)
    result["freshness_window_days"] = max_age_days
    result["live_geopolitical_risk"] = _score_live_geopolitical_articles(fresh)
    result["top_headlines"] = fresh[:20]

    return result



# ---------------------------------------------------------------------------
# GDELT LIVE NEWS OVERLAY
# ---------------------------------------------------------------------------

def _gdelt_timeline_volume(
    query: str,
    timespan: str = "7d",
    timeout: int = 20,
    max_retries: int = 4,
    base_backoff_seconds: float = 3.0,
) -> Dict:
    """
    Query one GDELT DOC timeline with retry/backoff.

    Handles HTTP 429 by waiting and retrying. If GDELT sends a Retry-After
    header, that value is respected. Other transient HTTP/network errors also
    get a small exponential backoff.
    """
    params = {
        "query": query,
        "mode": "timelinevol",
        "format": "json",
        "timespan": timespan,
        "timelinesmooth": "0",
    }
    url = GDELT_DOC_URL + "?" + urllib.parse.urlencode(params)

    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "TRAILING.live research client/1.0",
            "Accept": "application/json,text/plain,*/*",
        },
    )

    last_error = None

    for attempt in range(max_retries + 1):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                payload = json.loads(
                    r.read().decode("utf-8", errors="replace")
                )
            break

        except HTTPError as exc:
            last_error = exc

            if exc.code == 429 and attempt < max_retries:
                retry_after = exc.headers.get("Retry-After")
                try:
                    wait = float(retry_after) if retry_after else None
                except Exception:
                    wait = None

                if wait is None:
                    wait = base_backoff_seconds * (2 ** attempt)

                # Small deterministic cap so one run cannot hang for minutes.
                wait = min(wait, 45.0)

                print(
                    f"  GDELT rate limited (429). "
                    f"Retrying in {wait:.1f}s "
                    f"[attempt {attempt+1}/{max_retries}]..."
                )
                time.sleep(wait)
                continue

            # Retry common transient server errors.
            if exc.code in (500, 502, 503, 504) and attempt < max_retries:
                wait = min(base_backoff_seconds * (2 ** attempt), 30.0)
                print(
                    f"  GDELT HTTP {exc.code}. "
                    f"Retrying in {wait:.1f}s..."
                )
                time.sleep(wait)
                continue

            raise

        except (URLError, TimeoutError) as exc:
            last_error = exc
            if attempt < max_retries:
                wait = min(base_backoff_seconds * (2 ** attempt), 30.0)
                print(
                    f"  GDELT network error. "
                    f"Retrying in {wait:.1f}s..."
                )
                time.sleep(wait)
                continue
            raise

    else:
        raise RuntimeError(f"GDELT request failed: {last_error}")

    # GDELT has used more than one JSON shape over time.
    timeline = payload.get("timeline", payload.get("data", []))

    points = []

    if isinstance(timeline, list):
        for block in timeline:
            if (
                isinstance(block, dict)
                and "data" in block
                and isinstance(block["data"], list)
            ):
                for p in block["data"]:
                    if isinstance(p, dict):
                        points.append(p)
            elif isinstance(block, dict):
                points.append(block)

    values = []
    for p in points:
        val = None
        for key in ("value", "volume", "norm", "count"):
            if key in p:
                try:
                    val = float(p[key])
                    break
                except Exception:
                    pass

        if val is not None and np.isfinite(val):
            values.append(val)

    return {
        "query": query,
        "timespan": timespan,
        "latest": values[-1] if values else None,
        "mean": float(np.mean(values)) if values else None,
        "max": float(np.max(values)) if values else None,
        "points": len(values),
        "url": url,
        "status": "ok",
    }


def get_live_news_overlay(
    inter_request_delay: float = 3.0,
    max_retries: int = 1,
    max_age_days: int = 7,
) -> Dict:
    """
    Final multi-source live geopolitical overlay.

    Google News RSS is the primary live headline source.
    GDELT is secondary/optional because its public DOC API can rate-limit.

    Neither live-news source is fed into the trained crash model until a
    like-for-like historical feature is backfilled.
    """
    combined = {
        "model_input": False,
        "reason": (
            "Live-news diagnostics only. Historical AI-GPR and market "
            "transmission features are the geopolitical ML inputs."
        ),
        "google_news": None,
        "gdelt": None,
        "errors": [],
    }

    try:
        combined["google_news"] = get_google_news_overlay(
            max_age_days=max_age_days
        )
    except Exception as exc:
        combined["errors"].append(f"Google News RSS: {exc}")

    # GDELT is optional. Keep retries deliberately low so a 429 does not make
    # the application wait a long time when Google News is already available.
    try:
        queries = {
            "global_conflict_coverage": (
                '(war OR missile OR military OR attack OR sanctions OR nuclear)'
            ),
            "middle_east_coverage": (
                '(Iran OR Israel OR Lebanon OR Gaza OR "Persian Gulf" OR Hormuz)'
            ),
            "hormuz_coverage": (
                '("Strait of Hormuz" OR Hormuz)'
            ),
            "energy_disruption_coverage": (
                '((oil OR LNG OR tanker OR shipping) AND '
                '(war OR attack OR disruption OR blockade OR Hormuz))'
            ),
        }

        gdelt = {
            "source": "GDELT DOC 2.0",
            "model_input": False,
            "queries": {},
            "errors": [],
        }

        items = list(queries.items())

        for i, (name, query) in enumerate(items):
            try:
                gdelt["queries"][name] = _gdelt_timeline_volume(
                    query,
                    max_retries=max_retries,
                )
            except Exception as exc:
                gdelt["queries"][name] = {
                    "query": query,
                    "status": "unavailable",
                    "error": str(exc),
                }
                gdelt["errors"].append(f"{name}: {exc}")

            if i < len(items) - 1 and inter_request_delay > 0:
                time.sleep(inter_request_delay)

        combined["gdelt"] = gdelt

    except Exception as exc:
        combined["errors"].append(f"GDELT: {exc}")

    # Convenience summary for the Explanation Agent.
    gn = combined.get("google_news") or {}
    live_risk = gn.get("live_geopolitical_risk") or {}

    combined["summary"] = {
        "live_score": live_risk.get("score"),
        "live_level": live_risk.get("level"),
        "fresh_headlines": gn.get("fresh_headline_count"),
        "last_24h": live_risk.get("last_24h"),
        "last_72h": live_risk.get("last_72h"),
        "event_counts": live_risk.get("event_counts"),
        "deescalation_count": live_risk.get("deescalation_count"),
        "note": (
            "This is a live diagnostic score, not a market-crash probability."
        ),
    }

    return combined


def get_geopolitical_snapshot(
    signals: Optional[pd.DataFrame] = None,
    use_cache: bool = True,
    include_live_news: bool = True,
) -> Dict:
    """
    Human-readable current geopolitical snapshot for the Explanation Agent.
    """
    if signals is not None and len(signals):
        idx = signals.index
        start = (idx.min() - pd.Timedelta(days=10)).strftime("%Y-%m-%d")
        end = (idx.max() + pd.Timedelta(days=5)).strftime("%Y-%m-%d")
        geo, meta = load_geopolitical_features(
            start=start,
            end=end,
            target_index=idx,
            use_cache=use_cache,
        )
    else:
        today = pd.Timestamp.today().normalize()
        start = (today - pd.Timedelta(days=500)).strftime("%Y-%m-%d")
        geo, meta = load_geopolitical_features(
            start=start,
            end=None,
            target_index=None,
            use_cache=use_cache,
        )

    latest = {}
    if not geo.empty:
        row = geo.iloc[-1]
        for c, v in row.items():
            latest[c] = None if pd.isna(v) else float(v)

    out = {
        "latest_date": (
            geo.index.max().strftime("%Y-%m-%d") if not geo.empty else None
        ),
        "features": latest,
        "metadata": meta,
    }

    if include_live_news:
        out["live_news"] = get_live_news_overlay()
        out["live_geopolitical_risk"] = (
            out["live_news"].get("summary", {})
        )

    return out


# ---------------------------------------------------------------------------
# Standalone test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--start", default="2024-01-01")
    parser.add_argument("--no-news", action="store_true")
    args = parser.parse_args()

    print("Loading geopolitical features...")
    geo, meta = load_geopolitical_features(start=args.start)

    print(f"Rows: {len(geo)}")
    print(f"Columns: {list(geo.columns)}")
    print("\nLatest historical/model features:")
    print(geo.tail(1).T)

    print("\nMetadata:")
    print(json.dumps(meta, indent=2, default=str))

    if not args.no_news:
        print("\nLive geopolitical news overlay (diagnostic only):")
        overlay = get_live_news_overlay()

        summary = overlay.get("summary", {})
        print(
            f"  Live geopolitical risk: "
            f"{summary.get('live_score')} / 100 "
            f"({summary.get('live_level')})"
        )
        print(
            f"  Fresh headlines: {summary.get('fresh_headlines')} | "
            f"24h: {summary.get('last_24h')} | "
            f"72h: {summary.get('last_72h')}"
        )
        print(f"  Event counts: {summary.get('event_counts')}")
        print(
            f"  De-escalation headlines: "
            f"{summary.get('deescalation_count')}"
        )

        google = overlay.get("google_news") or {}
        risk = google.get("live_geopolitical_risk") or {}
        top = risk.get("top_risk_headlines", [])

        if top:
            print("\n  Top live geopolitical drivers:")
            for item in top[:5]:
                print(
                    f"    [{item.get('risk_contribution', 0):>5}] "
                    f"{item.get('title', '')}"
                )

        gdelt = overlay.get("gdelt") or {}
        if gdelt.get("errors"):
            print(
                "\n  GDELT note: some queries were unavailable/rate-limited; "
                "Google News remains the primary live source."
            )

        print("\nFull live-news diagnostic JSON:")
        print(json.dumps(overlay, indent=2, default=str))
