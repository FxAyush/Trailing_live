"""
portfolio_optimizer.py  (v2 — higher returns, lower CVaR, better Sharpe)
-------------------------------------------------------------------------
Key changes:
  1. Wider asset bounds — allows more equity in calm regimes
  2. Better objective: maximises Sharpe + penalises CVaR violation
  3. More diverse starting seeds — finds better optima
  4. Diversification bonus — prevents 100% concentration
  5. Target metrics:
       Calm:     CVaR -4% to -8%,  Sharpe 1.8-2.5
       Elevated: CVaR -6% to -10%, Sharpe 1.2-1.8
       Crisis:   CVaR -7% to -12%, Sharpe 0.8-1.4
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.optimize import minimize
from typing import Dict, Tuple
import warnings, os, sys
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from monte_carlo import MonteCarloEngine, mc_portfolio_returns, ASSET_CLASSES, N_ASSETS
from cvar_engine import CVaREngine

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ── Asset bounds by regime ──
# In calm markets: allow more equity
# In crisis: force defensive
BOUNDS_BY_REGIME = {
    "calm": [
        (0.05, 0.45),   # indian_equity    — higher floor + ceiling
        (0.00, 0.35),   # us_equity
        (0.00, 0.20),   # emerging_markets
        (0.05, 0.20),   # gold             — always some gold
        (0.05, 0.35),   # bonds_india
        (0.00, 0.30),   # bonds_us
        (0.00, 0.08),   # crypto           — small allowed
        (0.02, 0.12),   # cash
        (0.00, 0.12),   # commodities
    ],
    "elevated": [
        (0.02, 0.35),   # indian_equity
        (0.00, 0.28),   # us_equity
        (0.00, 0.15),   # emerging_markets
        (0.08, 0.22),   # gold             — higher floor
        (0.10, 0.38),   # bonds_india
        (0.05, 0.32),   # bonds_us
        (0.00, 0.05),   # crypto
        (0.03, 0.15),   # cash
        (0.00, 0.10),   # commodities
    ],
    "crisis": [
        (0.00, 0.15),   # indian_equity    — very limited
        (0.00, 0.12),   # us_equity
        (0.00, 0.08),   # emerging_markets
        (0.12, 0.28),   # gold             — high floor
        (0.18, 0.42),   # bonds_india      — high floor
        (0.12, 0.38),   # bonds_us         — high floor
        (0.00, 0.02),   # crypto           — near zero
        (0.05, 0.20),   # cash
        (0.00, 0.08),   # commodities
    ],
}

# Fallback bounds (used by safe_rl_agent)
BOUNDS = BOUNDS_BY_REGIME["elevated"]

# ── Regime seeds — warm start for optimizer ──
REGIME_SEEDS = {
    "calm": [
        np.array([0.35, 0.20, 0.10, 0.08, 0.12, 0.05, 0.04, 0.03, 0.03]),
        np.array([0.40, 0.15, 0.08, 0.10, 0.10, 0.05, 0.05, 0.04, 0.03]),
        np.array([0.30, 0.25, 0.08, 0.08, 0.12, 0.08, 0.03, 0.03, 0.03]),
    ],
    "elevated": [
        np.array([0.20, 0.12, 0.06, 0.12, 0.22, 0.15, 0.02, 0.07, 0.04]),
        np.array([0.15, 0.10, 0.05, 0.15, 0.25, 0.18, 0.01, 0.08, 0.03]),
        np.array([0.25, 0.10, 0.05, 0.10, 0.20, 0.18, 0.02, 0.06, 0.04]),
    ],
    "crisis": [
        np.array([0.05, 0.04, 0.02, 0.20, 0.32, 0.25, 0.00, 0.10, 0.02]),
        np.array([0.08, 0.03, 0.02, 0.22, 0.28, 0.24, 0.00, 0.10, 0.03]),
        np.array([0.03, 0.03, 0.01, 0.25, 0.35, 0.20, 0.00, 0.12, 0.01]),
    ],
}


class CVaROptimizer:
    """
    Finds the portfolio that maximises Sharpe ratio
    subject to CVaR constraint.

    Target:
      CVaR:   -7% to -12% (not worse than limit)
      Sharpe: 1.5 to 2.5
      Return: +0.8% to +1.8% monthly
    """

    def __init__(self, alpha: float = 0.05,
                 max_cvar: float = -0.10):
        self.alpha    = alpha
        self.max_cvar = max_cvar
        self.engine   = CVaREngine(alpha=alpha)

    def _stats(self, weights, scenarios):
        w = np.clip(weights, 0, 1); w /= w.sum() + 1e-8
        r  = mc_portfolio_returns(w, scenarios)
        tn = max(1, int(np.ceil(self.alpha * len(r))))
        cvar   = float(np.sort(r)[:tn].mean())
        exp    = float(r.mean())
        vol    = float(r.std()) + 1e-8
        sharpe = exp / vol * np.sqrt(12)
        return cvar, exp, sharpe

    def optimize(self, scenarios: np.ndarray,
                 regime: str = "elevated",
                 risk_tolerance: float = 0.5) -> Dict:

        bounds = BOUNDS_BY_REGIME.get(regime, BOUNDS_BY_REGIME["elevated"])
        seeds  = REGIME_SEEDS.get(regime, REGIME_SEEDS["elevated"])

        # Add random seeds for diversity
        rng = np.random.default_rng(42)
        for _ in range(3):
            w = rng.dirichlet(np.ones(N_ASSETS))
            w = np.clip(w, [b[0] for b in bounds],
                           [b[1] for b in bounds])
            w /= w.sum()
            seeds = seeds + [w]

        def objective(w):
            w = np.clip(w, 0, 1); w /= w.sum() + 1e-8
            r  = mc_portfolio_returns(w, scenarios)
            tn = max(1, int(np.ceil(self.alpha * len(r))))
            cvar   = float(np.sort(r)[:tn].mean())
            exp    = float(r.mean())
            vol    = float(r.std()) + 1e-8
            sharpe = exp / vol

            # Heavy penalty for CVaR violation
            cvar_pen = max(0, self.max_cvar - cvar) * 25

            # Concentration penalty — discourages single-asset dominance
            herfindahl = float(np.sum(w**2))
            conc_pen   = max(0, herfindahl - 0.20) * 3

            # Diversification bonus — rewards spreading across assets
            n_active   = float(np.sum(w > 0.03))
            div_bonus  = n_active * 0.002

            return -(risk_tolerance * sharpe
                     + (1 - risk_tolerance) * (-cvar / abs(self.max_cvar))
                     - cvar_pen - conc_pen + div_bonus)

        best_w, best_val = seeds[0].copy(), np.inf

        for w0 in seeds:
            w0 = np.clip(w0, [b[0] for b in bounds],
                             [b[1] for b in bounds])
            w0 /= w0.sum()
            try:
                res = minimize(
                    objective, w0,
                    method="SLSQP",
                    bounds=bounds,
                    constraints=[{"type":"eq","fun":lambda w:w.sum()-1}],
                    options={"maxiter":2000, "ftol":1e-10}
                )
                if res.success and res.fun < best_val:
                    best_val = res.fun
                    best_w   = res.x.copy()
            except Exception:
                continue

        weights = np.clip(best_w, 0, 1)
        weights /= weights.sum()

        cvar, exp_ret, sharpe = self._stats(weights, scenarios)

        # If CVaR still violated → force to safest seed
        if cvar < self.max_cvar:
            weights = np.array([0.00,0.00,0.00,0.22,0.35,0.28,0.00,0.12,0.03])
            weights /= weights.sum()
            cvar, exp_ret, sharpe = self._stats(weights, scenarios)

        return {
            "weights":       weights,
            "weights_named": dict(zip(ASSET_CLASSES, weights)),
            "cvar":          cvar,
            "expected_ret":  exp_ret,
            "sharpe":        sharpe,
            "is_safe":       cvar >= self.max_cvar,
            "regime":        regime,
            "max_cvar":      self.max_cvar,
        }


# ── RL Policy Network ──
class PolicyNetwork(nn.Module):
    def __init__(self, state_dim: int, hidden: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden), nn.LayerNorm(hidden), nn.Tanh(),
            nn.Linear(hidden, hidden),    nn.LayerNorm(hidden), nn.Tanh(),
            nn.Linear(hidden, N_ASSETS),  nn.Softplus(),
        )
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight, gain=0.1)
                nn.init.zeros_(m.bias)

    def forward(self, x):
        return self.net(x) + 1.0

    def get_weights(self, x, regime="elevated"):
        with torch.no_grad():
            conc = self.forward(x)
            w = (conc / conc.sum(-1, keepdim=True)).squeeze(0).cpu().numpy()
        bounds = BOUNDS_BY_REGIME.get(regime, BOUNDS_BY_REGIME["elevated"])
        lo = np.array([b[0] for b in bounds])
        hi = np.array([b[1] for b in bounds])
        w  = np.clip(w, lo, hi)
        w /= w.sum()
        return w


class StableRLTrainer:
    def __init__(self, state_dim, max_cvar=-0.10, alpha=0.05):
        self.policy    = PolicyNetwork(state_dim).to(DEVICE)
        self.optimizer = torch.optim.Adam(self.policy.parameters(), lr=1e-3)
        self.scheduler = torch.optim.lr_scheduler.StepLR(
            self.optimizer, step_size=50, gamma=0.7)
        self.max_cvar  = max_cvar
        self.alpha     = alpha
        self.stats     = []

    def _reward(self, w, scenarios):
        r  = mc_portfolio_returns(w, scenarios)
        tn = max(1, int(np.ceil(self.alpha * len(r))))
        cvar   = float(np.sort(r)[:tn].mean())
        exp    = float(r.mean())
        vol    = float(r.std()) + 1e-8
        sharpe = exp / vol
        cvar_pen  = min(0, (cvar - self.max_cvar)) * 12
        herfindahl = float(np.sum(w**2))
        conc_pen   = max(0, herfindahl - 0.20) * 2
        return sharpe + cvar_pen - conc_pen

    def train(self, signals_df, mc_engine, n_episodes=300,
              n_scenarios=200, save_path="rl_policy.pt"):
        from monte_carlo import N_ASSETS
        print(f"\nTraining RL policy on {DEVICE}")
        print(f"  Episodes: {n_episodes} | Scenarios: {n_scenarios}")
        rewards = []
        for ep in range(1, n_episodes+1):
            idx           = np.random.randint(60, len(signals_df)-35)
            current_state = signals_df.iloc[idx].values.astype(np.float32)
            stress        = float(current_state[0])
            regime        = ("crisis" if stress > 1 else
                             "elevated" if stress > 0 else "calm")
            state = np.concatenate([current_state,
                                    np.ones(N_ASSETS)/N_ASSETS])
            state_t = torch.FloatTensor(state).unsqueeze(0).to(DEVICE)
            scenarios = mc_engine.generate_scenarios(current_state, n_scenarios)
            w = self.policy.get_weights(state_t, regime)
            r = self._reward(w, scenarios)

            self.optimizer.zero_grad()
            conc = self.policy(state_t)
            wt   = conc / conc.sum(-1, keepdim=True)
            ent  = -(wt * (wt+1e-8).log()).sum()
            loss = -torch.tensor(r, dtype=torch.float32) * ent * 0.01
            loss += 0.001 * (conc-1).pow(2).mean()
            if torch.isfinite(loss):
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.policy.parameters(), 0.5)
                self.optimizer.step()
            self.scheduler.step()
            rewards.append(r)
            if ep % 50 == 0:
                print(f"  Ep {ep:4d} | avg reward: {np.mean(rewards[-50:]):.4f}")
        torch.save({"policy": self.policy.state_dict(),
                    "state_dim": signals_df.shape[1]+N_ASSETS,
                    "max_cvar": self.max_cvar}, save_path)
        print(f"  Saved → {save_path}")
        return rewards

    @classmethod
    def load_policy(cls, path):
        ckpt      = torch.load(path, map_location=DEVICE, weights_only=False)
        state_dim = ckpt["state_dim"]
        max_cvar  = ckpt.get("max_cvar", -0.10)
        t = cls(state_dim=state_dim, max_cvar=max_cvar)
        t.policy.load_state_dict(ckpt["policy"])
        print(f"Policy loaded from {path}")
        return t, state_dim


if __name__ == "__main__":
    from data_loader import load_all_signals
    print("Portfolio Optimizer v2 — calibration test")
    print("="*50)
    signals   = load_all_signals()
    mc_engine = MonteCarloEngine(horizon=30, df_t=8, seed=42)
    optimizer = CVaROptimizer(alpha=0.05, max_cvar=-0.10)

    for stress, regime in [(20,"calm"),(50,"elevated"),(80,"crisis")]:
        state = np.array([(stress-50)/15]+[0.0]*8, dtype=np.float32)
        sc    = mc_engine.generate_scenarios(state, 500)
        result = optimizer.optimize(sc, regime=regime,
                                    risk_tolerance=0.5)
        print(f"\nRegime: {regime.upper()}")
        print(f"  Expected: {result['expected_ret']*100:+.1f}%  "
              f"CVaR: {result['cvar']*100:.1f}%  "
              f"Sharpe: {result['sharpe']:.2f}  "
              f"{'✓' if result['is_safe'] else '✗'}")
        for a, w in sorted(result['weights_named'].items(),
                           key=lambda x: -x[1]):
            if w > 0.03:
                print(f"  {'█'*int(w*30)} {a} {w*100:.0f}%")


# ── Return-maximising bounds (calm/opportunistic regime) ──
BOUNDS_RETURN_MAX = [
    (0.15, 0.50),   # indian_equity    — high allocation allowed
    (0.05, 0.40),   # us_equity
    (0.00, 0.20),   # emerging_markets
    (0.05, 0.20),   # gold
    (0.00, 0.20),   # bonds_india      — reduced ceiling
    (0.00, 0.12),   # bonds_us         — hard cap: bonds_us drags return
    (0.00, 0.10),   # crypto
    (0.02, 0.10),   # cash
    (0.00, 0.10),   # commodities
]

# Update BOUNDS_BY_REGIME with return-maximising calm bounds
BOUNDS_BY_REGIME["calm"] = BOUNDS_RETURN_MAX


class ReturnMaximiser:
    """
    Maximises expected return subject to CVaR constraint.
    Used when stress is low and regime is calm.
    
    Different from CVaROptimizer which maximises Sharpe.
    This finds the highest possible return portfolio
    that still satisfies the CVaR safety limit.
    """

    def __init__(self, alpha: float = 0.05,
                 max_cvar: float = -0.10):
        self.alpha    = alpha
        self.max_cvar = max_cvar

    def optimize(self, scenarios: np.ndarray,
                 regime: str = "calm") -> Dict:

        bounds = BOUNDS_RETURN_MAX
        seeds  = [
            np.array([0.40,0.25,0.08,0.08,0.05,0.03,0.05,0.03,0.03]),
            np.array([0.35,0.30,0.10,0.08,0.05,0.02,0.05,0.03,0.02]),
            np.array([0.45,0.20,0.08,0.06,0.05,0.02,0.06,0.04,0.04]),
            np.array([0.38,0.22,0.10,0.10,0.06,0.03,0.06,0.03,0.02]),
        ]

        def stats(w):
            w  = np.clip(w, 0, 1); w /= w.sum() + 1e-8
            r  = mc_portfolio_returns(w, scenarios)
            tn = max(1, int(np.ceil(self.alpha * len(r))))
            cvar   = float(np.sort(r)[:tn].mean())
            exp    = float(r.mean())
            vol    = float(r.std()) + 1e-8
            sharpe = exp / vol * np.sqrt(12)
            return exp, cvar, sharpe

        def objective(w):
            exp, cvar, sharpe = stats(w)
            # Heavy penalty for CVaR violation
            cvar_pen  = max(0, self.max_cvar - cvar) * 30
            # Concentration penalty
            conc_pen  = max(0, np.sum(w**2) - 0.25) * 2
            # Maximise return directly
            return -(exp * 100 - cvar_pen - conc_pen)

        best_w, best_exp = seeds[0].copy(), 0.0

        for w0 in seeds:
            w0 = np.clip(w0, [b[0] for b in bounds],
                             [b[1] for b in bounds])
            w0 /= w0.sum()
            try:
                res = minimize(
                    objective, w0,
                    method="SLSQP",
                    bounds=bounds,
                    constraints=[{"type":"eq","fun":lambda w:w.sum()-1}],
                    options={"maxiter":2000,"ftol":1e-10}
                )
                if res.success:
                    exp, cvar, sharpe = stats(res.x)
                    if cvar >= self.max_cvar and exp > best_exp:
                        best_exp = exp
                        best_w   = res.x.copy()
            except Exception:
                continue

        weights = np.clip(best_w, 0, 1)
        weights /= weights.sum()
        exp, cvar, sharpe = stats(weights)

        # If CVaR violated fall back to CVaROptimizer
        if cvar < self.max_cvar:
            fallback = CVaROptimizer(self.alpha, self.max_cvar)
            return fallback.optimize(scenarios, regime, risk_tolerance=0.7)

        return {
            "weights":       weights,
            "weights_named": dict(zip(ASSET_CLASSES, weights)),
            "cvar":          cvar,
            "expected_ret":  exp,
            "sharpe":        sharpe,
            "is_safe":       cvar >= self.max_cvar,
            "regime":        regime,
            "max_cvar":      self.max_cvar,
        }
