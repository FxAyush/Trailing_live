"""
main.py
-------
Run the full crisis detection pipeline:
  1. Load data
  2. Compute Z-scores and stress index
  3. Backtest against historical crises
  4. Simulate portfolio protection
  5. Generate PDF report
"""

from data_loader import load_all_signals
from signal_processor import run_full_pipeline, get_current_snapshot
from backtester import run_full_backtest, compute_portfolio_protection
from visualizer import generate_full_report


def main():
    print("=" * 60)
    print("  FINANCIAL STRESS INDEX — CRISIS DETECTION SYSTEM")
    print("=" * 60)

    # Step 1: Load signals
    df = load_all_signals(start="2007-01-01", end="2024-01-01")

    # Step 2: Compute stress index
    results = run_full_pipeline(df)

    # Step 3: Current snapshot
    snap = get_current_snapshot(results)
    print(f"\n{'='*60}")
    print(f"  LATEST READING  ({snap['date']})")
    print(f"{'='*60}")
    print(f"  Stress score : {snap['stress_score']:.1f} / 100")
    print(f"  Regime       : {snap['regime'].upper()}")
    print(f"  Action       : {snap['action']}")
    print(f"  Trend        : {snap['trend']}")
    print(f"\n  Category breakdown:")
    for cat, info in snap["categories"].items():
        bar = "█" * int(info["percentile"] / 10)
        print(f"    {info['label'][:32]:32s} {bar:10s} {info['percentile']:.0f}th pct")

    # Step 4: Backtest
    print(f"\n{'='*60}")
    print("  BACKTEST RESULTS")
    print(f"{'='*60}")
    backtest = run_full_backtest(results["score"])

    # Step 5: Portfolio protection
    print(f"\n{'='*60}")
    print("  PORTFOLIO PROTECTION SIMULATION")
    print(f"{'='*60}")
    portfolio = compute_portfolio_protection(results["score"])
    print(f"  Benchmark  → Ann. return: {portfolio['benchmark_annualised_pct']:.1f}%  "
          f"| Max drawdown: {portfolio['benchmark_max_drawdown_pct']:.1f}%  "
          f"| Sharpe: {portfolio['benchmark_sharpe']:.2f}")
    print(f"  Strategy   → Ann. return: {portfolio['strategy_annualised_pct']:.1f}%  "
          f"| Max drawdown: {portfolio['strategy_max_drawdown_pct']:.1f}%  "
          f"| Sharpe: {portfolio['strategy_sharpe']:.2f}")
    drawdown_improvement = abs(portfolio['benchmark_max_drawdown_pct']) - abs(portfolio['strategy_max_drawdown_pct'])
    print(f"\n  Drawdown reduced by {drawdown_improvement:.1f} percentage points vs benchmark")

    # Step 6: Generate report
    print(f"\n{'='*60}")
    print("  GENERATING REPORT")
    print(f"{'='*60}")
    generate_full_report(
    results, backtest, portfolio,
    output_path="crisis_detection_report.pdf"
)
    print("\nDone.")


if __name__ == "__main__":
    main()
